/*! emojione 17-07-2015 */
!function(a){a.emojioneList={":flag_zw:":["1f1ff-1f1fc"],":zw:":["1f1ff-1f1fc"],":flag_zm:":["1f1ff-1f1f2"],":zm:":["1f1ff-1f1f2"],":flag_ye:":["1f1fe-1f1ea"],":ye:":["1f1fe-1f1ea"],":flag_eh:":["1f1ea-1f1ed"],":eh:":["1f1ea-1f1ed"],":flag_wf:":["1f1fc-1f1eb"],":wf:":["1f1fc-1f1eb"],":flag_ve:":["1f1fb-1f1ea"],":ve:":["1f1fb-1f1ea"],":flag_va:":["1f1fb-1f1e6"],":va:":["1f1fb-1f1e6"],":flag_vu:":["1f1fb-1f1fa"],":vu:":["1f1fb-1f1fa"],":flag_uz:":["1f1fa-1f1ff"],":uz:":["1f1fa-1f1ff"],":flag_uy:":["1f1fa-1f1fe"],":uy:":["1f1fa-1f1fe"],":flag_ua:":["1f1fa-1f1e6"],":ua:":["1f1fa-1f1e6"],":flag_ug:":["1f1fa-1f1ec"],":ug:":["1f1fa-1f1ec"],":flag_vi:":["1f1fb-1f1ee"],":vi:":["1f1fb-1f1ee"],":flag_tv:":["1f1f9-1f1fb"],":tuvalu:":["1f1f9-1f1fb"],":flag_tm:":["1f1f9-1f1f2"],":turkmenistan:":["1f1f9-1f1f2"],":flag_tn:":["1f1f9-1f1f3"],":tn:":["1f1f9-1f1f3"],":flag_tt:":["1f1f9-1f1f9"],":tt:":["1f1f9-1f1f9"],":flag_to:":["1f1f9-1f1f4"],":to:":["1f1f9-1f1f4"],":flag_tg:":["1f1f9-1f1ec"],":tg:":["1f1f9-1f1ec"],":flag_th:":["1f1f9-1f1ed"],":th:":["1f1f9-1f1ed"],":flag_tz:":["1f1f9-1f1ff"],":tz:":["1f1f9-1f1ff"],":flag_tj:":["1f1f9-1f1ef"],":tj:":["1f1f9-1f1ef"],":flag_tw:":["1f1f9-1f1fc"],":tw:":["1f1f9-1f1fc"],":flag_sy:":["1f1f8-1f1fe"],":sy:":["1f1f8-1f1fe"],":flag_sz:":["1f1f8-1f1ff"],":sz:":["1f1f8-1f1ff"],":flag_sr:":["1f1f8-1f1f7"],":sr:":["1f1f8-1f1f7"],":flag_sd:":["1f1f8-1f1e9"],":sd:":["1f1f8-1f1e9"],":flag_lk:":["1f1f1-1f1f0"],":lk:":["1f1f1-1f1f0"],":flag_so:":["1f1f8-1f1f4"],":so:":["1f1f8-1f1f4"],":flag_sb:":["1f1f8-1f1e7"],":sb:":["1f1f8-1f1e7"],":flag_si:":["1f1f8-1f1ee"],":si:":["1f1f8-1f1ee"],":flag_sk:":["1f1f8-1f1f0"],":sk:":["1f1f8-1f1f0"],":flag_sl:":["1f1f8-1f1f1"],":sl:":["1f1f8-1f1f1"],":flag_sc:":["1f1f8-1f1e8"],":sc:":["1f1f8-1f1e8"],":flag_rs:":["1f1f7-1f1f8"],":rs:":["1f1f7-1f1f8"],":flag_sn:":["1f1f8-1f1f3"],":sn:":["1f1f8-1f1f3"],":flag_st:":["1f1f8-1f1f9"],":st:":["1f1f8-1f1f9"],":flag_sm:":["1f1f8-1f1f2"],":sm:":["1f1f8-1f1f2"],":flag_ws:":["1f1fc-1f1f8"],":ws:":["1f1fc-1f1f8"],":flag_vc:":["1f1fb-1f1e8"],":vc:":["1f1fb-1f1e8"],":flag_lc:":["1f1f1-1f1e8"],":lc:":["1f1f1-1f1e8"],":flag_kn:":["1f1f0-1f1f3"],":kn:":["1f1f0-1f1f3"],":flag_sh:":["1f1f8-1f1ed"],":sh:":["1f1f8-1f1ed"],":flag_rw:":["1f1f7-1f1fc"],":rw:":["1f1f7-1f1fc"],":flag_ro:":["1f1f7-1f1f4"],":ro:":["1f1f7-1f1f4"],":flag_qa:":["1f1f6-1f1e6"],":qa:":["1f1f6-1f1e6"],":flag_pe:":["1f1f5-1f1ea"],":pe:":["1f1f5-1f1ea"],":flag_py:":["1f1f5-1f1fe"],":py:":["1f1f5-1f1fe"],":flag_pg:":["1f1f5-1f1ec"],":pg:":["1f1f5-1f1ec"],":flag_pa:":["1f1f5-1f1e6"],":pa:":["1f1f5-1f1e6"],":flag_ps:":["1f1f5-1f1f8"],":ps:":["1f1f5-1f1f8"],":flag_pw:":["1f1f5-1f1fc"],":pw:":["1f1f5-1f1fc"],":flag_pk:":["1f1f5-1f1f0"],":pk:":["1f1f5-1f1f0"],":flag_om:":["1f1f4-1f1f2"],":om:":["1f1f4-1f1f2"],":flag_kp:":["1f1f0-1f1f5"],":kp:":["1f1f0-1f1f5"],":flag_nu:":["1f1f3-1f1fa"],":nu:":["1f1f3-1f1fa"],":flag_ng:":["1f1f3-1f1ec"],":nigeria:":["1f1f3-1f1ec"],":flag_ne:":["1f1f3-1f1ea"],":ne:":["1f1f3-1f1ea"],":flag_ni:":["1f1f3-1f1ee"],":ni:":["1f1f3-1f1ee"],":flag_nc:":["1f1f3-1f1e8"],":nc:":["1f1f3-1f1e8"],":flag_np:":["1f1f3-1f1f5"],":np:":["1f1f3-1f1f5"],":flag_nr:":["1f1f3-1f1f7"],":nr:":["1f1f3-1f1f7"],":flag_na:":["1f1f3-1f1e6"],":na:":["1f1f3-1f1e6"],":flag_mm:":["1f1f2-1f1f2"],":mm:":["1f1f2-1f1f2"],":flag_mz:":["1f1f2-1f1ff"],":mz:":["1f1f2-1f1ff"],":flag_ma:":["1f1f2-1f1e6"],":ma:":["1f1f2-1f1e6"],":flag_ms:":["1f1f2-1f1f8"],":ms:":["1f1f2-1f1f8"],":flag_me:":["1f1f2-1f1ea"],":me:":["1f1f2-1f1ea"],":flag_mn:":["1f1f2-1f1f3"],":mn:":["1f1f2-1f1f3"],":flag_mc:":["1f1f2-1f1e8"],":mc:":["1f1f2-1f1e8"],":flag_md:":["1f1f2-1f1e9"],":md:":["1f1f2-1f1e9"],":flag_fm:":["1f1eb-1f1f2"],":fm:":["1f1eb-1f1f2"],":flag_mu:":["1f1f2-1f1fa"],":mu:":["1f1f2-1f1fa"],":flag_mr:":["1f1f2-1f1f7"],":mr:":["1f1f2-1f1f7"],":flag_mh:":["1f1f2-1f1ed"],":mh:":["1f1f2-1f1ed"],":flag_mt:":["1f1f2-1f1f9"],":mt:":["1f1f2-1f1f9"],":flag_ml:":["1f1f2-1f1f1"],":ml:":["1f1f2-1f1f1"],":flag_mv:":["1f1f2-1f1fb"],":mv:":["1f1f2-1f1fb"],":flag_mw:":["1f1f2-1f1fc"],":mw:":["1f1f2-1f1fc"],":flag_mg:":["1f1f2-1f1ec"],":mg:":["1f1f2-1f1ec"],":flag_mk:":["1f1f2-1f1f0"],":mk:":["1f1f2-1f1f0"],":flag_lu:":["1f1f1-1f1fa"],":lu:":["1f1f1-1f1fa"],":flag_lt:":["1f1f1-1f1f9"],":lt:":["1f1f1-1f1f9"],":flag_li:":["1f1f1-1f1ee"],":li:":["1f1f1-1f1ee"],":flag_ly:":["1f1f1-1f1fe"],":ly:":["1f1f1-1f1fe"],":flag_lr:":["1f1f1-1f1f7"],":lr:":["1f1f1-1f1f7"],":flag_ls:":["1f1f1-1f1f8"],":ls:":["1f1f1-1f1f8"],":flag_lb:":["1f1f1-1f1e7"],":lb:":["1f1f1-1f1e7"],":flag_lv:":["1f1f1-1f1fb"],":lv:":["1f1f1-1f1fb"],":flag_la:":["1f1f1-1f1e6"],":la:":["1f1f1-1f1e6"],":flag_kg:":["1f1f0-1f1ec"],":kg:":["1f1f0-1f1ec"],":flag_kw:":["1f1f0-1f1fc"],":kw:":["1f1f0-1f1fc"],":flag_xk:":["1f1fd-1f1f0"],":xk:":["1f1fd-1f1f0"],":flag_ki:":["1f1f0-1f1ee"],":ki:":["1f1f0-1f1ee"],":flag_ke:":["1f1f0-1f1ea"],":ke:":["1f1f0-1f1ea"],":flag_kz:":["1f1f0-1f1ff"],":kz:":["1f1f0-1f1ff"],":flag_jo:":["1f1ef-1f1f4"],":jo:":["1f1ef-1f1f4"],":flag_je:":["1f1ef-1f1ea"],":je:":["1f1ef-1f1ea"],":flag_jm:":["1f1ef-1f1f2"],":jm:":["1f1ef-1f1f2"],":flag_iq:":["1f1ee-1f1f6"],":iq:":["1f1ee-1f1f6"],":flag_ir:":["1f1ee-1f1f7"],":ir:":["1f1ee-1f1f7"],":flag_is:":["1f1ee-1f1f8"],":is:":["1f1ee-1f1f8"],":flag_hu:":["1f1ed-1f1fa"],":hu:":["1f1ed-1f1fa"],":flag_hn:":["1f1ed-1f1f3"],":hn:":["1f1ed-1f1f3"],":flag_ht:":["1f1ed-1f1f9"],":ht:":["1f1ed-1f1f9"],":flag_gy:":["1f1ec-1f1fe"],":gy:":["1f1ec-1f1fe"],":flag_gw:":["1f1ec-1f1fc"],":gw:":["1f1ec-1f1fc"],":flag_gn:":["1f1ec-1f1f3"],":gn:":["1f1ec-1f1f3"],":flag_gt:":["1f1ec-1f1f9"],":gt:":["1f1ec-1f1f9"],":flag_gu:":["1f1ec-1f1fa"],":gu:":["1f1ec-1f1fa"],":flag_gd:":["1f1ec-1f1e9"],":gd:":["1f1ec-1f1e9"],":flag_gl:":["1f1ec-1f1f1"],":gl:":["1f1ec-1f1f1"],":flag_gr:":["1f1ec-1f1f7"],":gr:":["1f1ec-1f1f7"],":flag_gi:":["1f1ec-1f1ee"],":gi:":["1f1ec-1f1ee"],":flag_gh:":["1f1ec-1f1ed"],":gh:":["1f1ec-1f1ed"],":flag_ge:":["1f1ec-1f1ea"],":ge:":["1f1ec-1f1ea"],":flag_gm:":["1f1ec-1f1f2"],":gm:":["1f1ec-1f1f2"],":flag_ga:":["1f1ec-1f1e6"],":ga:":["1f1ec-1f1e6"],":flag_pf:":["1f1f5-1f1eb"],":pf:":["1f1f5-1f1eb"],":flag_fj:":["1f1eb-1f1ef"],":fj:":["1f1eb-1f1ef"],":flag_fo:":["1f1eb-1f1f4"],":fo:":["1f1eb-1f1f4"],":flag_fk:":["1f1eb-1f1f0"],":fk:":["1f1eb-1f1f0"],":flag_et:":["1f1ea-1f1f9"],":et:":["1f1ea-1f1f9"],":flag_ee:":["1f1ea-1f1ea"],":ee:":["1f1ea-1f1ea"],":flag_er:":["1f1ea-1f1f7"],":er:":["1f1ea-1f1f7"],":flag_gq:":["1f1ec-1f1f6"],":gq:":["1f1ec-1f1f6"],":flag_sv:":["1f1f8-1f1fb"],":sv:":["1f1f8-1f1fb"],":flag_eg:":["1f1ea-1f1ec"],":eg:":["1f1ea-1f1ec"],":flag_ec:":["1f1ea-1f1e8"],":ec:":["1f1ea-1f1e8"],":flag_tl:":["1f1f9-1f1f1"],":tl:":["1f1f9-1f1f1"],":flag_do:":["1f1e9-1f1f4"],":do:":["1f1e9-1f1f4"],":flag_dm:":["1f1e9-1f1f2"],":dm:":["1f1e9-1f1f2"],":flag_dj:":["1f1e9-1f1ef"],":dj:":["1f1e9-1f1ef"],":flag_cz:":["1f1e8-1f1ff"],":cz:":["1f1e8-1f1ff"],":flag_cy:":["1f1e8-1f1fe"],":cy:":["1f1e8-1f1fe"],":flag_cu:":["1f1e8-1f1fa"],":cu:":["1f1e8-1f1fa"],":flag_hr:":["1f1ed-1f1f7"],":hr:":["1f1ed-1f1f7"],":flag_ci:":["1f1e8-1f1ee"],":ci:":["1f1e8-1f1ee"],":flag_cr:":["1f1e8-1f1f7"],":cr:":["1f1e8-1f1f7"],":flag_td:":["1f1f9-1f1e9"],":td:":["1f1f9-1f1e9"],":flag_cg:":["1f1e8-1f1ec"],":cg:":["1f1e8-1f1ec"],":flag_cd:":["1f1e8-1f1e9"],":congo:":["1f1e8-1f1e9"],":flag_km:":["1f1f0-1f1f2"],":km:":["1f1f0-1f1f2"],":flag_cf:":["1f1e8-1f1eb"],":cf:":["1f1e8-1f1eb"],":flag_ky:":["1f1f0-1f1fe"],":ky:":["1f1f0-1f1fe"],":flag_cv:":["1f1e8-1f1fb"],":cv:":["1f1e8-1f1fb"],":flag_cm:":["1f1e8-1f1f2"],":cm:":["1f1e8-1f1f2"],":flag_kh:":["1f1f0-1f1ed"],":kh:":["1f1f0-1f1ed"],":flag_bi:":["1f1e7-1f1ee"],":bi:":["1f1e7-1f1ee"],":flag_bf:":["1f1e7-1f1eb"],":bf:":["1f1e7-1f1eb"],":flag_bg:":["1f1e7-1f1ec"],":bg:":["1f1e7-1f1ec"],":flag_bn:":["1f1e7-1f1f3"],":bn:":["1f1e7-1f1f3"],":flag_bw:":["1f1e7-1f1fc"],":bw:":["1f1e7-1f1fc"],":flag_ba:":["1f1e7-1f1e6"],":ba:":["1f1e7-1f1e6"],":flag_bo:":["1f1e7-1f1f4"],":bo:":["1f1e7-1f1f4"],":flag_bt:":["1f1e7-1f1f9"],":bt:":["1f1e7-1f1f9"],":flag_bm:":["1f1e7-1f1f2"],":bm:":["1f1e7-1f1f2"],":flag_bj:":["1f1e7-1f1ef"],":bj:":["1f1e7-1f1ef"],":flag_bz:":["1f1e7-1f1ff"],":bz:":["1f1e7-1f1ff"],":flag_by:":["1f1e7-1f1fe"],":by:":["1f1e7-1f1fe"],":flag_bb:":["1f1e7-1f1e7"],":bb:":["1f1e7-1f1e7"],":flag_bd:":["1f1e7-1f1e9"],":bd:":["1f1e7-1f1e9"],":flag_bh:":["1f1e7-1f1ed"],":bh:":["1f1e7-1f1ed"],":flag_bs:":["1f1e7-1f1f8"],":bs:":["1f1e7-1f1f8"],":flag_az:":["1f1e6-1f1ff"],":az:":["1f1e6-1f1ff"],":flag_ac:":["1f1e6-1f1e8"],":ac:":["1f1e6-1f1e8"],":flag_aw:":["1f1e6-1f1fc"],":aw:":["1f1e6-1f1fc"],":flag_am:":["1f1e6-1f1f2"],":am:":["1f1e6-1f1f2"],":flag_ar:":["1f1e6-1f1f7"],":ar:":["1f1e6-1f1f7"],":flag_ag:":["1f1e6-1f1ec"],":ag:":["1f1e6-1f1ec"],":flag_ai:":["1f1e6-1f1ee"],":ai:":["1f1e6-1f1ee"],":flag_ao:":["1f1e6-1f1f4"],":ao:":["1f1e6-1f1f4"],":flag_ad:":["1f1e6-1f1e9"],":ad:":["1f1e6-1f1e9"],":flag_dz:":["1f1e9-1f1ff"],":dz:":["1f1e9-1f1ff"],":flag_al:":["1f1e6-1f1f1"],":al:":["1f1e6-1f1f1"],":flag_af:":["1f1e6-1f1eb"],":af:":["1f1e6-1f1eb"],":flag_vn:":["1f1fb-1f1f3"],":vn:":["1f1fb-1f1f3"],":flag_ae:":["1f1e6-1f1ea"],":ae:":["1f1e6-1f1ea"],":flag_us:":["1f1fa-1f1f8"],":us:":["1f1fa-1f1f8"],":flag_gb:":["1f1ec-1f1e7"],":gb:":["1f1ec-1f1e7"],":flag_tr:":["1f1f9-1f1f7"],":tr:":["1f1f9-1f1f7"],":flag_ch:":["1f1e8-1f1ed"],":ch:":["1f1e8-1f1ed"],":flag_se:":["1f1f8-1f1ea"],":se:":["1f1f8-1f1ea"],":flag_es:":["1f1ea-1f1f8"],":es:":["1f1ea-1f1f8"],":flag_za:":["1f1ff-1f1e6"],":za:":["1f1ff-1f1e6"],":flag_sg:":["1f1f8-1f1ec"],":sg:":["1f1f8-1f1ec"],":flag_sa:":["1f1f8-1f1e6"],":saudiarabia:":["1f1f8-1f1e6"],":saudi:":["1f1f8-1f1e6"],":flag_ru:":["1f1f7-1f1fa"],":ru:":["1f1f7-1f1fa"],":flag_pr:":["1f1f5-1f1f7"],":pr:":["1f1f5-1f1f7"],":flag_pt:":["1f1f5-1f1f9"],":pt:":["1f1f5-1f1f9"],":flag_pl:":["1f1f5-1f1f1"],":pl:":["1f1f5-1f1f1"],":flag_ph:":["1f1f5-1f1ed"],":ph:":["1f1f5-1f1ed"],":flag_no:":["1f1f3-1f1f4"],":no:":["1f1f3-1f1f4"],":flag_nz:":["1f1f3-1f1ff"],":nz:":["1f1f3-1f1ff"],":flag_nl:":["1f1f3-1f1f1"],":nl:":["1f1f3-1f1f1"],":flag_mx:":["1f1f2-1f1fd"],":mx:":["1f1f2-1f1fd"],":flag_my:":["1f1f2-1f1fe"],":my:":["1f1f2-1f1fe"],":flag_mo:":["1f1f2-1f1f4"],":mo:":["1f1f2-1f1f4"],":flag_kr:":["1f1f0-1f1f7"],":kr:":["1f1f0-1f1f7"],":flag_jp:":["1f1ef-1f1f5"],":jp:":["1f1ef-1f1f5"],":flag_it:":["1f1ee-1f1f9"],":it:":["1f1ee-1f1f9"],":flag_il:":["1f1ee-1f1f1"],":il:":["1f1ee-1f1f1"],":flag_ie:":["1f1ee-1f1ea"],":ie:":["1f1ee-1f1ea"],":flag_id:":["1f1ee-1f1e9"],":indonesia:":["1f1ee-1f1e9"],":flag_in:":["1f1ee-1f1f3"],":in:":["1f1ee-1f1f3"],":flag_hk:":["1f1ed-1f1f0"],":hk:":["1f1ed-1f1f0"],":flag_de:":["1f1e9-1f1ea"],":de:":["1f1e9-1f1ea"],":flag_fr:":["1f1eb-1f1f7"],":fr:":["1f1eb-1f1f7"],":flag_fi:":["1f1eb-1f1ee"],":fi:":["1f1eb-1f1ee"],":flag_dk:":["1f1e9-1f1f0"],":dk:":["1f1e9-1f1f0"],":flag_co:":["1f1e8-1f1f4"],":co:":["1f1e8-1f1f4"],":flag_cn:":["1f1e8-1f1f3"],":cn:":["1f1e8-1f1f3"],":flag_cl:":["1f1e8-1f1f1"],":chile:":["1f1e8-1f1f1"],":flag_ca:":["1f1e8-1f1e6"],":ca:":["1f1e8-1f1e6"],":flag_br:":["1f1e7-1f1f7"],":br:":["1f1e7-1f1f7"],":flag_be:":["1f1e7-1f1ea"],":be:":["1f1e7-1f1ea"],":flag_at:":["1f1e6-1f1f9"],":at:":["1f1e6-1f1f9"],":flag_au:":["1f1e6-1f1fa"],":au:":["1f1e6-1f1fa"],":map:":["1f5fa"],":world_map:":["1f5fa"],":school:":["1f3eb"],":convenience_store:":["1f3ea"],":church:":["26ea-fe0f","26ea"],":wedding:":["1f492"],":love_hotel:":["1f3e9"],":hotel:":["1f3e8"],":bank:":["1f3e6"],":hospital:":["1f3e5"],":european_post_office:":["1f3e4"],":post_office:":["1f3e3"],":factory:":["1f3ed"],":department_store:":["1f3ec"],":office:":["1f3e2"],":contruction_site:":["1f3d7"],":building_construction:":["1f3d7"],":house-abandoned:":["1f3da"],":derelict_house_building:":["1f3da"],":house_with_garden:":["1f3e1"],":homes:":["1f3d8"],":house_buildings:":["1f3d8"],":house:":["1f3e0"],":bridge_at_night:":["1f309"],":night_with_stars:":["1f303"],":city_dusk:":["1f306"],":city_sunset:":["1f307"],":city_sunrise:":["1f307"],":cityscape:":["1f3d9"],":cityscape:":["1f3d9"],":park:":["1f3de"],":national_park:":["1f3de"],":island:":["1f3dd"],":desert_island:":["1f3dd"],":desert:":["1f3dc"],":beach:":["1f3d6"],":beach_with_umbrella:":["1f3d6"],":camping:":["1f3d5"],":mountain_snow:":["1f3d4"],":snow_capped_mountain:":["1f3d4"],":stadium:":["1f3df"],":classical_building:":["1f3db"],":japanese_castle:":["1f3ef"],":european_castle:":["1f3f0"],":fountain:":["26f2-fe0f","26f2"],":tokyo_tower:":["1f5fc"],":foggy:":["1f301"],":moyai:":["1f5ff"],":statue_of_liberty:":["1f5fd"],":shopping_bags:":["1f6cd"],":shopping_bags:":["1f6cd"],":fork_knife_plate:":["1f37d"],":fork_and_knife_with_plate:":["1f37d"],":couch:":["1f6cb"],":couch_and_lamp:":["1f6cb"],":bed:":["1f6cf"],":bellhop:":["1f6ce"],":bellhop_bell:":["1f6ce"],":dollar:":["1f4b5"],":pound:":["1f4b7"],":euro:":["1f4b6"],":yen:":["1f4b4"],":left_luggage:":["1f6c5"],":baggage_claim:":["1f6c4"],":customs:":["1f6c3"],":passport_control:":["1f6c2"],":suspension_railway:":["1f69f"],":mountain_cableway:":["1f6a0"],":aerial_tramway:":["1f6a1"],":sailboat:":["26f5-fe0f","26f5"],":speedboat:":["1f6a4"],":motorboat:":["1f6e5"],":cruise_ship:":["1f6f3"],":passenger_ship:":["1f6f3"],":ship:":["1f6a2"],":anchor:":["2693-fe0f","2693"],":seat:":["1f4ba"],":airplane_arriving:":["1f6ec"],":airplane_departure:":["1f6eb"],":airplane_small:":["1f6e9"],":small_airplane:":["1f6e9"],":airplane_northeast:":["1f6ea"],":northeast_pointing_airplane:":["1f6ea"],":jet_up:":["1f6e6"],":up_pointing_military_airplane:":["1f6e6"],":airplane_small_up:":["1f6e8"],":up_pointing_small_airplane:":["1f6e8"],":airplane_up:":["1f6e7"],":up_pointing_airplane:":["1f6e7"],":airplane:":["2708-fe0f","2708"],":helicopter:":["1f681"],":rocket:":["1f680"],":traffic_light:":["1f6a5"],":vertical_traffic_light:":["1f6a6"],":construction:":["1f6a7"],":fuelpump:":["26fd-fe0f","26fd"],":busstop:":["1f68f"],":motorway:":["1f6e3"],":bike:":["1f6b2"],":tractor:":["1f69c"],":articulated_lorry:":["1f69b"],":truck:":["1f69a"],":blue_car:":["1f699"],":oncoming_automobile:":["1f698"],":red_car:":["1f697"],":oncoming_taxi:":["1f696"],":taxi:":["1f695"],":rotating_light:":["1f6a8"],":oncoming_police_car:":["1f694"],":police_car:":["1f693"],":fire_engine_oncoming:":["1f6f1"],":oncoming_fire_engine:":["1f6f1"],":fire_engine:":["1f692"],":ambulance:":["1f691"],":minibus:":["1f690"],":trolleybus:":["1f68e"],":oncoming_bus:":["1f68d"],":bus:":["1f68c"],":railway_track:":["1f6e4"],":railroad_track:":["1f6e4"],":tram:":["1f68a"],":station:":["1f689"],":light_rail:":["1f688"],":metro:":["1f687"],":train2:":["1f686"],":bullettrain_front:":["1f685"],":bullettrain_side:":["1f684"],":monorail:":["1f69d"],":train:":["1f68b"],":train_diesel:":["1f6f2"],":diesel_locomotive:":["1f6f2"],":steam_locomotive:":["1f682"],":mountain_railway:":["1f69e"],":railway_car:":["1f683"],":clock1230:":["1f567"],":clock1130:":["1f566"],":clock1030:":["1f565"],":clock930:":["1f564"],":clock830:":["1f563"],":clock730:":["1f562"],":clock630:":["1f561"],":clock530:":["1f560"],":clock430:":["1f55f"],":clock330:":["1f55e"],":clock230:":["1f55d"],":clock130:":["1f55c"],":clock12:":["1f55b"],":clock11:":["1f55a"],":clock10:":["1f559"],":clock9:":["1f558"],":clock8:":["1f557"],":clock7:":["1f556"],":clock6:":["1f555"],":clock5:":["1f554"],":clock4:":["1f553"],":clock3:":["1f552"],":clock2:":["1f551"],":clock1:":["1f550"],":white_square_button:":["1f533"],":black_square_button:":["1f532"],":white_medium_small_square:":["25fd-fe0f","25fd"],":black_medium_small_square:":["25fe-fe0f","25fe"],":white_medium_square:":["25fb-fe0f","25fb"],":black_medium_square:":["25fc-fe0f","25fc"],":white_large_square:":["2b1c-fe0f","2b1c"],":black_large_square:":["2b1b-fe0f","2b1b"],":white_small_square:":["25ab-fe0f","25ab"],":black_small_square:":["25aa-fe0f","25aa"],":large_blue_diamond:":["1f537"],":large_orange_diamond:":["1f536"],":small_blue_diamond:":["1f539"],":small_orange_diamond:":["1f538"],":small_red_triangle_down:":["1f53b"],":small_red_triangle:":["1f53a"],":large_blue_circle:":["1f535"],":red_circle:":["1f534"],":radio_button:":["1f518"],":black_circle:":["26ab-fe0f","26ab"],":white_circle:":["26aa-fe0f","26aa"],":ballot_box_x:":["1f5f5"],":ballot_box_with_script_x:":["1f5f5"],":ballot_x:":["1f5f4"],":ballot_script_x:":["1f5f4"],":ballot_box_check:":["1f5f9"],":ballot_box_with_bold_check:":["1f5f9"],":light_check_mark:":["1f5f8"],":light_mark:":["1f5f8"],":ballot_box_with_check:":["2611-fe0f","2611"],":diamonds:":["2666-fe0f","2666"],":hearts:":["2665-fe0f","2665"],":clubs:":["2663-fe0f","2663"],":spades:":["2660-fe0f","2660"],":diamond_shape_with_a_dot_inside:":["1f4a0"],":anger:":["1f4a2"],":recycle:":["267b-fe0f","267b"],":rosette_black:":["1f3f6"],":rosette:":["1f3f5"],":hotsprings:":["2668-fe0f","2668"],":warning:":["26a0-fe0f","26a0"],":trident:":["1f531"],":mood_lightning:":["1f5f2"],":lightning_mood:":["1f5f2"],":beginner:":["1f530"],":six_pointed_star:":["1f52f"],":ophiuchus:":["26ce"],":info:":["1f6c8"],":circled_information_source:":["1f6c8"],":m:":["24c2-fe0f","24c2"],":cyclone:":["1f300"],":soon:":["1f51c"],":top:":["1f51d"],":on:":["1f51b"],":back:":["1f519"],":end:":["1f51a"],":100:":["1f4af"],":o:":["2b55-fe0f","2b55"],":x:":["274c"],":triangle_round:":["1f6c6"],":triangle_with_rounded_corners:":["1f6c6"],":interrobang:":["2049-fe0f","2049"],":bangbang:":["203c-fe0f","203c"],":grey_question:":["2754"],":grey_exclamation:":["2755"],":question:":["2753"],":exclamation:":["2757-fe0f","2757"],":part_alternation_mark:":["303d-fe0f","303d"],":loop:":["27bf"],":curly_loop:":["27b0"],":heavy_dollar_sign:":["1f4b2"],":currency_exchange:":["1f4b1"],":registered:":["00ae"],":copyright:":["00a9"],":tm:":["2122"],":clockwise_arrows:":["1f5d8"],":clockwise_right_and_left_semicircle_arrows:":["1f5d8"],":arrows_clockwise:":["1f503"],":cancellation_x:":["1f5d9"],":heavy_check_mark:":["2714-fe0f","2714"],":heavy_multiplication_x:":["2716-fe0f","2716"],":heavy_division_sign:":["2797"],":wavy_dash:":["3030"],":heavy_minus_sign:":["2796"],":heavy_plus_sign:":["2795"],":symbols:":["1f523"],":cinema:":["1f3a6"],":signal_strength:":["1f4f6"],":information_source:":["2139-fe0f","2139"],":capital_abcd:":["1f520"],":abcd:":["1f521"],":abc:":["1f524"],":1234:":["1f522"],":keycap_ten:":["1f51f"],":nine:":["0039-fe0f-20e3","0039-20e3"],":eight:":["0038-fe0f-20e3","0038-20e3"],":seven:":["0037-fe0f-20e3","0037-20e3"],":six:":["0036-fe0f-20e3","0036-20e3"],":five:":["0035-fe0f-20e3","0035-20e3"],":four:":["0034-fe0f-20e3","0034-20e3"],":three:":["0033-fe0f-20e3","0033-20e3"],":two:":["0032-fe0f-20e3","0032-20e3"],":one:":["0031-fe0f-20e3","0031-20e3"],":zero:":["0030-fe0f-20e3","0030-20e3"],":hash:":["0023-fe0f-20e3","0023-20e3"],":repeat_one:":["1f502"],":repeat:":["1f501"],":twisted_rightwards_arrows:":["1f500"],":arrow_heading_down:":["2935-fe0f","2935"],":arrow_heading_up:":["2934-fe0f","2934"],":leftwards_arrow_with_hook:":["21a9-fe0f","21a9"],":arrow_right_hook:":["21aa-fe0f","21aa"],":arrows_counterclockwise:":["1f504"],":left_right_arrow:":["2194-fe0f","2194"],":arrow_up_down:":["2195-fe0f","2195"],":arrow_upper_left:":["2196-fe0f","2196"],":arrow_lower_left:":["2199-fe0f","2199"],":arrow_lower_right:":["2198-fe0f","2198"],":arrow_upper_right:":["2197-fe0f","2197"],":arrow_down:":["2b07-fe0f","2b07"],":arrow_up:":["2b06-fe0f","2b06"],":arrow_left:":["2b05-fe0f","2b05"],":arrow_right:":["27a1-fe0f","27a1"],":arrow_double_down:":["23ec"],":arrow_double_up:":["23eb"],":rewind:":["23ea"],":fast_forward:":["23e9"],":arrow_down_small:":["1f53d"],":arrow_up_small:":["1f53c"],":arrow_backward:":["25c0-fe0f","25c0"],":arrow_forward:":["25b6-fe0f","25b6"],":put_litter_in_its_place:":["1f6ae"],":no_smoking:":["1f6ad"],":potable_water:":["1f6b0"],":wheelchair:":["267f-fe0f","267f"],":baby_symbol:":["1f6bc"],":girls_symbol:":["1f6ca"],":boys_symbol:":["1f6c9"],":womens:":["1f6ba"],":mens:":["1f6b9"],":restroom:":["1f6bb"],":pisces:":["2653-fe0f","2653"],":aquarius:":["2652-fe0f","2652"],":capricorn:":["2651-fe0f","2651"],":sagittarius:":["2650-fe0f","2650"],":scorpius:":["264f-fe0f","264f"],":libra:":["264e-fe0f","264e"],":virgo:":["264d-fe0f","264d"],":leo:":["264c-fe0f","264c"],":cancer:":["264b-fe0f","264b"],":gemini:":["264a-fe0f","264a"],":taurus:":["2649-fe0f","2649"],":aries:":["2648-fe0f","2648"],":atm:":["1f3e7"],":up:":["1f199"],":ok:":["1f197"],":ng:":["1f196"],":new:":["1f195"],":free:":["1f193"],":cool:":["1f192"],":wc:":["1f6be"],":parking:":["1f17f-fe0f","1f17f"],":id:":["1f194"],":sos:":["1f198"],":o2:":["1f17e"],":cl:":["1f191"],":ab:":["1f18e"],":b:":["1f171"],":a:":["1f170"],":vs:":["1f19a"],":mobile_phone_off:":["1f4f4"],":vibration_mode:":["1f4f3"],":eight_pointed_black_star:":["2734-fe0f","2734"],":white_check_mark:":["2705"],":negative_squared_cross_mark:":["274e"],":eight_spoked_asterisk:":["2733-fe0f","2733"],":sparkle:":["2747-fe0f","2747"],":chart:":["1f4b9"],":u6307:":["1f22f-fe0f","1f22f"],":koko:":["1f201"],":sa:":["1f202"],":u7a7a:":["1f233"],":u5272:":["1f239"],":u6708:":["1f237"],":u55b6:":["1f23a"],":u7533:":["1f238"],":u7121:":["1f21a-fe0f","1f21a"],":u6709:":["1f236"],":u7981:":["1f232"],":u6e80:":["1f235"],":u5408:":["1f234"],":congratulations:":["3297-fe0f","3297"],":secret:":["3299-fe0f","3299"],":white_flower:":["1f4ae"],":ideograph_advantage:":["1f250"],":accept:":["1f251"],":piracy:":["1f572"],":no_piracy:":["1f572"],":underage:":["1f51e"],":no_mobile_phones:":["1f4f5"],":non-potable_water:":["1f6b1"],":no_bicycles:":["1f6b3"],":do_not_litter:":["1f6af"],":no_pedestrians:":["1f6b7"],":name_badge:":["1f4db"],":no_entry:":["26d4-fe0f","26d4"],":no_entry_sign:":["1f6ab"],":prohibited:":["1f6c7"],":prohibited_sign:":["1f6c7"],":sleeping_accommodation:":["1f6cc"],":speaking_head:":["1f5e3"],":speaking_head_in_silhouette:":["1f5e3"],":mag_right:":["1f50e"],":mag:":["1f50d"],":shield:":["1f6e1"],":children_crossing:":["1f6b8"],":mood_bubble_lightning:":["1f5f1"],":lightning_mood_bubble:":["1f5f1"],":mood_bubble:":["1f5f0"],":anger_right:":["1f5ef"],":right_anger_bubble:":["1f5ef"],":anger_left:":["1f5ee"],":left_anger_bubble:":["1f5ee"],":thought_right:":["1f5ed"],":right_thought_bubble:":["1f5ed"],":thought_left:":["1f5ec"],":left_thought_bubble:":["1f5ec"],":speech_three:":["1f5eb"],":three_speech_bubbles:":["1f5eb"],":speech_two:":["1f5ea"],":two_speech_bubbles:":["1f5ea"],":speech_right:":["1f5e9"],":right_speech_bubble:":["1f5e9"],":speech_left:":["1f5e8"],":left_speech_bubble:":["1f5e8"],":speech_balloon:":["1f4ac"],":thought_balloon:":["1f4ad"],":dove:":["1f54a"],":dove_of_peace:":["1f54a"],":om_symbol:":["1f549"],":celtic_cross:":["1f548"],":cross_heavy:":["1f547"],":heavy_latin_cross:":["1f547"],":cross_white:":["1f546"],":white_latin_cross:":["1f546"],":descending_notes:":["1f39d"],":ascending_notes:":["1f39c"],":ringing_bell:":["1f56d"],":no_bell:":["1f515"],":bell:":["1f514"],":zzz:":["1f4a4"],":bullhorn_waves:":["1f56c"],":bullhorn_with_sound_waves:":["1f56c"],":bullhorn:":["1f56b"],":right_speaker_three:":["1f56a"],":right_speaker_with_three_sound_waves:":["1f56a"],":right_speaker_one:":["1f569"],":right_speaker_with_one_sound_wave:":["1f569"],":right_speaker:":["1f568"],":mute:":["1f507"],":loud_sound:":["1f50a"],":sound:":["1f509"],":speaker:":["1f508"],":loudspeaker:":["1f4e2"],":mega:":["1f4e3"],":unlock:":["1f513"],":lock:":["1f512"],":closed_lock_with_key:":["1f510"],":lock_with_ink_pen:":["1f50f"],":pencil:":["1f4dd"],":crayon:":["1f58d"],":lower_left_crayon:":["1f58d"],":paintbrush:":["1f58c"],":lower_left_paintbrush:":["1f58c"],":pen_fountain:":["1f58b"],":lower_left_fountain_pen:":["1f58b"],":pen_ballpoint:":["1f58a"],":lower_left_ballpoint_pen:":["1f58a"],":pencil3:":["1f589"],":lower_left_pencil:":["1f589"],":pencil2:":["270f-fe0f","270f"],":black_nib:":["2712-fe0f","2712"],":file_cabinet:":["1f5c4"],":open_file_folder:":["1f4c2"],":file_folder:":["1f4c1"],":folder_open:":["1f5c1"],":open_folder:":["1f5c1"],":folder:":["1f5c0"],":hole:":["1f573"],":flag_black:":["1f3f4"],":waving_black_flag:":["1f3f4"],":flag_white:":["1f3f3"],":waving_white_flag:":["1f3f3"],":pennant_black:":["1f3f2"],":black_pennant:":["1f3f2"],":pennant_white:":["1f3f1"],":white_pennant:":["1f3f1"],":triangular_flag_on_post:":["1f6a9"],":straight_ruler:":["1f4cf"],":round_pushpin:":["1f4cd"],":triangular_ruler:":["1f4d0"],":scissors:":["2702-fe0f","2702"],":pushpin_black:":["1f588"],":pushpin:":["1f4cc"],":paperclips:":["1f587"],":linked_paperclips:":["1f587"],":paperclip:":["1f4ce"],":link:":["1f517"],":card_box:":["1f5c3"],":card_file_box:":["1f5c3"],":dividers:":["1f5c2"],":card_index_dividers:":["1f5c2"],":card_index:":["1f4c7"],":books:":["1f4da"],":orange_book:":["1f4d9"],":blue_book:":["1f4d8"],":green_book:":["1f4d7"],":closed_book:":["1f4d5"],":ledger:":["1f4d2"],":notebook_with_decorative_cover:":["1f4d4"],":notebook:":["1f4d3"],":book:":["1f4d6"],":book2:":["1f56e"],":clipboard:":["1f4cb"],":scroll:":["1f4dc"],":frame_tiles:":["1f5bd"],":frame_with_tiles:":["1f5bd"],":frame_photo:":["1f5bc"],":frame_with_picture:":["1f5bc"],":frame_x:":["1f5be"],":frame_with_an_x:":["1f5be"],":compression:":["1f5dc"],":high_brightness:":["1f506"],":low_brightness:":["1f505"],":ballot_box:":["1f5f3"],":ballot_box_with_ballot:":["1f5f3"],":calendar_spiral:":["1f5d3"],":spiral_calendar_pad:":["1f5d3"],":calendar:":["1f4c6"],":date:":["1f4c5"],":stock_chart:":["1f5e0"],":bar_chart:":["1f4ca"],":chart_with_downwards_trend:":["1f4c9"],":chart_with_upwards_trend:":["1f4c8"],":notepad-spiral:":["1f5d2"],":spiral_note_pad:":["1f5d2"],":notepad:":["1f5ca"],":note_pad:":["1f5ca"],":note:":["1f5c9"],":note_page:":["1f5c9"],":notepad_empty:":["1f5c7"],":empty_note_pad:":["1f5c7"],":note_empty:":["1f5c6"],":empty_note_page:":["1f5c6"],":wastebasket:":["1f5d1"],":bookmark_tabs:":["1f4d1"],":pages:":["1f5d0"],":page_with_curl:":["1f4c3"],":page_facing_up:":["1f4c4"],":page:":["1f5cf"],":document_text:":["1f5b9"],":document_with_text:":["1f5b9"],":document:":["1f5ce"],":mailbox_with_mail:":["1f4ec"],":mailbox_with_no_mail:":["1f4ed"],":mailbox:":["1f4eb"],":mailbox_closed:":["1f4ea"],":postbox:":["1f4ee"],":postal_horn:":["1f4ef"],":package:":["1f4e6"],":outbox_tray:":["1f4e4"],":inbox_tray:":["1f4e5"],":e-mail:":["1f4e7"],":email:":["1f4e7"],":incoming_envelope:":["1f4e8"],":envelope_with_arrow:":["1f4e9"],":envelope_stamped_pen:":["1f586"],":pen_over_stamped_envelope:":["1f586"],":envelope_flying:":["1f585"],":flying_envelope:":["1f585"],":envelope_stamped:":["1f583"],":stamped_envelope:":["1f583"],":envelope_back:":["1f582"],":back_of_envelope:":["1f582"],":envelope:":["2709-fe0f","2709"],":key2:":["1f5dd"],":old_key:":["1f5dd"],":key:":["1f511"],":label:":["1f3f7"],":thermometer:":["1f321"],":newspaper2:":["1f5de"],":rolled_up_newspaper:":["1f5de"],":newspaper:":["1f4f0"],":bookmark:":["1f516"],":gun:":["1f52b"],":crossbones:":["1f571"],":black_skull_and_crossbones:":["1f571"],":smoking:":["1f6ac"],":bomb:":["1f4a3"],":oil:":["1f6e2"],":oil_drum:":["1f6e2"],":tools:":["1f6e0"],":hammer_and_wrench:":["1f6e0"],":hammer:":["1f528"],":nut_and_bolt:":["1f529"],":dagger:":["1f5e1"],":dagger_knife:":["1f5e1"],":knife:":["1f52a"],":wrench:":["1f527"],":crystal_ball:":["1f52e"],":telescope:":["1f52d"],":microscope:":["1f52c"],":pill:":["1f48a"],":syringe:":["1f489"],":barber:":["1f488"],":toilet:":["1f6bd"],":bathtub:":["1f6c1"],":shower:":["1f6bf"],":door:":["1f6aa"],":jeans:":["1f456"],":necktie:":["1f454"],":shirt:":["1f455"],":womans_clothes:":["1f45a"],":kimono:":["1f458"],":dress:":["1f457"],":bikini:":["1f459"],":athletic_shoe:":["1f45f"],":mans_shoe:":["1f45e"],":boot:":["1f462"],":high_heel:":["1f460"],":sandal:":["1f461"],":womans_hat:":["1f452"],":dark_sunglasses:":["1f576"],":eyeglasses:":["1f453"],":lipstick:":["1f484"],":school_satchel:":["1f392"],":briefcase:":["1f4bc"],":handbag:":["1f45c"],":purse:":["1f45b"],":pouch:":["1f45d"],":closed_umbrella:":["1f302"],":gem:":["1f48e"],":moneybag:":["1f4b0"],":money_with_wings:":["1f4b8"],":credit_card:":["1f4b3"],":satellite_orbital:":["1f6f0"],":satellite:":["1f4e1"],":candle:":["1f56f"],":flashlight:":["1f526"],":bulb:":["1f4a1"],":electric_plug:":["1f50c"],":battery:":["1f50b"],":vhs:":["1f4fc"],":optical_disk:":["1f5b8"],":optical_disc_icon:":["1f5b8"],":dvd:":["1f4c0"],":cd:":["1f4bf"],":hard_disk:":["1f5b4"],":cartridge:":["1f5ad"],":tape_cartridge:":["1f5ad"],":floppy_white:":["1f5ab"],":white_hard_shell_floppy_disk:":["1f5ab"],":floppy_black:":["1f5aa"],":black_hard_shell_floppy_disk:":["1f5aa"],":floppy_disk:":["1f4be"],":minidisc:":["1f4bd"],":fax:":["1f4e0"],":flip_phone:":["1f581"],":clamshell_mobile_phone:":["1f581"],":telephone_black:":["1f57f"],":black_touchtone_telephone:":["1f57f"],":telephone_white:":["1f57e"],":white_touchtone_telephone:":["1f57e"],":telephone:":["260e-fe0f","260e"],":left_receiver:":["1f57b"],":left_hand_telephone_receiver:":["1f57b"],":telephone_receiver:":["1f4de"],":joystick:":["1f579"],":pager:":["1f4df"],":stereo:":["1f4fe"],":portable_stereo:":["1f4fe"],":radio:":["1f4fb"],":control_knobs:":["1f39b"],":level_slider:":["1f39a"],":microphone2:":["1f399"],":studio_microphone:":["1f399"],":keyboard_with_jacks:":["1f398"],":musical_keyboard_with_jacks:":["1f398"],":tv:":["1f4fa"],":projector:":["1f4fd"],":film_projector:":["1f4fd"],":movie_camera:":["1f3a5"],":video_camera:":["1f4f9"],":camera_with_flash:":["1f4f8"],":camera:":["1f4f7"],":hourglass:":["231b-fe0f","231b"],":hourglass_flowing_sand:":["23f3"],":clock:":["1f570"],":mantlepiece_clock:":["1f570"],":alarm_clock:":["23f0"],":calculator:":["1f5a9"],":pocket calculator:":["1f5a9"],":desktop_window:":["1f5d4"],":printer:":["1f5a8"],":network:":["1f5a7"],":three_networked_computers:":["1f5a7"],":keyboard_mouse:":["1f5a6"],":keyboard_and_mouse:":["1f5a6"],":trackball:":["1f5b2"],":mouse-one:":["1f5af"],":one_button_mouse:":["1f5af"],":keyboard:":["1f5ae"],":wired_keyboard:":["1f5ae"],":computer_old:":["1f5b3"],":old_personal_computer:":["1f5b3"],":desktop:":["1f5a5"],":desktop_computer:":["1f5a5"],":computer:":["1f4bb"],":calling:":["1f4f2"],":iphone:":["1f4f1"],":watch:":["231a-fe0f","231a"],":baby_bottle:":["1f37c"],":beers:":["1f37b"],":beer:":["1f37a"],":tropical_drink:":["1f379"],":cocktail:":["1f378"],":wine_glass:":["1f377"],":sake:":["1f376"],":coffee:":["2615-fe0f","2615"],":tea:":["1f375"],":fork_and_knife:":["1f374"],":egg:":["1f373"],":stew:":["1f372"],":bento:":["1f371"],":cake:":["1f370"],":honey_pot:":["1f36f"],":custard:":["1f36e"],":lollipop:":["1f36d"],":candy:":["1f36c"],":chocolate_bar:":["1f36b"],":cookie:":["1f36a"],":doughnut:":["1f369"],":ice_cream:":["1f368"],":shaved_ice:":["1f367"],":icecream:":["1f366"],":fish_cake:":["1f365"],":fried_shrimp:":["1f364"],":sushi:":["1f363"],":oden:":["1f362"],":dango:":["1f361"],":fries:":["1f35f"],":bread:":["1f35e"],":spaghetti:":["1f35d"],":ramen:":["1f35c"],":curry:":["1f35b"],":rice:":["1f35a"],":rice_ball:":["1f359"],":rice_cracker:":["1f358"],":poultry_leg:":["1f357"],":meat_on_bone:":["1f356"],":pizza:":["1f355"],":hamburger:":["1f354"],":strawberry:":["1f353"],":cherries:":["1f352"],":peach:":["1f351"],":pear:":["1f350"],":green_apple:":["1f34f"],":apple:":["1f34e"],":pineapple:":["1f34d"],":banana:":["1f34c"],":lemon:":["1f34b"],":tangerine:":["1f34a"],":watermelon:":["1f349"],":melon:":["1f348"],":grapes:":["1f347"],":hot_pepper:":["1f336"],":sweet_potato:":["1f360"],":corn:":["1f33d"],":eggplant:":["1f346"],":tomato:":["1f345"],":roller_coaster:":["1f3a2"],":ferris_wheel:":["1f3a1"],":carousel_horse:":["1f3a0"],":mahjong:":["1f004-fe0f","1f004"],":black_joker:":["1f0cf"],":flower_playing_cards:":["1f3b4"],":video_game:":["1f3ae"],":game_die:":["1f3b2"],":slot_machine:":["1f3b0"],":bowling:":["1f3b3"],":8ball:":["1f3b1"],":dart:":["1f3af"],":art:":["1f3a8"],":tickets:":["1f39f"],":admission_tickets:":["1f39f"],":film_frames:":["1f39e"],":clapper:":["1f3ac"],":circus_tent:":["1f3aa"],":tophat:":["1f3a9"],":ticket:":["1f3ab"],":performing_arts:":["1f3ad"],
":microphone:":["1f3a4"],":headphones:":["1f3a7"],":musical_score:":["1f3bc"],":notes:":["1f3b6"],":musical_note:":["1f3b5"],":trumpet:":["1f3ba"],":saxophone:":["1f3b7"],":violin:":["1f3bb"],":guitar:":["1f3b8"],":musical_keyboard:":["1f3b9"],":checkered_flag:":["1f3c1"],":running_shirt_with_sash:":["1f3bd"],":medal:":["1f3c5"],":sports_medal:":["1f3c5"],":trophy:":["1f3c6"],":golf:":["26f3-fe0f","26f3"],":rugby_football:":["1f3c9"],":tennis:":["1f3be"],":baseball:":["26be-fe0f","26be"],":football:":["1f3c8"],":basketball:":["1f3c0"],":soccer:":["26bd-fe0f","26bd"],":fishing_pole_and_fish:":["1f3a3"],":tent:":["26fa-fe0f","26fa"],":horse_racing:":["1f3c7"],":race_car:":["1f3ce"],":racing_car:":["1f3ce"],":motorcycle:":["1f3cd"],":racing_motorcycle:":["1f3cd"],":mountain_bicyclist:":["1f6b5"],":bicyclist:":["1f6b4"],":snowman:":["26c4-fe0f","26c4"],":ski:":["1f3bf"],":snowboarder:":["1f3c2"],":bath:":["1f6c0"],":surfer:":["1f3c4"],":swimmer:":["1f3ca"],":rowboat:":["1f6a3"],":golfer:":["1f3cc"],":lifter:":["1f3cb"],":weight_lifter:":["1f3cb"],":dancer:":["1f483"],":walking:":["1f6b6"],":runner:":["1f3c3"],":blue_heart:":["1f499"],":green_heart:":["1f49a"],":yellow_heart:":["1f49b"],":purple_heart:":["1f49c"],":heart_decoration:":["1f49f"],":heart_tip:":["1f394"],":heart_with_tip_on_the_left:":["1f394"],":gift_heart:":["1f49d"],":cupid:":["1f498"],":sparkling_heart:":["1f496"],":heartpulse:":["1f497"],":heartbeat:":["1f493"],":revolving_hearts:":["1f49e"],":two_hearts:":["1f495"],":love_letter:":["1f48c"],":broken_heart:":["1f494"],":heart:":["2764-fe0f","2764"],":bouquet2:":["1f395"],":bouquet_of_flowers:":["1f395"],":ring:":["1f48d"],":izakaya_lantern:":["1f3ee"],":crossed_flags:":["1f38c"],":wind_chime:":["1f390"],":flags:":["1f38f"],":dolls:":["1f38e"],":military_medal:":["1f396"],":reminder_ribbon:":["1f397"],":crown:":["1f451"],":mortar_board:":["1f393"],":boom:":["1f4a5"],":sparkles:":["2728"],":dizzy:":["1f4ab"],":balloon:":["1f388"],":confetti_ball:":["1f38a"],":tada:":["1f389"],":sparkler:":["1f387"],":fireworks:":["1f386"],":rice_scene:":["1f391"],":bamboo:":["1f38d"],":tanabata_tree:":["1f38b"],":christmas_tree:":["1f384"],":jack_o_lantern:":["1f383"],":birthday:":["1f382"],":gift:":["1f381"],":ribbon:":["1f380"],":wind_blowing_face:":["1f32c"],":sun_with_face:":["1f31e"],":last_quarter_moon_with_face:":["1f31c"],":first_quarter_moon_with_face:":["1f31b"],":full_moon_with_face:":["1f31d"],":new_moon_with_face:":["1f31a"],":waning_crescent_moon:":["1f318"],":last_quarter_moon:":["1f317"],":waning_gibbous_moon:":["1f316"],":full_moon:":["1f315"],":waxing_gibbous_moon:":["1f314"],":first_quarter_moon:":["1f313"],":waxing_crescent_moon:":["1f312"],":new_moon:":["1f311"],":earth_asia:":["1f30f"],":earth_americas:":["1f30e"],":earth_africa:":["1f30d"],":globe_with_meridians:":["1f310"],":japan:":["1f5fe"],":mount_fuji:":["1f5fb"],":milky_way:":["1f30c"],":volcano:":["1f30b"],":ocean:":["1f30a"],":rainbow:":["1f308"],":sunrise:":["1f305"],":sunrise_over_mountains:":["1f304"],":stars:":["1f320"],":star:":["2b50-fe0f","2b50"],":star2:":["1f31f"],":snowflake:":["2744-fe0f","2744"],":dash:":["1f4a8"],":fog:":["1f32b"],":umbrella:":["2614-fe0f","2614"],":sweat_drops:":["1f4a6"],":droplet:":["1f4a7"],":cloud_tornado:":["1f32a"],":cloud_with_tornado:":["1f32a"],":cloud_lightning:":["1f329"],":cloud_with_lightning:":["1f329"],":cloud_snow:":["1f328"],":cloud_with_snow:":["1f328"],":cloud_rain:":["1f327"],":cloud_with_rain:":["1f327"],":cloud:":["2601-fe0f","2601"],":partly_sunny:":["26c5-fe0f","26c5"],":sunny:":["2600-fe0f","2600"],":crescent_moon:":["1f319"],":fire:":["1f525"],":flame:":["1f525"],":zap:":["26a1-fe0f","26a1"],":feet:":["1f43e"],":spider_web:":["1f578"],":spider:":["1f577"],":beetle:":["1f41e"],":bee:":["1f41d"],":ant:":["1f41c"],":bug:":["1f41b"],":snail:":["1f40c"],":shell:":["1f41a"],":blowfish:":["1f421"],":tropical_fish:":["1f420"],":fish:":["1f41f"],":octopus:":["1f419"],":dolphin:":["1f42c"],":whale:":["1f433"],":whale2:":["1f40b"],":frog:":["1f438"],":turtle:":["1f422"],":snake:":["1f40d"],":crocodile:":["1f40a"],":dragon_face:":["1f432"],":dragon:":["1f409"],":monkey:":["1f412"],":speak_no_evil:":["1f64a"],":hear_no_evil:":["1f649"],":see_no_evil:":["1f648"],":monkey_face:":["1f435"],":panda_face:":["1f43c"],":koala:":["1f428"],":bear:":["1f43b"],":wolf:":["1f43a"],":dog:":["1f436"],":poodle:":["1f429"],":dog2:":["1f415"],":pig_nose:":["1f43d"],":pig:":["1f437"],":pig2:":["1f416"],":boar:":["1f417"],":camel:":["1f42b"],":dromedary_camel:":["1f42a"],":elephant:":["1f418"],":penguin:":["1f427"],":bird:":["1f426"],":hatched_chick:":["1f425"],":hatching_chick:":["1f423"],":baby_chick:":["1f424"],":chicken:":["1f414"],":rooster:":["1f413"],":goat:":["1f410"],":sheep:":["1f411"],":ram:":["1f40f"],":horse:":["1f434"],":racehorse:":["1f40e"],":cat:":["1f431"],":cat2:":["1f408"],":rabbit:":["1f430"],":rabbit2:":["1f407"],":chipmunk:":["1f43f"],":tiger:":["1f42f"],":leopard:":["1f406"],":tiger2:":["1f405"],":cow:":["1f42e"],":cow2:":["1f404"],":water_buffalo:":["1f403"],":ox:":["1f402"],":hamster:":["1f439"],":mouse:":["1f42d"],":mouse2:":["1f401"],":rat:":["1f400"],":chestnut:":["1f330"],":mushroom:":["1f344"],":leaves:":["1f343"],":fallen_leaf:":["1f342"],":maple_leaf:":["1f341"],":four_leaf_clover:":["1f340"],":herb:":["1f33f"],":ear_of_rice:":["1f33e"],":bouquet:":["1f490"],":blossom:":["1f33c"],":sunflower:":["1f33b"],":hibiscus:":["1f33a"],":rose:":["1f339"],":cherry_blossom:":["1f338"],":tulip:":["1f337"],":cactus:":["1f335"],":palm_tree:":["1f334"],":deciduous_tree:":["1f333"],":evergreen_tree:":["1f332"],":seedling:":["1f331"],":pray:":["1f64f"],":finger_pointing_down2:":["1f59f"],":sideways_white_down_pointing_index:":["1f59f"],":finger_pointing_up:":["1f59e"],":sideways_white_up_pointing_index:":["1f59e"],":finger_pointing_right:":["1f599"],":sideways_white_right_pointing_index:":["1f599"],":finger_pointing_left:":["1f598"],":sideways_white_left_pointing_index:":["1f598"],":finger_pointing_down:":["1f597"],":white_down_pointing_left_hand_index:":["1f597"],":vulcan:":["1f596"],":raised_hand_with_part_between_middle_and_ring_fingers:":["1f596"],":middle_finger:":["1f595"],":reversed_hand_with_middle_finger_extended:":["1f595"],":hand_victory:":["1f594"],":reversed_victory_hand:":["1f594"],":thumbs_down_reverse:":["1f593"],":reversed_thumbs_down_sign:":["1f593"],":thumbs_up_reverse:":["1f592"],":reversed_thumbs_up_sign:":["1f592"],":hand_splayed_reverse:":["1f591"],":reversed_raised_hand_with_fingers_splayed:":["1f591"],":hand_splayed:":["1f590"],":raised_hand_with_fingers_splayed:":["1f590"],":turned_ok_hand:":["1f58f"],":turned_ok_hand_sign:":["1f58f"],":writing_hand:":["1f58e"],":left_writing_hand:":["1f58e"],":open_hands:":["1f450"],":muscle:":["1f4aa"],":raised_hand:":["270b"],":fist:":["270a"],":punch:":["1f44a"],":v:":["270c-fe0f","270c"],":ok_hand:":["1f44c"],":point_right:":["1f449"],":point_left:":["1f448"],":point_down:":["1f447"],":point_up_2:":["1f446"],":point_up:":["261d-fe0f","261d"],":thumbsdown:":["1f44e"],":-1:":["1f44e"],":thumbsup:":["1f44d"],":+1:":["1f44d"],":wave:":["1f44b"],":nail_care:":["1f485"],":tongue:":["1f445"],":kiss:":["1f48b"],":lips2:":["1f5e2"],":lips:":["1f444"],":nose:":["1f443"],":eyes:":["1f440"],":eye:":["1f441"],":ear:":["1f442"],":clap:":["1f44f"],":raised_hands:":["1f64c"],":kiss_mm:":["1f468-200d-2764-fe0f-200d-1f48b-200d-1f468","1f468-2764-1f48b-1f468"],":couplekiss_mm:":["1f468-2764-1f48b-1f468"],":kiss_ww:":["1f469-200d-2764-fe0f-200d-1f48b-200d-1f469","1f469-2764-1f48b-1f469"],":couplekiss_ww:":["1f469-2764-1f48b-1f469"],":couplekiss:":["1f48f"],":couple_mm:":["1f468-200d-2764-fe0f-200d-1f468","1f468-2764-1f468"],":couple_with_heart_mm:":["1f468-2764-1f468"],":couple_ww:":["1f469-200d-2764-fe0f-200d-1f469","1f469-2764-1f469"],":couple_with_heart_ww:":["1f469-2764-1f469"],":couple_with_heart:":["1f491"],":haircut:":["1f487"],":massage:":["1f486"],":person_frowning:":["1f64d"],":person_with_pouting_face:":["1f64e"],":raising_hand:":["1f64b"],":ok_woman:":["1f646"],":no_good:":["1f645"],":information_desk_person:":["1f481"],":bow:":["1f647"],":space_invader:":["1f47e"],":alien:":["1f47d"],":skull:":["1f480"],":skeleton:":["1f480"],":poop:":["1f4a9"],":shit:":["1f4a9"],":hankey:":["1f4a9"],":poo:":["1f4a9"],":japanese_goblin:":["1f47a"],":japanese_ogre:":["1f479"],":ghost:":["1f47b"],":santa:":["1f385"],":angel:":["1f47c"],":guardsman:":["1f482"],":princess:":["1f478"],":construction_worker:":["1f477"],":cop:":["1f46e"],":older_woman:":["1f475"],":grandma:":["1f475"],":older_man:":["1f474"],":man_with_turban:":["1f473"],":man_with_gua_pi_mao:":["1f472"],":person_with_blond_hair:":["1f471"],":bride_with_veil:":["1f470"],":dancers:":["1f46f"],":two_women_holding_hands:":["1f46d"],":two_men_holding_hands:":["1f46c"],":couple:":["1f46b"],":family_mmgg:":["1f468-200d-1f468-200d-1f467-200d-1f467","1f468-1f468-1f467-1f467"],":family_mmbb:":["1f468-200d-1f468-200d-1f466-200d-1f466","1f468-1f468-1f466-1f466"],":family_mmgb:":["1f468-200d-1f468-200d-1f467","1f468-1f468-1f467-1f466"],":family_mmg:":["1f468-200d-1f468-200d-1f467","1f468-1f468-1f467"],":family_mmb:":["1f468-200d-1f468-200d-1f466","1f468-1f468-1f466"],":family_wwgg:":["1f469-200d-1f469-200d-1f467-200d-1f467","1f469-1f469-1f467-1f467"],":family_wwbb:":["1f469-200d-1f469-200d-1f466-200d-1f466","1f469-1f469-1f466-1f466"],":family_wwgb:":["1f469-200d-1f469-200d-1f467-200d-1f466","1f469-1f469-1f467-1f466"],":family_wwg:":["1f469-200d-1f469-200d-1f467","1f469-1f469-1f467"],":family_wwb:":["1f469-200d-1f469-200d-1f466","1f469-1f469-1f466"],":family_mwgg:":["1f468-200d-1f469-200d-1f467-200d-1f467","1f468-1f469-1f467-1f467"],":family_mwbb:":["1f468-200d-1f469-200d-1f466-200d-1f466","1f468-1f469-1f466-1f466"],":family_mwgb:":["1f468-200d-1f469-200d-1f467-200d-1f466","1f468-1f469-1f467-1f466"],":family_mwg:":["1f468-200d-1f469-200d-1f467","1f468-1f469-1f467"],":family:":["1f46a"],":woman:":["1f469"],":man:":["1f468"],":girl:":["1f467"],":boy:":["1f466"],":baby:":["1f476"],":spy:":["1f575"],":sleuth_or_spy:":["1f575"],":levitate:":["1f574"],":man_in_business_suit_levitating:":["1f574"],":busts_in_silhouette:":["1f465"],":bust_in_silhouette:":["1f464"],":footprints:":["1f463"],":scream_cat:":["1f640"],":crying_cat_face:":["1f63f"],":pouting_cat:":["1f63e"],":kissing_cat:":["1f63d"],":smirk_cat:":["1f63c"],":heart_eyes_cat:":["1f63b"],":smiley_cat:":["1f63a"],":joy_cat:":["1f639"],":smile_cat:":["1f638"],":slight_smile:":["1f642"],":slightly_smiling_face:":["1f642"],":slight_frown:":["1f641"],":slightly_frowning_face:":["1f641"],":mask:":["1f637"],":no_mouth:":["1f636"],":dizzy_face:":["1f635"],":sleeping:":["1f634"],":flushed:":["1f633"],":astonished:":["1f632"],":scream:":["1f631"],":cold_sweat:":["1f630"],":hushed:":["1f62f"],":open_mouth:":["1f62e"],":sob:":["1f62d"],":grimacing:":["1f62c"],":tired_face:":["1f62b"],":sleepy:":["1f62a"],":weary:":["1f629"],":fearful:":["1f628"],":anguished:":["1f627"],":frowning:":["1f626"],":disappointed_relieved:":["1f625"],":triumph:":["1f624"],":persevere:":["1f623"],":cry:":["1f622"],":rage:":["1f621"],":angry:":["1f620"],":worried:":["1f61f"],":disappointed:":["1f61e"],":stuck_out_tongue_closed_eyes:":["1f61d"],":stuck_out_tongue_winking_eye:":["1f61c"],":stuck_out_tongue:":["1f61b"],":kissing_closed_eyes:":["1f61a"],":kissing_smiling_eyes:":["1f619"],":kissing_heart:":["1f618"],":kissing:":["1f617"],":confounded:":["1f616"],":confused:":["1f615"],":pensive:":["1f614"],":sweat:":["1f613"],":unamused:":["1f612"],":expressionless:":["1f611"],":neutral_face:":["1f610"],":smirk:":["1f60f"],":sunglasses:":["1f60e"],":heart_eyes:":["1f60d"],":relieved:":["1f60c"],":yum:":["1f60b"],":relaxed:":["263a-fe0f","263a"],":blush:":["1f60a"],":wink:":["1f609"],":imp:":["1f47f"],":smiling_imp:":["1f608"],":innocent:":["1f607"],":laughing:":["1f606"],":satisfied:":["1f606"],":sweat_smile:":["1f605"],":smile:":["1f604"],":smiley:":["1f603"],":joy:":["1f602"],":grin:":["1f601"],":grinning:":["1f600"]},a.asciiList={"<3":"2764","</3":"1f494",":')":"1f602",":'-)":"1f602",":D":"1f603",":-D":"1f603","=D":"1f603",":)":"1f604",":-)":"1f604","=]":"1f604","=)":"1f604",":]":"1f604","':)":"1f605","':-)":"1f605","'=)":"1f605","':D":"1f605","':-D":"1f605","'=D":"1f605",">:)":"1f606",">;)":"1f606",">:-)":"1f606",">=)":"1f606",";)":"1f609",";-)":"1f609","*-)":"1f609","*)":"1f609",";-]":"1f609",";]":"1f609",";D":"1f609",";^)":"1f609","':(":"1f613","':-(":"1f613","'=(":"1f613",":*":"1f618",":-*":"1f618","=*":"1f618",":^*":"1f618",">:P":"1f61c","X-P":"1f61c","x-p":"1f61c",">:[":"1f61e",":-(":"1f61e",":(":"1f61e",":-[":"1f61e",":[":"1f61e","=(":"1f61e",">:(":"1f620",">:-(":"1f620",":@":"1f620",":'(":"1f622",":'-(":"1f622",";(":"1f622",";-(":"1f622",">.<":"1f623",":$":"1f633","=$":"1f633","#-)":"1f635","#)":"1f635","%-)":"1f635","%)":"1f635","X)":"1f635","X-)":"1f635","*\\0/*":"1f646","\\0/":"1f646","*\\O/*":"1f646","\\O/":"1f646","O:-)":"1f607","0:-3":"1f607","0:3":"1f607","0:-)":"1f607","0:)":"1f607","0;^)":"1f607","O:)":"1f607","O;-)":"1f607","O=)":"1f607","0;-)":"1f607","O:-3":"1f607","O:3":"1f607","B-)":"1f60e","B)":"1f60e","8)":"1f60e","8-)":"1f60e","B-D":"1f60e","8-D":"1f60e","-_-":"1f611","-__-":"1f611","-___-":"1f611",">:\\":"1f615",">:/":"1f615",":-/":"1f615",":-.":"1f615",":/":"1f615",":\\":"1f615","=/":"1f615","=\\":"1f615",":L":"1f615","=L":"1f615",":P":"1f61b",":-P":"1f61b","=P":"1f61b",":-p":"1f61b",":p":"1f61b","=p":"1f61b",":-Þ":"1f61b",":Þ":"1f61b",":þ":"1f61b",":-þ":"1f61b",":-b":"1f61b",":b":"1f61b","d:":"1f61b",":-O":"1f62e",":O":"1f62e",":-o":"1f62e",":o":"1f62e",O_O:"1f62e",">:O":"1f62e",":-X":"1f636",":X":"1f636",":-#":"1f636",":#":"1f636","=X":"1f636","=x":"1f636",":x":"1f636",":-x":"1f636","=#":"1f636"},a.asciiRegexp="(\\<3|&lt;3|\\<\\/3|&lt;\\/3|\\:'\\)|\\:'\\-\\)|\\:D|\\:\\-D|\\=D|\\:\\)|\\:\\-\\)|\\=\\]|\\=\\)|\\:\\]|'\\:\\)|'\\:\\-\\)|'\\=\\)|'\\:D|'\\:\\-D|'\\=D|\\>\\:\\)|&gt;\\:\\)|\\>;\\)|&gt;;\\)|\\>\\:\\-\\)|&gt;\\:\\-\\)|\\>\\=\\)|&gt;\\=\\)|;\\)|;\\-\\)|\\*\\-\\)|\\*\\)|;\\-\\]|;\\]|;D|;\\^\\)|'\\:\\(|'\\:\\-\\(|'\\=\\(|\\:\\*|\\:\\-\\*|\\=\\*|\\:\\^\\*|\\>\\:P|&gt;\\:P|X\\-P|x\\-p|\\>\\:\\[|&gt;\\:\\[|\\:\\-\\(|\\:\\(|\\:\\-\\[|\\:\\[|\\=\\(|\\>\\:\\(|&gt;\\:\\(|\\>\\:\\-\\(|&gt;\\:\\-\\(|\\:@|\\:'\\(|\\:'\\-\\(|;\\(|;\\-\\(|\\>\\.\\<|&gt;\\.&lt;|\\:\\$|\\=\\$|#\\-\\)|#\\)|%\\-\\)|%\\)|X\\)|X\\-\\)|\\*\\\\0\\/\\*|\\\\0\\/|\\*\\\\O\\/\\*|\\\\O\\/|O\\:\\-\\)|0\\:\\-3|0\\:3|0\\:\\-\\)|0\\:\\)|0;\\^\\)|O\\:\\-\\)|O\\:\\)|O;\\-\\)|O\\=\\)|0;\\-\\)|O\\:\\-3|O\\:3|B\\-\\)|B\\)|8\\)|8\\-\\)|B\\-D|8\\-D|\\-_\\-|\\-__\\-|\\-___\\-|\\>\\:\\\\|&gt;\\:\\\\|\\>\\:\\/|&gt;\\:\\/|\\:\\-\\/|\\:\\-\\.|\\:\\/|\\:\\\\|\\=\\/|\\=\\\\|\\:L|\\=L|\\:P|\\:\\-P|\\=P|\\:\\-p|\\:p|\\=p|\\:\\-Þ|\\:\\-&THORN;|\\:Þ|\\:&THORN;|\\:þ|\\:&thorn;|\\:\\-þ|\\:\\-&thorn;|\\:\\-b|\\:b|d\\:|\\:\\-O|\\:O|\\:\\-o|\\:o|O_O|\\>\\:O|&gt;\\:O|\\:\\-X|\\:X|\\:\\-#|\\:#|\\=X|\\=x|\\:x|\\:\\-x|\\=#)",a.unicodeRegexp="(\\u2049|\\u2122|\\u2139|\\u2194|\\u2195|\\u2196|\\u2197|\\u2198|\\u2199|\\u2600|\\u2601|\\u2611|\\u2614|\\u2615|\\u2648|\\u2649|\\u2650|\\u2651|\\u2652|\\u2653|\\u2660|\\u2663|\\u2665|\\u2666|\\u2668|\\u2693|\\u2702|\\u2705|\\u2708|\\u2709|\\u2712|\\u2714|\\u2716|\\u2728|\\u2733|\\u2734|\\u2744|\\u2747|\\u2753|\\u2754|\\u2755|\\u2757|\\u2764|\\u2795|\\u2796|\\u2797|\\u2934|\\u2935|\\u3030|\\u3297|\\u3299|\\uD83C\\uDDFF\\uD83C\\uDDFC|\\uD83C\\uDDFF\\uD83C\\uDDF2|\\uD83C\\uDDFE\\uD83C\\uDDEA|\\uD83C\\uDDEA\\uD83C\\uDDED|\\uD83C\\uDDFC\\uD83C\\uDDEB|\\uD83C\\uDDFB\\uD83C\\uDDEA|\\uD83C\\uDDFB\\uD83C\\uDDE6|\\uD83C\\uDDFB\\uD83C\\uDDFA|\\uD83C\\uDDFA\\uD83C\\uDDFF|\\uD83C\\uDDFA\\uD83C\\uDDFE|\\uD83C\\uDDFA\\uD83C\\uDDE6|\\uD83C\\uDDFA\\uD83C\\uDDEC|\\uD83C\\uDDFB\\uD83C\\uDDEE|\\uD83C\\uDDF9\\uD83C\\uDDFB|\\uD83C\\uDDF9\\uD83C\\uDDF2|\\uD83C\\uDDF9\\uD83C\\uDDF3|\\uD83C\\uDDF9\\uD83C\\uDDF9|\\uD83C\\uDDF9\\uD83C\\uDDF4|\\uD83C\\uDDF9\\uD83C\\uDDEC|\\uD83C\\uDDF9\\uD83C\\uDDED|\\uD83C\\uDDF9\\uD83C\\uDDFF|\\uD83C\\uDDF9\\uD83C\\uDDEF|\\uD83C\\uDDF9\\uD83C\\uDDFC|\\uD83C\\uDDF8\\uD83C\\uDDFE|\\uD83C\\uDDF8\\uD83C\\uDDFF|\\uD83C\\uDDF8\\uD83C\\uDDF7|\\uD83C\\uDDF8\\uD83C\\uDDE9|\\uD83C\\uDDF1\\uD83C\\uDDF0|\\uD83C\\uDDF8\\uD83C\\uDDF4|\\uD83C\\uDDF8\\uD83C\\uDDE7|\\uD83C\\uDDF8\\uD83C\\uDDEE|\\uD83C\\uDDF8\\uD83C\\uDDF0|\\uD83C\\uDDF8\\uD83C\\uDDF1|\\uD83C\\uDDF8\\uD83C\\uDDE8|\\uD83C\\uDDF7\\uD83C\\uDDF8|\\uD83C\\uDDF8\\uD83C\\uDDF3|\\uD83C\\uDDF8\\uD83C\\uDDF9|\\uD83C\\uDDF8\\uD83C\\uDDF2|\\uD83C\\uDDFC\\uD83C\\uDDF8|\\uD83C\\uDDFB\\uD83C\\uDDE8|\\uD83C\\uDDF1\\uD83C\\uDDE8|\\uD83C\\uDDF0\\uD83C\\uDDF3|\\uD83C\\uDDF8\\uD83C\\uDDED|\\uD83C\\uDDF7\\uD83C\\uDDFC|\\uD83C\\uDDF7\\uD83C\\uDDF4|\\uD83C\\uDDF6\\uD83C\\uDDE6|\\uD83C\\uDDF5\\uD83C\\uDDEA|\\uD83C\\uDDF5\\uD83C\\uDDFE|\\uD83C\\uDDF5\\uD83C\\uDDEC|\\uD83C\\uDDF5\\uD83C\\uDDE6|\\uD83C\\uDDF5\\uD83C\\uDDF8|\\uD83C\\uDDF5\\uD83C\\uDDFC|\\uD83C\\uDDF5\\uD83C\\uDDF0|\\uD83C\\uDDF4\\uD83C\\uDDF2|\\uD83C\\uDDF0\\uD83C\\uDDF5|\\uD83C\\uDDF3\\uD83C\\uDDFA|\\uD83C\\uDDF3\\uD83C\\uDDEC|\\uD83C\\uDDF3\\uD83C\\uDDEA|\\uD83C\\uDDF3\\uD83C\\uDDEE|\\uD83C\\uDDF3\\uD83C\\uDDE8|\\uD83C\\uDDF3\\uD83C\\uDDF5|\\uD83C\\uDDF3\\uD83C\\uDDF7|\\uD83C\\uDDF3\\uD83C\\uDDE6|\\uD83C\\uDDF2\\uD83C\\uDDF2|\\uD83C\\uDDF2\\uD83C\\uDDFF|\\uD83C\\uDDF2\\uD83C\\uDDE6|\\uD83C\\uDDF2\\uD83C\\uDDF8|\\uD83C\\uDDF2\\uD83C\\uDDEA|\\uD83C\\uDDF2\\uD83C\\uDDF3|\\uD83C\\uDDF2\\uD83C\\uDDE8|\\uD83C\\uDDF2\\uD83C\\uDDE9|\\uD83C\\uDDEB\\uD83C\\uDDF2|\\uD83C\\uDDF2\\uD83C\\uDDFA|\\uD83C\\uDDF2\\uD83C\\uDDF7|\\uD83C\\uDDF2\\uD83C\\uDDED|\\uD83C\\uDDF2\\uD83C\\uDDF9|\\uD83C\\uDDF2\\uD83C\\uDDF1|\\uD83C\\uDDF2\\uD83C\\uDDFB|\\uD83C\\uDDF2\\uD83C\\uDDFC|\\uD83C\\uDDF2\\uD83C\\uDDEC|\\uD83C\\uDDF2\\uD83C\\uDDF0|\\uD83C\\uDDF1\\uD83C\\uDDFA|\\uD83C\\uDDF1\\uD83C\\uDDF9|\\uD83C\\uDDF1\\uD83C\\uDDEE|\\uD83C\\uDDF1\\uD83C\\uDDFE|\\uD83C\\uDDF1\\uD83C\\uDDF7|\\uD83C\\uDDF1\\uD83C\\uDDF8|\\uD83C\\uDDF1\\uD83C\\uDDE7|\\uD83C\\uDDF1\\uD83C\\uDDFB|\\uD83C\\uDDF1\\uD83C\\uDDE6|\\uD83C\\uDDF0\\uD83C\\uDDEC|\\uD83C\\uDDF0\\uD83C\\uDDFC|\\uD83C\\uDDFD\\uD83C\\uDDF0|\\uD83C\\uDDF0\\uD83C\\uDDEE|\\uD83C\\uDDF0\\uD83C\\uDDEA|\\uD83C\\uDDF0\\uD83C\\uDDFF|\\uD83C\\uDDEF\\uD83C\\uDDF4|\\uD83C\\uDDEF\\uD83C\\uDDEA|\\uD83C\\uDDEF\\uD83C\\uDDF2|\\uD83C\\uDDEE\\uD83C\\uDDF6|\\uD83C\\uDDEE\\uD83C\\uDDF7|\\uD83C\\uDDEE\\uD83C\\uDDF8|\\uD83C\\uDDED\\uD83C\\uDDFA|\\uD83C\\uDDED\\uD83C\\uDDF3|\\uD83C\\uDDED\\uD83C\\uDDF9|\\uD83C\\uDDEC\\uD83C\\uDDFE|\\uD83C\\uDDEC\\uD83C\\uDDFC|\\uD83C\\uDDEC\\uD83C\\uDDF3|\\uD83C\\uDDEC\\uD83C\\uDDF9|\\uD83C\\uDDEC\\uD83C\\uDDFA|\\uD83C\\uDDEC\\uD83C\\uDDE9|\\uD83C\\uDDEC\\uD83C\\uDDF1|\\uD83C\\uDDEC\\uD83C\\uDDF7|\\uD83C\\uDDEC\\uD83C\\uDDEE|\\uD83C\\uDDEC\\uD83C\\uDDED|\\uD83C\\uDDEC\\uD83C\\uDDEA|\\uD83C\\uDDEC\\uD83C\\uDDF2|\\uD83C\\uDDEC\\uD83C\\uDDE6|\\uD83C\\uDDF5\\uD83C\\uDDEB|\\uD83C\\uDDEB\\uD83C\\uDDEF|\\uD83C\\uDDEB\\uD83C\\uDDF4|\\uD83C\\uDDEB\\uD83C\\uDDF0|\\uD83C\\uDDEA\\uD83C\\uDDF9|\\uD83C\\uDDEA\\uD83C\\uDDEA|\\uD83C\\uDDEA\\uD83C\\uDDF7|\\uD83C\\uDDEC\\uD83C\\uDDF6|\\uD83C\\uDDF8\\uD83C\\uDDFB|\\uD83C\\uDDEA\\uD83C\\uDDEC|\\uD83C\\uDDEA\\uD83C\\uDDE8|\\uD83C\\uDDF9\\uD83C\\uDDF1|\\uD83C\\uDDE9\\uD83C\\uDDF4|\\uD83C\\uDDE9\\uD83C\\uDDF2|\\uD83C\\uDDE9\\uD83C\\uDDEF|\\uD83C\\uDDE8\\uD83C\\uDDFF|\\uD83C\\uDDE8\\uD83C\\uDDFE|\\uD83C\\uDDE8\\uD83C\\uDDFA|\\uD83C\\uDDED\\uD83C\\uDDF7|\\uD83C\\uDDE8\\uD83C\\uDDEE|\\uD83C\\uDDE8\\uD83C\\uDDF7|\\uD83C\\uDDF9\\uD83C\\uDDE9|\\uD83C\\uDDE8\\uD83C\\uDDEC|\\uD83C\\uDDE8\\uD83C\\uDDE9|\\uD83C\\uDDF0\\uD83C\\uDDF2|\\uD83C\\uDDE8\\uD83C\\uDDEB|\\uD83C\\uDDF0\\uD83C\\uDDFE|\\uD83C\\uDDE8\\uD83C\\uDDFB|\\uD83C\\uDDE8\\uD83C\\uDDF2|\\uD83C\\uDDF0\\uD83C\\uDDED|\\uD83C\\uDDE7\\uD83C\\uDDEE|\\uD83C\\uDDE7\\uD83C\\uDDEB|\\uD83C\\uDDE7\\uD83C\\uDDEC|\\uD83C\\uDDE7\\uD83C\\uDDF3|\\uD83C\\uDDE7\\uD83C\\uDDFC|\\uD83C\\uDDE7\\uD83C\\uDDE6|\\uD83C\\uDDE7\\uD83C\\uDDF4|\\uD83C\\uDDE7\\uD83C\\uDDF9|\\uD83C\\uDDE7\\uD83C\\uDDF2|\\uD83C\\uDDE7\\uD83C\\uDDEF|\\uD83C\\uDDE7\\uD83C\\uDDFF|\\uD83C\\uDDE7\\uD83C\\uDDFE|\\uD83C\\uDDE7\\uD83C\\uDDE7|\\uD83C\\uDDE7\\uD83C\\uDDE9|\\uD83C\\uDDE7\\uD83C\\uDDED|\\uD83C\\uDDE7\\uD83C\\uDDF8|\\uD83C\\uDDE6\\uD83C\\uDDFF|\\uD83C\\uDDE6\\uD83C\\uDDE8|\\uD83C\\uDDE6\\uD83C\\uDDFC|\\uD83C\\uDDE6\\uD83C\\uDDF2|\\uD83C\\uDDE6\\uD83C\\uDDF7|\\uD83C\\uDDE6\\uD83C\\uDDEC|\\uD83C\\uDDE6\\uD83C\\uDDEE|\\uD83C\\uDDE6\\uD83C\\uDDF4|\\uD83C\\uDDE6\\uD83C\\uDDE9|\\uD83C\\uDDE9\\uD83C\\uDDFF|\\uD83C\\uDDE6\\uD83C\\uDDF1|\\uD83C\\uDDE6\\uD83C\\uDDEB|\\uD83C\\uDDFB\\uD83C\\uDDF3|\\uD83C\\uDDE6\\uD83C\\uDDEA|\\uD83C\\uDDFA\\uD83C\\uDDF8|\\uD83C\\uDDEC\\uD83C\\uDDE7|\\uD83C\\uDDF9\\uD83C\\uDDF7|\\uD83C\\uDDE8\\uD83C\\uDDED|\\uD83C\\uDDF8\\uD83C\\uDDEA|\\uD83C\\uDDEA\\uD83C\\uDDF8|\\uD83C\\uDDFF\\uD83C\\uDDE6|\\uD83C\\uDDF8\\uD83C\\uDDEC|\\uD83C\\uDDF8\\uD83C\\uDDE6|\\uD83C\\uDDF7\\uD83C\\uDDFA|\\uD83C\\uDDF5\\uD83C\\uDDF7|\\uD83C\\uDDF5\\uD83C\\uDDF9|\\uD83C\\uDDF5\\uD83C\\uDDF1|\\uD83C\\uDDF5\\uD83C\\uDDED|\\uD83C\\uDDF3\\uD83C\\uDDF4|\\uD83C\\uDDF3\\uD83C\\uDDFF|\\uD83C\\uDDF3\\uD83C\\uDDF1|\\uD83C\\uDDF2\\uD83C\\uDDFD|\\uD83C\\uDDF2\\uD83C\\uDDFE|\\uD83C\\uDDF2\\uD83C\\uDDF4|\\uD83C\\uDDF0\\uD83C\\uDDF7|\\uD83C\\uDDEF\\uD83C\\uDDF5|\\uD83C\\uDDEE\\uD83C\\uDDF9|\\uD83C\\uDDEE\\uD83C\\uDDF1|\\uD83C\\uDDEE\\uD83C\\uDDEA|\\uD83C\\uDDEE\\uD83C\\uDDE9|\\uD83C\\uDDEE\\uD83C\\uDDF3|\\uD83C\\uDDED\\uD83C\\uDDF0|\\uD83C\\uDDE9\\uD83C\\uDDEA|\\uD83C\\uDDEB\\uD83C\\uDDF7|\\uD83C\\uDDEB\\uD83C\\uDDEE|\\uD83C\\uDDE9\\uD83C\\uDDF0|\\uD83C\\uDDE8\\uD83C\\uDDF4|\\uD83C\\uDDE8\\uD83C\\uDDF3|\\uD83C\\uDDE8\\uD83C\\uDDF1|\\uD83C\\uDDE8\\uD83C\\uDDE6|\\uD83C\\uDDE7\\uD83C\\uDDF7|\\uD83C\\uDDE7\\uD83C\\uDDEA|\\uD83C\\uDDE6\\uD83C\\uDDF9|\\uD83C\\uDDE6\\uD83C\\uDDFA|\\uD83D\\uDDFA|\\uD83C\\uDFEB|\\uD83C\\uDFEA|\\u26EA\\uFE0F|\\u26EA|\\uD83D\\uDC92|\\uD83C\\uDFE9|\\uD83C\\uDFE8|\\uD83C\\uDFE6|\\uD83C\\uDFE5|\\uD83C\\uDFE4|\\uD83C\\uDFE3|\\uD83C\\uDFED|\\uD83C\\uDFEC|\\uD83C\\uDFE2|\\uD83C\\uDFD7|\\uD83C\\uDFDA|\\uD83C\\uDFE1|\\uD83C\\uDFD8|\\uD83C\\uDFE0|\\uD83C\\uDF09|\\uD83C\\uDF03|\\uD83C\\uDF06|\\uD83C\\uDF07|\\uD83C\\uDFD9|\\uD83C\\uDFDE|\\uD83C\\uDFDD|\\uD83C\\uDFDC|\\uD83C\\uDFD6|\\uD83C\\uDFD5|\\uD83C\\uDFD4|\\uD83C\\uDFDF|\\uD83C\\uDFDB|\\uD83C\\uDFEF|\\uD83C\\uDFF0|\\u26F2\\uFE0F|\\u26F2|\\uD83D\\uDDFC|\\uD83C\\uDF01|\\uD83D\\uDDFF|\\uD83D\\uDDFD|\\uD83D\\uDECD|\\uD83C\\uDF7D|\\uD83D\\uDECB|\\uD83D\\uDECF|\\uD83D\\uDECE|\\uD83D\\uDCB5|\\uD83D\\uDCB7|\\uD83D\\uDCB6|\\uD83D\\uDCB4|\\uD83D\\uDEC5|\\uD83D\\uDEC4|\\uD83D\\uDEC3|\\uD83D\\uDEC2|\\uD83D\\uDE9F|\\uD83D\\uDEA0|\\uD83D\\uDEA1|\\u26F5\\uFE0F|\\u26F5|\\uD83D\\uDEA4|\\uD83D\\uDEE5|\\uD83D\\uDEF3|\\uD83D\\uDEA2|\\u2693\\uFE0F|\\uD83D\\uDCBA|\\uD83D\\uDEEC|\\uD83D\\uDEEB|\\uD83D\\uDEE9|\\uD83D\\uDEEA|\\uD83D\\uDEE6|\\uD83D\\uDEE8|\\uD83D\\uDEE7|\\u2708\\uFE0F|\\uD83D\\uDE81|\\uD83D\\uDE80|\\uD83D\\uDEA5|\\uD83D\\uDEA6|\\uD83D\\uDEA7|\\u26FD\\uFE0F|\\u26FD|\\uD83D\\uDE8F|\\uD83D\\uDEE3|\\uD83D\\uDEB2|\\uD83D\\uDE9C|\\uD83D\\uDE9B|\\uD83D\\uDE9A|\\uD83D\\uDE99|\\uD83D\\uDE98|\\uD83D\\uDE97|\\uD83D\\uDE96|\\uD83D\\uDE95|\\uD83D\\uDEA8|\\uD83D\\uDE94|\\uD83D\\uDE93|\\uD83D\\uDEF1|\\uD83D\\uDE92|\\uD83D\\uDE91|\\uD83D\\uDE90|\\uD83D\\uDE8E|\\uD83D\\uDE8D|\\uD83D\\uDE8C|\\uD83D\\uDEE4|\\uD83D\\uDE8A|\\uD83D\\uDE89|\\uD83D\\uDE88|\\uD83D\\uDE87|\\uD83D\\uDE86|\\uD83D\\uDE85|\\uD83D\\uDE84|\\uD83D\\uDE9D|\\uD83D\\uDE8B|\\uD83D\\uDEF2|\\uD83D\\uDE82|\\uD83D\\uDE9E|\\uD83D\\uDE83|\\uD83D\\uDD67|\\uD83D\\uDD66|\\uD83D\\uDD65|\\uD83D\\uDD64|\\uD83D\\uDD63|\\uD83D\\uDD62|\\uD83D\\uDD61|\\uD83D\\uDD60|\\uD83D\\uDD5F|\\uD83D\\uDD5E|\\uD83D\\uDD5D|\\uD83D\\uDD5C|\\uD83D\\uDD5B|\\uD83D\\uDD5A|\\uD83D\\uDD59|\\uD83D\\uDD58|\\uD83D\\uDD57|\\uD83D\\uDD56|\\uD83D\\uDD55|\\uD83D\\uDD54|\\uD83D\\uDD53|\\uD83D\\uDD52|\\uD83D\\uDD51|\\uD83D\\uDD50|\\uD83D\\uDD33|\\uD83D\\uDD32|\\u25FD\\uFE0F|\\u25FD|\\u25FE\\uFE0F|\\u25FE|\\u25FB\\uFE0F|\\u25FB|\\u25FC\\uFE0F|\\u25FC|\\u2B1C\\uFE0F|\\u2B1C|\\u2B1B\\uFE0F|\\u2B1B|\\u25AB\\uFE0F|\\u25AB|\\u25AA\\uFE0F|\\u25AA|\\uD83D\\uDD37|\\uD83D\\uDD36|\\uD83D\\uDD39|\\uD83D\\uDD38|\\uD83D\\uDD3B|\\uD83D\\uDD3A|\\uD83D\\uDD35|\\uD83D\\uDD34|\\uD83D\\uDD18|\\u26AB\\uFE0F|\\u26AB|\\u26AA\\uFE0F|\\u26AA|\\uD83D\\uDDF5|\\uD83D\\uDDF4|\\uD83D\\uDDF9|\\uD83D\\uDDF8|\\u2611\\uFE0F|\\u2666\\uFE0F|\\u2665\\uFE0F|\\u2663\\uFE0F|\\u2660\\uFE0F|\\uD83D\\uDCA0|\\uD83D\\uDCA2|\\u267B\\uFE0F|\\u267B|\\uD83C\\uDFF6|\\uD83C\\uDFF5|\\u2668\\uFE0F|\\u26A0\\uFE0F|\\u26A0|\\uD83D\\uDD31|\\uD83D\\uDDF2|\\uD83D\\uDD30|\\uD83D\\uDD2F|\\u26CE|\\uD83D\\uDEC8|\\u24C2\\uFE0F|\\u24C2|\\uD83C\\uDF00|\\uD83D\\uDD1C|\\uD83D\\uDD1D|\\uD83D\\uDD1B|\\uD83D\\uDD19|\\uD83D\\uDD1A|\\uD83D\\uDCAF|\\u2B55\\uFE0F|\\u2B55|\\u274C|\\uD83D\\uDEC6|\\u2049\\uFE0F|\\u203C\\uFE0F|\\u203C|\\u2757\\uFE0F|\\u303D\\uFE0F|\\u303D|\\u27BF|\\u27B0|\\uD83D\\uDCB2|\\uD83D\\uDCB1|\\u00AE|\\u00A9|\\uD83D\\uDDD8|\\uD83D\\uDD03|\\uD83D\\uDDD9|\\u2714\\uFE0F|\\u2716\\uFE0F|\\uD83D\\uDD23|\\uD83C\\uDFA6|\\uD83D\\uDCF6|\\u2139\\uFE0F|\\uD83D\\uDD20|\\uD83D\\uDD21|\\uD83D\\uDD24|\\uD83D\\uDD22|\\uD83D\\uDD1F|9\\uFE0F\\u20E3|9\\u20E3|8\\uFE0F\\u20E3|8\\u20E3|7\\uFE0F\\u20E3|7\\u20E3|6\\uFE0F\\u20E3|6\\u20E3|5\\uFE0F\\u20E3|5\\u20E3|4\\uFE0F\\u20E3|4\\u20E3|3\\uFE0F\\u20E3|3\\u20E3|2\\uFE0F\\u20E3|2\\u20E3|1\\uFE0F\\u20E3|1\\u20E3|0\\uFE0F\\u20E3|0\\u20E3|#\\uFE0F\\u20E3|#\\u20E3|\\uD83D\\uDD02|\\uD83D\\uDD01|\\uD83D\\uDD00|\\u2935\\uFE0F|\\u2934\\uFE0F|\\u21A9\\uFE0F|\\u21A9|\\u21AA\\uFE0F|\\u21AA|\\uD83D\\uDD04|\\u2194\\uFE0F|\\u2195\\uFE0F|\\u2196\\uFE0F|\\u2199\\uFE0F|\\u2198\\uFE0F|\\u2197\\uFE0F|\\u2B07\\uFE0F|\\u2B07|\\u2B06\\uFE0F|\\u2B06|\\u2B05\\uFE0F|\\u2B05|\\u27A1\\uFE0F|\\u27A1|\\u23EC|\\u23EB|\\u23EA|\\u23E9|\\uD83D\\uDD3D|\\uD83D\\uDD3C|\\u25C0\\uFE0F|\\u25C0|\\u25B6\\uFE0F|\\u25B6|\\uD83D\\uDEAE|\\uD83D\\uDEAD|\\uD83D\\uDEB0|\\u267F\\uFE0F|\\u267F|\\uD83D\\uDEBC|\\uD83D\\uDECA|\\uD83D\\uDEC9|\\uD83D\\uDEBA|\\uD83D\\uDEB9|\\uD83D\\uDEBB|\\u2653\\uFE0F|\\u2652\\uFE0F|\\u2651\\uFE0F|\\u2650\\uFE0F|\\u264F\\uFE0F|\\u264F|\\u264E\\uFE0F|\\u264E|\\u264D\\uFE0F|\\u264D|\\u264C\\uFE0F|\\u264C|\\u264B\\uFE0F|\\u264B|\\u264A\\uFE0F|\\u264A|\\u2649\\uFE0F|\\u2648\\uFE0F|\\uD83C\\uDFE7|\\uD83C\\uDD99|\\uD83C\\uDD97|\\uD83C\\uDD96|\\uD83C\\uDD95|\\uD83C\\uDD93|\\uD83C\\uDD92|\\uD83D\\uDEBE|\\uD83C\\uDD7F\\uFE0F|\\uD83C\\uDD7F|\\uD83C\\uDD94|\\uD83C\\uDD98|\\uD83C\\uDD7E|\\uD83C\\uDD91|\\uD83C\\uDD8E|\\uD83C\\uDD71|\\uD83C\\uDD70|\\uD83C\\uDD9A|\\uD83D\\uDCF4|\\uD83D\\uDCF3|\\u2734\\uFE0F|\\u274E|\\u2733\\uFE0F|\\u2747\\uFE0F|\\uD83D\\uDCB9|\\uD83C\\uDE2F\\uFE0F|\\uD83C\\uDE2F|\\uD83C\\uDE01|\\uD83C\\uDE02|\\uD83C\\uDE33|\\uD83C\\uDE39|\\uD83C\\uDE37|\\uD83C\\uDE3A|\\uD83C\\uDE38|\\uD83C\\uDE1A\\uFE0F|\\uD83C\\uDE1A|\\uD83C\\uDE36|\\uD83C\\uDE32|\\uD83C\\uDE35|\\uD83C\\uDE34|\\u3297\\uFE0F|\\u3299\\uFE0F|\\uD83D\\uDCAE|\\uD83C\\uDE50|\\uD83C\\uDE51|\\uD83D\\uDD72|\\uD83D\\uDD1E|\\uD83D\\uDCF5|\\uD83D\\uDEB1|\\uD83D\\uDEB3|\\uD83D\\uDEAF|\\uD83D\\uDEB7|\\uD83D\\uDCDB|\\u26D4\\uFE0F|\\u26D4|\\uD83D\\uDEAB|\\uD83D\\uDEC7|\\uD83D\\uDECC|\\uD83D\\uDDE3|\\uD83D\\uDD0E|\\uD83D\\uDD0D|\\uD83D\\uDEE1|\\uD83D\\uDEB8|\\uD83D\\uDDF1|\\uD83D\\uDDF0|\\uD83D\\uDDEF|\\uD83D\\uDDEE|\\uD83D\\uDDED|\\uD83D\\uDDEC|\\uD83D\\uDDEB|\\uD83D\\uDDEA|\\uD83D\\uDDE9|\\uD83D\\uDDE8|\\uD83D\\uDCAC|\\uD83D\\uDCAD|\\uD83D\\uDD4A|\\uD83D\\uDD49|\\uD83D\\uDD48|\\uD83D\\uDD47|\\uD83D\\uDD46|\\uD83C\\uDF9D|\\uD83C\\uDF9C|\\uD83D\\uDD6D|\\uD83D\\uDD15|\\uD83D\\uDD14|\\uD83D\\uDCA4|\\uD83D\\uDD6C|\\uD83D\\uDD6B|\\uD83D\\uDD6A|\\uD83D\\uDD69|\\uD83D\\uDD68|\\uD83D\\uDD07|\\uD83D\\uDD0A|\\uD83D\\uDD09|\\uD83D\\uDD08|\\uD83D\\uDCE2|\\uD83D\\uDCE3|\\uD83D\\uDD13|\\uD83D\\uDD12|\\uD83D\\uDD10|\\uD83D\\uDD0F|\\uD83D\\uDCDD|\\uD83D\\uDD8D|\\uD83D\\uDD8C|\\uD83D\\uDD8B|\\uD83D\\uDD8A|\\uD83D\\uDD89|\\u270F\\uFE0F|\\u270F|\\u2712\\uFE0F|\\uD83D\\uDDC4|\\uD83D\\uDCC2|\\uD83D\\uDCC1|\\uD83D\\uDDC1|\\uD83D\\uDDC0|\\uD83D\\uDD73|\\uD83C\\uDFF4|\\uD83C\\uDFF3|\\uD83C\\uDFF2|\\uD83C\\uDFF1|\\uD83D\\uDEA9|\\uD83D\\uDCCF|\\uD83D\\uDCCD|\\uD83D\\uDCD0|\\u2702\\uFE0F|\\uD83D\\uDD88|\\uD83D\\uDCCC|\\uD83D\\uDD87|\\uD83D\\uDCCE|\\uD83D\\uDD17|\\uD83D\\uDDC3|\\uD83D\\uDDC2|\\uD83D\\uDCC7|\\uD83D\\uDCDA|\\uD83D\\uDCD9|\\uD83D\\uDCD8|\\uD83D\\uDCD7|\\uD83D\\uDCD5|\\uD83D\\uDCD2|\\uD83D\\uDCD4|\\uD83D\\uDCD3|\\uD83D\\uDCD6|\\uD83D\\uDD6E|\\uD83D\\uDCCB|\\uD83D\\uDCDC|\\uD83D\\uDDBD|\\uD83D\\uDDBC|\\uD83D\\uDDBE|\\uD83D\\uDDDC|\\uD83D\\uDD06|\\uD83D\\uDD05|\\uD83D\\uDDF3|\\uD83D\\uDDD3|\\uD83D\\uDCC6|\\uD83D\\uDCC5|\\uD83D\\uDDE0|\\uD83D\\uDCCA|\\uD83D\\uDCC9|\\uD83D\\uDCC8|\\uD83D\\uDDD2|\\uD83D\\uDDCA|\\uD83D\\uDDC9|\\uD83D\\uDDC7|\\uD83D\\uDDC6|\\uD83D\\uDDD1|\\uD83D\\uDCD1|\\uD83D\\uDDD0|\\uD83D\\uDCC3|\\uD83D\\uDCC4|\\uD83D\\uDDCF|\\uD83D\\uDDB9|\\uD83D\\uDDCE|\\uD83D\\uDCEC|\\uD83D\\uDCED|\\uD83D\\uDCEB|\\uD83D\\uDCEA|\\uD83D\\uDCEE|\\uD83D\\uDCEF|\\uD83D\\uDCE6|\\uD83D\\uDCE4|\\uD83D\\uDCE5|\\uD83D\\uDCE7|\\uD83D\\uDCE8|\\uD83D\\uDCE9|\\uD83D\\uDD86|\\uD83D\\uDD85|\\uD83D\\uDD83|\\uD83D\\uDD82|\\u2709\\uFE0F|\\uD83D\\uDDDD|\\uD83D\\uDD11|\\uD83C\\uDFF7|\\uD83C\\uDF21|\\uD83D\\uDDDE|\\uD83D\\uDCF0|\\uD83D\\uDD16|\\uD83D\\uDD2B|\\uD83D\\uDD71|\\uD83D\\uDEAC|\\uD83D\\uDCA3|\\uD83D\\uDEE2|\\uD83D\\uDEE0|\\uD83D\\uDD28|\\uD83D\\uDD29|\\uD83D\\uDDE1|\\uD83D\\uDD2A|\\uD83D\\uDD27|\\uD83D\\uDD2E|\\uD83D\\uDD2D|\\uD83D\\uDD2C|\\uD83D\\uDC8A|\\uD83D\\uDC89|\\uD83D\\uDC88|\\uD83D\\uDEBD|\\uD83D\\uDEC1|\\uD83D\\uDEBF|\\uD83D\\uDEAA|\\uD83D\\uDC56|\\uD83D\\uDC54|\\uD83D\\uDC55|\\uD83D\\uDC5A|\\uD83D\\uDC58|\\uD83D\\uDC57|\\uD83D\\uDC59|\\uD83D\\uDC5F|\\uD83D\\uDC5E|\\uD83D\\uDC62|\\uD83D\\uDC60|\\uD83D\\uDC61|\\uD83D\\uDC52|\\uD83D\\uDD76|\\uD83D\\uDC53|\\uD83D\\uDC84|\\uD83C\\uDF92|\\uD83D\\uDCBC|\\uD83D\\uDC5C|\\uD83D\\uDC5B|\\uD83D\\uDC5D|\\uD83C\\uDF02|\\uD83D\\uDC8E|\\uD83D\\uDCB0|\\uD83D\\uDCB8|\\uD83D\\uDCB3|\\uD83D\\uDEF0|\\uD83D\\uDCE1|\\uD83D\\uDD6F|\\uD83D\\uDD26|\\uD83D\\uDCA1|\\uD83D\\uDD0C|\\uD83D\\uDD0B|\\uD83D\\uDCFC|\\uD83D\\uDDB8|\\uD83D\\uDCC0|\\uD83D\\uDCBF|\\uD83D\\uDDB4|\\uD83D\\uDDAD|\\uD83D\\uDDAB|\\uD83D\\uDDAA|\\uD83D\\uDCBE|\\uD83D\\uDCBD|\\uD83D\\uDCE0|\\uD83D\\uDD81|\\uD83D\\uDD7F|\\uD83D\\uDD7E|\\u260E\\uFE0F|\\u260E|\\uD83D\\uDD7B|\\uD83D\\uDCDE|\\uD83D\\uDD79|\\uD83D\\uDCDF|\\uD83D\\uDCFE|\\uD83D\\uDCFB|\\uD83C\\uDF9B|\\uD83C\\uDF9A|\\uD83C\\uDF99|\\uD83C\\uDF98|\\uD83D\\uDCFA|\\uD83D\\uDCFD|\\uD83C\\uDFA5|\\uD83D\\uDCF9|\\uD83D\\uDCF8|\\uD83D\\uDCF7|\\u231B\\uFE0F|\\u231B|\\u23F3|\\uD83D\\uDD70|\\u23F0|\\uD83D\\uDDA9|\\uD83D\\uDDD4|\\uD83D\\uDDA8|\\uD83D\\uDDA7|\\uD83D\\uDDA6|\\uD83D\\uDDB2|\\uD83D\\uDDAF|\\uD83D\\uDDAE|\\uD83D\\uDDB3|\\uD83D\\uDDA5|\\uD83D\\uDCBB|\\uD83D\\uDCF2|\\uD83D\\uDCF1|\\u231A\\uFE0F|\\u231A|\\uD83C\\uDF7C|\\uD83C\\uDF7B|\\uD83C\\uDF7A|\\uD83C\\uDF79|\\uD83C\\uDF78|\\uD83C\\uDF77|\\uD83C\\uDF76|\\u2615\\uFE0F|\\uD83C\\uDF75|\\uD83C\\uDF74|\\uD83C\\uDF73|\\uD83C\\uDF72|\\uD83C\\uDF71|\\uD83C\\uDF70|\\uD83C\\uDF6F|\\uD83C\\uDF6E|\\uD83C\\uDF6D|\\uD83C\\uDF6C|\\uD83C\\uDF6B|\\uD83C\\uDF6A|\\uD83C\\uDF69|\\uD83C\\uDF68|\\uD83C\\uDF67|\\uD83C\\uDF66|\\uD83C\\uDF65|\\uD83C\\uDF64|\\uD83C\\uDF63|\\uD83C\\uDF62|\\uD83C\\uDF61|\\uD83C\\uDF5F|\\uD83C\\uDF5E|\\uD83C\\uDF5D|\\uD83C\\uDF5C|\\uD83C\\uDF5B|\\uD83C\\uDF5A|\\uD83C\\uDF59|\\uD83C\\uDF58|\\uD83C\\uDF57|\\uD83C\\uDF56|\\uD83C\\uDF55|\\uD83C\\uDF54|\\uD83C\\uDF53|\\uD83C\\uDF52|\\uD83C\\uDF51|\\uD83C\\uDF50|\\uD83C\\uDF4F|\\uD83C\\uDF4E|\\uD83C\\uDF4D|\\uD83C\\uDF4C|\\uD83C\\uDF4B|\\uD83C\\uDF4A|\\uD83C\\uDF49|\\uD83C\\uDF48|\\uD83C\\uDF47|\\uD83C\\uDF36|\\uD83C\\uDF60|\\uD83C\\uDF3D|\\uD83C\\uDF46|\\uD83C\\uDF45|\\uD83C\\uDFA2|\\uD83C\\uDFA1|\\uD83C\\uDFA0|\\uD83C\\uDC04\\uFE0F|\\uD83C\\uDC04|\\uD83C\\uDCCF|\\uD83C\\uDFB4|\\uD83C\\uDFAE|\\uD83C\\uDFB2|\\uD83C\\uDFB0|\\uD83C\\uDFB3|\\uD83C\\uDFB1|\\uD83C\\uDFAF|\\uD83C\\uDFA8|\\uD83C\\uDF9F|\\uD83C\\uDF9E|\\uD83C\\uDFAC|\\uD83C\\uDFAA|\\uD83C\\uDFA9|\\uD83C\\uDFAB|\\uD83C\\uDFAD|\\uD83C\\uDFA4|\\uD83C\\uDFA7|\\uD83C\\uDFBC|\\uD83C\\uDFB6|\\uD83C\\uDFB5|\\uD83C\\uDFBA|\\uD83C\\uDFB7|\\uD83C\\uDFBB|\\uD83C\\uDFB8|\\uD83C\\uDFB9|\\uD83C\\uDFC1|\\uD83C\\uDFBD|\\uD83C\\uDFC5|\\uD83C\\uDFC6|\\u26F3\\uFE0F|\\u26F3|\\uD83C\\uDFC9|\\uD83C\\uDFBE|\\u26BE\\uFE0F|\\u26BE|\\uD83C\\uDFC8|\\uD83C\\uDFC0|\\u26BD\\uFE0F|\\u26BD|\\uD83C\\uDFA3|\\u26FA\\uFE0F|\\u26FA|\\uD83C\\uDFC7|\\uD83C\\uDFCE|\\uD83C\\uDFCD|\\uD83D\\uDEB5|\\uD83D\\uDEB4|\\u26C4\\uFE0F|\\u26C4|\\uD83C\\uDFBF|\\uD83C\\uDFC2|\\uD83D\\uDEC0|\\uD83C\\uDFC4|\\uD83C\\uDFCA|\\uD83D\\uDEA3|\\uD83C\\uDFCC|\\uD83C\\uDFCB|\\uD83D\\uDC83|\\uD83D\\uDEB6|\\uD83C\\uDFC3|\\uD83D\\uDC99|\\uD83D\\uDC9A|\\uD83D\\uDC9B|\\uD83D\\uDC9C|\\uD83D\\uDC9F|\\uD83C\\uDF94|\\uD83D\\uDC9D|\\uD83D\\uDC98|\\uD83D\\uDC96|\\uD83D\\uDC97|\\uD83D\\uDC93|\\uD83D\\uDC9E|\\uD83D\\uDC95|\\uD83D\\uDC8C|\\uD83D\\uDC94|\\u2764\\uFE0F|\\uD83C\\uDF95|\\uD83D\\uDC8D|\\uD83C\\uDFEE|\\uD83C\\uDF8C|\\uD83C\\uDF90|\\uD83C\\uDF8F|\\uD83C\\uDF8E|\\uD83C\\uDF96|\\uD83C\\uDF97|\\uD83D\\uDC51|\\uD83C\\uDF93|\\uD83D\\uDCA5|\\uD83D\\uDCAB|\\uD83C\\uDF88|\\uD83C\\uDF8A|\\uD83C\\uDF89|\\uD83C\\uDF87|\\uD83C\\uDF86|\\uD83C\\uDF91|\\uD83C\\uDF8D|\\uD83C\\uDF8B|\\uD83C\\uDF84|\\uD83C\\uDF83|\\uD83C\\uDF82|\\uD83C\\uDF81|\\uD83C\\uDF80|\\uD83C\\uDF2C|\\uD83C\\uDF1E|\\uD83C\\uDF1C|\\uD83C\\uDF1B|\\uD83C\\uDF1D|\\uD83C\\uDF1A|\\uD83C\\uDF18|\\uD83C\\uDF17|\\uD83C\\uDF16|\\uD83C\\uDF15|\\uD83C\\uDF14|\\uD83C\\uDF13|\\uD83C\\uDF12|\\uD83C\\uDF11|\\uD83C\\uDF0F|\\uD83C\\uDF0E|\\uD83C\\uDF0D|\\uD83C\\uDF10|\\uD83D\\uDDFE|\\uD83D\\uDDFB|\\uD83C\\uDF0C|\\uD83C\\uDF0B|\\uD83C\\uDF0A|\\uD83C\\uDF08|\\uD83C\\uDF05|\\uD83C\\uDF04|\\uD83C\\uDF20|\\u2B50\\uFE0F|\\u2B50|\\uD83C\\uDF1F|\\u2744\\uFE0F|\\uD83D\\uDCA8|\\uD83C\\uDF2B|\\u2614\\uFE0F|\\uD83D\\uDCA6|\\uD83D\\uDCA7|\\uD83C\\uDF2A|\\uD83C\\uDF29|\\uD83C\\uDF28|\\uD83C\\uDF27|\\u2601\\uFE0F|\\u26C5\\uFE0F|\\u26C5|\\u2600\\uFE0F|\\uD83C\\uDF19|\\uD83D\\uDD25|\\u26A1\\uFE0F|\\u26A1|\\uD83D\\uDC3E|\\uD83D\\uDD78|\\uD83D\\uDD77|\\uD83D\\uDC1E|\\uD83D\\uDC1D|\\uD83D\\uDC1C|\\uD83D\\uDC1B|\\uD83D\\uDC0C|\\uD83D\\uDC1A|\\uD83D\\uDC21|\\uD83D\\uDC20|\\uD83D\\uDC1F|\\uD83D\\uDC19|\\uD83D\\uDC2C|\\uD83D\\uDC33|\\uD83D\\uDC0B|\\uD83D\\uDC38|\\uD83D\\uDC22|\\uD83D\\uDC0D|\\uD83D\\uDC0A|\\uD83D\\uDC32|\\uD83D\\uDC09|\\uD83D\\uDC12|\\uD83D\\uDE4A|\\uD83D\\uDE49|\\uD83D\\uDE48|\\uD83D\\uDC35|\\uD83D\\uDC3C|\\uD83D\\uDC28|\\uD83D\\uDC3B|\\uD83D\\uDC3A|\\uD83D\\uDC36|\\uD83D\\uDC29|\\uD83D\\uDC15|\\uD83D\\uDC3D|\\uD83D\\uDC37|\\uD83D\\uDC16|\\uD83D\\uDC17|\\uD83D\\uDC2B|\\uD83D\\uDC2A|\\uD83D\\uDC18|\\uD83D\\uDC27|\\uD83D\\uDC26|\\uD83D\\uDC25|\\uD83D\\uDC23|\\uD83D\\uDC24|\\uD83D\\uDC14|\\uD83D\\uDC13|\\uD83D\\uDC10|\\uD83D\\uDC11|\\uD83D\\uDC0F|\\uD83D\\uDC34|\\uD83D\\uDC0E|\\uD83D\\uDC31|\\uD83D\\uDC08|\\uD83D\\uDC30|\\uD83D\\uDC07|\\uD83D\\uDC3F|\\uD83D\\uDC2F|\\uD83D\\uDC06|\\uD83D\\uDC05|\\uD83D\\uDC2E|\\uD83D\\uDC04|\\uD83D\\uDC03|\\uD83D\\uDC02|\\uD83D\\uDC39|\\uD83D\\uDC2D|\\uD83D\\uDC01|\\uD83D\\uDC00|\\uD83C\\uDF30|\\uD83C\\uDF44|\\uD83C\\uDF43|\\uD83C\\uDF42|\\uD83C\\uDF41|\\uD83C\\uDF40|\\uD83C\\uDF3F|\\uD83C\\uDF3E|\\uD83D\\uDC90|\\uD83C\\uDF3C|\\uD83C\\uDF3B|\\uD83C\\uDF3A|\\uD83C\\uDF39|\\uD83C\\uDF38|\\uD83C\\uDF37|\\uD83C\\uDF35|\\uD83C\\uDF34|\\uD83C\\uDF33|\\uD83C\\uDF32|\\uD83C\\uDF31|\\uD83D\\uDE4F|\\uD83D\\uDD9F|\\uD83D\\uDD9E|\\uD83D\\uDD99|\\uD83D\\uDD98|\\uD83D\\uDD97|\\uD83D\\uDD96|\\uD83D\\uDD95|\\uD83D\\uDD94|\\uD83D\\uDD93|\\uD83D\\uDD92|\\uD83D\\uDD91|\\uD83D\\uDD90|\\uD83D\\uDD8F|\\uD83D\\uDD8E|\\uD83D\\uDC50|\\uD83D\\uDCAA|\\u270B|\\u270A|\\uD83D\\uDC4A|\\u270C\\uFE0F|\\u270C|\\uD83D\\uDC4C|\\uD83D\\uDC49|\\uD83D\\uDC48|\\uD83D\\uDC47|\\uD83D\\uDC46|\\u261D\\uFE0F|\\u261D|\\uD83D\\uDC4E|\\uD83D\\uDC4D|\\uD83D\\uDC4B|\\uD83D\\uDC85|\\uD83D\\uDC45|\\uD83D\\uDC8B|\\uD83D\\uDDE2|\\uD83D\\uDC44|\\uD83D\\uDC43|\\uD83D\\uDC40|\\uD83D\\uDC41|\\uD83D\\uDC42|\\uD83D\\uDC4F|\\uD83D\\uDE4C|\\uD83D\\uDC68\\u200D\\u2764\\uFE0F\\u200D\\uD83D\\uDC8B\\u200D\\uD83D\\uDC68|\\uD83D\\uDC68\\u2764\\uD83D\\uDC8B\\uD83D\\uDC68|\\uD83D\\uDC69\\u200D\\u2764\\uFE0F\\u200D\\uD83D\\uDC8B\\u200D\\uD83D\\uDC69|\\uD83D\\uDC69\\u2764\\uD83D\\uDC8B\\uD83D\\uDC69|\\uD83D\\uDC8F|\\uD83D\\uDC68\\u200D\\u2764\\uFE0F\\u200D\\uD83D\\uDC68|\\uD83D\\uDC68\\u2764\\uD83D\\uDC68|\\uD83D\\uDC69\\u200D\\u2764\\uFE0F\\u200D\\uD83D\\uDC69|\\uD83D\\uDC69\\u2764\\uD83D\\uDC69|\\uD83D\\uDC91|\\uD83D\\uDC87|\\uD83D\\uDC86|\\uD83D\\uDE4D|\\uD83D\\uDE4E|\\uD83D\\uDE4B|\\uD83D\\uDE46|\\uD83D\\uDE45|\\uD83D\\uDC81|\\uD83D\\uDE47|\\uD83D\\uDC7E|\\uD83D\\uDC7D|\\uD83D\\uDC80|\\uD83D\\uDCA9|\\uD83D\\uDC7A|\\uD83D\\uDC79|\\uD83D\\uDC7B|\\uD83C\\uDF85|\\uD83D\\uDC7C|\\uD83D\\uDC82|\\uD83D\\uDC78|\\uD83D\\uDC77|\\uD83D\\uDC6E|\\uD83D\\uDC75|\\uD83D\\uDC74|\\uD83D\\uDC73|\\uD83D\\uDC72|\\uD83D\\uDC71|\\uD83D\\uDC70|\\uD83D\\uDC6F|\\uD83D\\uDC6D|\\uD83D\\uDC6C|\\uD83D\\uDC6B|\\uD83D\\uDC68\\u200D\\uD83D\\uDC68\\u200D\\uD83D\\uDC67\\u200D\\uD83D\\uDC67|\\uD83D\\uDC68\\uD83D\\uDC68\\uD83D\\uDC67\\uD83D\\uDC67|\\uD83D\\uDC68\\u200D\\uD83D\\uDC68\\u200D\\uD83D\\uDC66\\u200D\\uD83D\\uDC66|\\uD83D\\uDC68\\uD83D\\uDC68\\uD83D\\uDC66\\uD83D\\uDC66|\\uD83D\\uDC68\\u200D\\uD83D\\uDC68\\u200D\\uD83D\\uDC67|\\uD83D\\uDC68\\uD83D\\uDC68\\uD83D\\uDC67\\uD83D\\uDC66|\\uD83D\\uDC68\\uD83D\\uDC68\\uD83D\\uDC67|\\uD83D\\uDC68\\u200D\\uD83D\\uDC68\\u200D\\uD83D\\uDC66|\\uD83D\\uDC68\\uD83D\\uDC68\\uD83D\\uDC66|\\uD83D\\uDC69\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC67\\u200D\\uD83D\\uDC67|\\uD83D\\uDC69\\uD83D\\uDC69\\uD83D\\uDC67\\uD83D\\uDC67|\\uD83D\\uDC69\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC66\\u200D\\uD83D\\uDC66|\\uD83D\\uDC69\\uD83D\\uDC69\\uD83D\\uDC66\\uD83D\\uDC66|\\uD83D\\uDC69\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC67\\u200D\\uD83D\\uDC66|\\uD83D\\uDC69\\uD83D\\uDC69\\uD83D\\uDC67\\uD83D\\uDC66|\\uD83D\\uDC69\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC67|\\uD83D\\uDC69\\uD83D\\uDC69\\uD83D\\uDC67|\\uD83D\\uDC69\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC66|\\uD83D\\uDC69\\uD83D\\uDC69\\uD83D\\uDC66|\\uD83D\\uDC68\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC67\\u200D\\uD83D\\uDC67|\\uD83D\\uDC68\\uD83D\\uDC69\\uD83D\\uDC67\\uD83D\\uDC67|\\uD83D\\uDC68\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC66\\u200D\\uD83D\\uDC66|\\uD83D\\uDC68\\uD83D\\uDC69\\uD83D\\uDC66\\uD83D\\uDC66|\\uD83D\\uDC68\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC67\\u200D\\uD83D\\uDC66|\\uD83D\\uDC68\\uD83D\\uDC69\\uD83D\\uDC67\\uD83D\\uDC66|\\uD83D\\uDC68\\u200D\\uD83D\\uDC69\\u200D\\uD83D\\uDC67|\\uD83D\\uDC68\\uD83D\\uDC69\\uD83D\\uDC67|\\uD83D\\uDC6A|\\uD83D\\uDC69|\\uD83D\\uDC68|\\uD83D\\uDC67|\\uD83D\\uDC66|\\uD83D\\uDC76|\\uD83D\\uDD75|\\uD83D\\uDD74|\\uD83D\\uDC65|\\uD83D\\uDC64|\\uD83D\\uDC63|\\uD83D\\uDE40|\\uD83D\\uDE3F|\\uD83D\\uDE3E|\\uD83D\\uDE3D|\\uD83D\\uDE3C|\\uD83D\\uDE3B|\\uD83D\\uDE3A|\\uD83D\\uDE39|\\uD83D\\uDE38|\\uD83D\\uDE42|\\uD83D\\uDE41|\\uD83D\\uDE37|\\uD83D\\uDE36|\\uD83D\\uDE35|\\uD83D\\uDE34|\\uD83D\\uDE33|\\uD83D\\uDE32|\\uD83D\\uDE31|\\uD83D\\uDE30|\\uD83D\\uDE2F|\\uD83D\\uDE2E|\\uD83D\\uDE2D|\\uD83D\\uDE2C|\\uD83D\\uDE2B|\\uD83D\\uDE2A|\\uD83D\\uDE29|\\uD83D\\uDE28|\\uD83D\\uDE27|\\uD83D\\uDE26|\\uD83D\\uDE25|\\uD83D\\uDE24|\\uD83D\\uDE23|\\uD83D\\uDE22|\\uD83D\\uDE21|\\uD83D\\uDE20|\\uD83D\\uDE1F|\\uD83D\\uDE1E|\\uD83D\\uDE1D|\\uD83D\\uDE1C|\\uD83D\\uDE1B|\\uD83D\\uDE1A|\\uD83D\\uDE19|\\uD83D\\uDE18|\\uD83D\\uDE17|\\uD83D\\uDE16|\\uD83D\\uDE15|\\uD83D\\uDE14|\\uD83D\\uDE13|\\uD83D\\uDE12|\\uD83D\\uDE11|\\uD83D\\uDE10|\\uD83D\\uDE0F|\\uD83D\\uDE0E|\\uD83D\\uDE0D|\\uD83D\\uDE0C|\\uD83D\\uDE0B|\\u263A\\uFE0F|\\u263A|\\uD83D\\uDE0A|\\uD83D\\uDE09|\\uD83D\\uDC7F|\\uD83D\\uDE08|\\uD83D\\uDE07|\\uD83D\\uDE06|\\uD83D\\uDE05|\\uD83D\\uDE04|\\uD83D\\uDE03|\\uD83D\\uDE02|\\uD83D\\uDE01|\\uD83D\\uDE00)",
a.jsecapeMap={"⁉":"2049","™":"2122","ℹ":"2139","↔":"2194","↕":"2195","↖":"2196","↗":"2197","↘":"2198","↙":"2199","☀":"2600","☁":"2601","☑":"2611","☔":"2614","☕":"2615","♈":"2648","♉":"2649","♐":"2650","♑":"2651","♒":"2652","♓":"2653","♠":"2660","♣":"2663","♥":"2665","♦":"2666","♨":"2668","⚓":"2693","✂":"2702","✅":"2705","✈":"2708","✉":"2709","✒":"2712","✔":"2714","✖":"2716","✨":"2728","✳":"2733","✴":"2734","❄":"2744","❇":"2747","❓":"2753","❔":"2754","❕":"2755","❗":"2757","❤":"2764","➕":"2795","➖":"2796","➗":"2797","⤴":"2934","⤵":"2935","〰":"3030","㊗":"3297","㊙":"3299","🇿🇼":"1F1FF-1F1FC","🇿🇲":"1F1FF-1F1F2","🇾🇪":"1F1FE-1F1EA","🇪🇭":"1F1EA-1F1ED","🇼🇫":"1F1FC-1F1EB","🇻🇪":"1F1FB-1F1EA","🇻🇦":"1F1FB-1F1E6","🇻🇺":"1F1FB-1F1FA","🇺🇿":"1F1FA-1F1FF","🇺🇾":"1F1FA-1F1FE","🇺🇦":"1F1FA-1F1E6","🇺🇬":"1F1FA-1F1EC","🇻🇮":"1F1FB-1F1EE","🇹🇻":"1F1F9-1F1FB","🇹🇲":"1F1F9-1F1F2","🇹🇳":"1F1F9-1F1F3","🇹🇹":"1F1F9-1F1F9","🇹🇴":"1F1F9-1F1F4","🇹🇬":"1F1F9-1F1EC","🇹🇭":"1F1F9-1F1ED","🇹🇿":"1F1F9-1F1FF","🇹🇯":"1F1F9-1F1EF","🇹🇼":"1F1F9-1F1FC","🇸🇾":"1F1F8-1F1FE","🇸🇿":"1F1F8-1F1FF","🇸🇷":"1F1F8-1F1F7","🇸🇩":"1F1F8-1F1E9","🇱🇰":"1F1F1-1F1F0","🇸🇴":"1F1F8-1F1F4","🇸🇧":"1F1F8-1F1E7","🇸🇮":"1F1F8-1F1EE","🇸🇰":"1F1F8-1F1F0","🇸🇱":"1F1F8-1F1F1","🇸🇨":"1F1F8-1F1E8","🇷🇸":"1F1F7-1F1F8","🇸🇳":"1F1F8-1F1F3","🇸🇹":"1F1F8-1F1F9","🇸🇲":"1F1F8-1F1F2","🇼🇸":"1F1FC-1F1F8","🇻🇨":"1F1FB-1F1E8","🇱🇨":"1F1F1-1F1E8","🇰🇳":"1F1F0-1F1F3","🇸🇭":"1F1F8-1F1ED","🇷🇼":"1F1F7-1F1FC","🇷🇴":"1F1F7-1F1F4","🇶🇦":"1F1F6-1F1E6","🇵🇪":"1F1F5-1F1EA","🇵🇾":"1F1F5-1F1FE","🇵🇬":"1F1F5-1F1EC","🇵🇦":"1F1F5-1F1E6","🇵🇸":"1F1F5-1F1F8","🇵🇼":"1F1F5-1F1FC","🇵🇰":"1F1F5-1F1F0","🇴🇲":"1F1F4-1F1F2","🇰🇵":"1F1F0-1F1F5","🇳🇺":"1F1F3-1F1FA","🇳🇬":"1F1F3-1F1EC","🇳🇪":"1F1F3-1F1EA","🇳🇮":"1F1F3-1F1EE","🇳🇨":"1F1F3-1F1E8","🇳🇵":"1F1F3-1F1F5","🇳🇷":"1F1F3-1F1F7","🇳🇦":"1F1F3-1F1E6","🇲🇲":"1F1F2-1F1F2","🇲🇿":"1F1F2-1F1FF","🇲🇦":"1F1F2-1F1E6","🇲🇸":"1F1F2-1F1F8","🇲🇪":"1F1F2-1F1EA","🇲🇳":"1F1F2-1F1F3","🇲🇨":"1F1F2-1F1E8","🇲🇩":"1F1F2-1F1E9","🇫🇲":"1F1EB-1F1F2","🇲🇺":"1F1F2-1F1FA","🇲🇷":"1F1F2-1F1F7","🇲🇭":"1F1F2-1F1ED","🇲🇹":"1F1F2-1F1F9","🇲🇱":"1F1F2-1F1F1","🇲🇻":"1F1F2-1F1FB","🇲🇼":"1F1F2-1F1FC","🇲🇬":"1F1F2-1F1EC","🇲🇰":"1F1F2-1F1F0","🇱🇺":"1F1F1-1F1FA","🇱🇹":"1F1F1-1F1F9","🇱🇮":"1F1F1-1F1EE","🇱🇾":"1F1F1-1F1FE","🇱🇷":"1F1F1-1F1F7","🇱🇸":"1F1F1-1F1F8","🇱🇧":"1F1F1-1F1E7","🇱🇻":"1F1F1-1F1FB","🇱🇦":"1F1F1-1F1E6","🇰🇬":"1F1F0-1F1EC","🇰🇼":"1F1F0-1F1FC","🇽🇰":"1F1FD-1F1F0","🇰🇮":"1F1F0-1F1EE","🇰🇪":"1F1F0-1F1EA","🇰🇿":"1F1F0-1F1FF","🇯🇴":"1F1EF-1F1F4","🇯🇪":"1F1EF-1F1EA","🇯🇲":"1F1EF-1F1F2","🇮🇶":"1F1EE-1F1F6","🇮🇷":"1F1EE-1F1F7","🇮🇸":"1F1EE-1F1F8","🇭🇺":"1F1ED-1F1FA","🇭🇳":"1F1ED-1F1F3","🇭🇹":"1F1ED-1F1F9","🇬🇾":"1F1EC-1F1FE","🇬🇼":"1F1EC-1F1FC","🇬🇳":"1F1EC-1F1F3","🇬🇹":"1F1EC-1F1F9","🇬🇺":"1F1EC-1F1FA","🇬🇩":"1F1EC-1F1E9","🇬🇱":"1F1EC-1F1F1","🇬🇷":"1F1EC-1F1F7","🇬🇮":"1F1EC-1F1EE","🇬🇭":"1F1EC-1F1ED","🇬🇪":"1F1EC-1F1EA","🇬🇲":"1F1EC-1F1F2","🇬🇦":"1F1EC-1F1E6","🇵🇫":"1F1F5-1F1EB","🇫🇯":"1F1EB-1F1EF","🇫🇴":"1F1EB-1F1F4","🇫🇰":"1F1EB-1F1F0","🇪🇹":"1F1EA-1F1F9","🇪🇪":"1F1EA-1F1EA","🇪🇷":"1F1EA-1F1F7","🇬🇶":"1F1EC-1F1F6","🇸🇻":"1F1F8-1F1FB","🇪🇬":"1F1EA-1F1EC","🇪🇨":"1F1EA-1F1E8","🇹🇱":"1F1F9-1F1F1","🇩🇴":"1F1E9-1F1F4","🇩🇲":"1F1E9-1F1F2","🇩🇯":"1F1E9-1F1EF","🇨🇿":"1F1E8-1F1FF","🇨🇾":"1F1E8-1F1FE","🇨🇺":"1F1E8-1F1FA","🇭🇷":"1F1ED-1F1F7","🇨🇮":"1F1E8-1F1EE","🇨🇷":"1F1E8-1F1F7","🇹🇩":"1F1F9-1F1E9","🇨🇬":"1F1E8-1F1EC","🇨🇩":"1F1E8-1F1E9","🇰🇲":"1F1F0-1F1F2","🇨🇫":"1F1E8-1F1EB","🇰🇾":"1F1F0-1F1FE","🇨🇻":"1F1E8-1F1FB","🇨🇲":"1F1E8-1F1F2","🇰🇭":"1F1F0-1F1ED","🇧🇮":"1F1E7-1F1EE","🇧🇫":"1F1E7-1F1EB","🇧🇬":"1F1E7-1F1EC","🇧🇳":"1F1E7-1F1F3","🇧🇼":"1F1E7-1F1FC","🇧🇦":"1F1E7-1F1E6","🇧🇴":"1F1E7-1F1F4","🇧🇹":"1F1E7-1F1F9","🇧🇲":"1F1E7-1F1F2","🇧🇯":"1F1E7-1F1EF","🇧🇿":"1F1E7-1F1FF","🇧🇾":"1F1E7-1F1FE","🇧🇧":"1F1E7-1F1E7","🇧🇩":"1F1E7-1F1E9","🇧🇭":"1F1E7-1F1ED","🇧🇸":"1F1E7-1F1F8","🇦🇿":"1F1E6-1F1FF","🇦🇨":"1F1E6-1F1E8","🇦🇼":"1F1E6-1F1FC","🇦🇲":"1F1E6-1F1F2","🇦🇷":"1F1E6-1F1F7","🇦🇬":"1F1E6-1F1EC","🇦🇮":"1F1E6-1F1EE","🇦🇴":"1F1E6-1F1F4","🇦🇩":"1F1E6-1F1E9","🇩🇿":"1F1E9-1F1FF","🇦🇱":"1F1E6-1F1F1","🇦🇫":"1F1E6-1F1EB","🇻🇳":"1F1FB-1F1F3","🇦🇪":"1F1E6-1F1EA","🇺🇸":"1F1FA-1F1F8","🇬🇧":"1F1EC-1F1E7","🇹🇷":"1F1F9-1F1F7","🇨🇭":"1F1E8-1F1ED","🇸🇪":"1F1F8-1F1EA","🇪🇸":"1F1EA-1F1F8","🇿🇦":"1F1FF-1F1E6","🇸🇬":"1F1F8-1F1EC","🇸🇦":"1F1F8-1F1E6","🇷🇺":"1F1F7-1F1FA","🇵🇷":"1F1F5-1F1F7","🇵🇹":"1F1F5-1F1F9","🇵🇱":"1F1F5-1F1F1","🇵🇭":"1F1F5-1F1ED","🇳🇴":"1F1F3-1F1F4","🇳🇿":"1F1F3-1F1FF","🇳🇱":"1F1F3-1F1F1","🇲🇽":"1F1F2-1F1FD","🇲🇾":"1F1F2-1F1FE","🇲🇴":"1F1F2-1F1F4","🇰🇷":"1F1F0-1F1F7","🇯🇵":"1F1EF-1F1F5","🇮🇹":"1F1EE-1F1F9","🇮🇱":"1F1EE-1F1F1","🇮🇪":"1F1EE-1F1EA","🇮🇩":"1F1EE-1F1E9","🇮🇳":"1F1EE-1F1F3","🇭🇰":"1F1ED-1F1F0","🇩🇪":"1F1E9-1F1EA","🇫🇷":"1F1EB-1F1F7","🇫🇮":"1F1EB-1F1EE","🇩🇰":"1F1E9-1F1F0","🇨🇴":"1F1E8-1F1F4","🇨🇳":"1F1E8-1F1F3","🇨🇱":"1F1E8-1F1F1","🇨🇦":"1F1E8-1F1E6","🇧🇷":"1F1E7-1F1F7","🇧🇪":"1F1E7-1F1EA","🇦🇹":"1F1E6-1F1F9","🇦🇺":"1F1E6-1F1FA","🗺":"1F5FA","🏫":"1F3EB","🏪":"1F3EA","⛪️":"26EA","⛪":"26EA","💒":"1F492","🏩":"1F3E9","🏨":"1F3E8","🏦":"1F3E6","🏥":"1F3E5","🏤":"1F3E4","🏣":"1F3E3","🏭":"1F3ED","🏬":"1F3EC","🏢":"1F3E2","🏗":"1F3D7","🏚":"1F3DA","🏡":"1F3E1","🏘":"1F3D8","🏠":"1F3E0","🌉":"1F309","🌃":"1F303","🌆":"1F306","🌇":"1F307","🏙":"1F3D9","🏞":"1F3DE","🏝":"1F3DD","🏜":"1F3DC","🏖":"1F3D6","🏕":"1F3D5","🏔":"1F3D4","🏟":"1F3DF","🏛":"1F3DB","🏯":"1F3EF","🏰":"1F3F0","⛲️":"26F2","⛲":"26F2","🗼":"1F5FC","🌁":"1F301","🗿":"1F5FF","🗽":"1F5FD","🛍":"1F6CD","🍽":"1F37D","🛋":"1F6CB","🛏":"1F6CF","🛎":"1F6CE","💵":"1F4B5","💷":"1F4B7","💶":"1F4B6","💴":"1F4B4","🛅":"1F6C5","🛄":"1F6C4","🛃":"1F6C3","🛂":"1F6C2","🚟":"1F69F","🚠":"1F6A0","🚡":"1F6A1","⛵️":"26F5","⛵":"26F5","🚤":"1F6A4","🛥":"1F6E5","🛳":"1F6F3","🚢":"1F6A2","⚓️":"2693","💺":"1F4BA","🛬":"1F6EC","🛫":"1F6EB","🛩":"1F6E9","🛪":"1F6EA","🛦":"1F6E6","🛨":"1F6E8","🛧":"1F6E7","✈️":"2708","🚁":"1F681","🚀":"1F680","🚥":"1F6A5","🚦":"1F6A6","🚧":"1F6A7","⛽️":"26FD","⛽":"26FD","🚏":"1F68F","🛣":"1F6E3","🚲":"1F6B2","🚜":"1F69C","🚛":"1F69B","🚚":"1F69A","🚙":"1F699","🚘":"1F698","🚗":"1F697","🚖":"1F696","🚕":"1F695","🚨":"1F6A8","🚔":"1F694","🚓":"1F693","🛱":"1F6F1","🚒":"1F692","🚑":"1F691","🚐":"1F690","🚎":"1F68E","🚍":"1F68D","🚌":"1F68C","🛤":"1F6E4","🚊":"1F68A","🚉":"1F689","🚈":"1F688","🚇":"1F687","🚆":"1F686","🚅":"1F685","🚄":"1F684","🚝":"1F69D","🚋":"1F68B","🛲":"1F6F2","🚂":"1F682","🚞":"1F69E","🚃":"1F683","🕧":"1F567","🕦":"1F566","🕥":"1F565","🕤":"1F564","🕣":"1F563","🕢":"1F562","🕡":"1F561","🕠":"1F560","🕟":"1F55F","🕞":"1F55E","🕝":"1F55D","🕜":"1F55C","🕛":"1F55B","🕚":"1F55A","🕙":"1F559","🕘":"1F558","🕗":"1F557","🕖":"1F556","🕕":"1F555","🕔":"1F554","🕓":"1F553","🕒":"1F552","🕑":"1F551","🕐":"1F550","🔳":"1F533","🔲":"1F532","◽️":"25FD","◽":"25FD","◾️":"25FE","◾":"25FE","◻️":"25FB","◻":"25FB","◼️":"25FC","◼":"25FC","⬜️":"2B1C","⬜":"2B1C","⬛️":"2B1B","⬛":"2B1B","▫️":"25AB","▫":"25AB","▪️":"25AA","▪":"25AA","🔷":"1F537","🔶":"1F536","🔹":"1F539","🔸":"1F538","🔻":"1F53B","🔺":"1F53A","🔵":"1F535","🔴":"1F534","🔘":"1F518","⚫️":"26AB","⚫":"26AB","⚪️":"26AA","⚪":"26AA","🗵":"1F5F5","🗴":"1F5F4","🗹":"1F5F9","🗸":"1F5F8","☑️":"2611","♦️":"2666","♥️":"2665","♣️":"2663","♠️":"2660","💠":"1F4A0","💢":"1F4A2","♻️":"267B","♻":"267B","🏶":"1F3F6","🏵":"1F3F5","♨️":"2668","⚠️":"26A0","⚠":"26A0","🔱":"1F531","🗲":"1F5F2","🔰":"1F530","🔯":"1F52F","⛎":"26CE","🛈":"1F6C8","Ⓜ️":"24C2","Ⓜ":"24C2","🌀":"1F300","🔜":"1F51C","🔝":"1F51D","🔛":"1F51B","🔙":"1F519","🔚":"1F51A","💯":"1F4AF","⭕️":"2B55","⭕":"2B55","❌":"274C","🛆":"1F6C6","⁉️":"2049","‼️":"203C","‼":"203C","❗️":"2757","〽️":"303D","〽":"303D","➿":"27BF","➰":"27B0","💲":"1F4B2","💱":"1F4B1","®":"00AE","©":"00A9","🗘":"1F5D8","🔃":"1F503","🗙":"1F5D9","✔️":"2714","✖️":"2716","🔣":"1F523","🎦":"1F3A6","📶":"1F4F6","ℹ️":"2139","🔠":"1F520","🔡":"1F521","🔤":"1F524","🔢":"1F522","🔟":"1F51F","9️⃣":"0039-20E3","9⃣":"0039-20E3","8️⃣":"0038-20E3","8⃣":"0038-20E3","7️⃣":"0037-20E3","7⃣":"0037-20E3","6️⃣":"0036-20E3","6⃣":"0036-20E3","5️⃣":"0035-20E3","5⃣":"0035-20E3","4️⃣":"0034-20E3","4⃣":"0034-20E3","3️⃣":"0033-20E3","3⃣":"0033-20E3","2️⃣":"0032-20E3","2⃣":"0032-20E3","1️⃣":"0031-20E3","1⃣":"0031-20E3","0️⃣":"0030-20E3","0⃣":"0030-20E3","#️⃣":"0023-20E3","#⃣":"0023-20E3","🔂":"1F502","🔁":"1F501","🔀":"1F500","⤵️":"2935","⤴️":"2934","↩️":"21A9","↩":"21A9","↪️":"21AA","↪":"21AA","🔄":"1F504","↔️":"2194","↕️":"2195","↖️":"2196","↙️":"2199","↘️":"2198","↗️":"2197","⬇️":"2B07","⬇":"2B07","⬆️":"2B06","⬆":"2B06","⬅️":"2B05","⬅":"2B05","➡️":"27A1","➡":"27A1","⏬":"23EC","⏫":"23EB","⏪":"23EA","⏩":"23E9","🔽":"1F53D","🔼":"1F53C","◀️":"25C0","◀":"25C0","▶️":"25B6","▶":"25B6","🚮":"1F6AE","🚭":"1F6AD","🚰":"1F6B0","♿️":"267F","♿":"267F","🚼":"1F6BC","🛊":"1F6CA","🛉":"1F6C9","🚺":"1F6BA","🚹":"1F6B9","🚻":"1F6BB","♓️":"2653","♒️":"2652","♑️":"2651","♐️":"2650","♏️":"264F","♏":"264F","♎️":"264E","♎":"264E","♍️":"264D","♍":"264D","♌️":"264C","♌":"264C","♋️":"264B","♋":"264B","♊️":"264A","♊":"264A","♉️":"2649","♈️":"2648","🏧":"1F3E7","🆙":"1F199","🆗":"1F197","🆖":"1F196","🆕":"1F195","🆓":"1F193","🆒":"1F192","🚾":"1F6BE","🅿️":"1F17F","🅿":"1F17F","🆔":"1F194","🆘":"1F198","🅾":"1F17E","🆑":"1F191","🆎":"1F18E","🅱":"1F171","🅰":"1F170","🆚":"1F19A","📴":"1F4F4","📳":"1F4F3","✴️":"2734","❎":"274E","✳️":"2733","❇️":"2747","💹":"1F4B9","🈯️":"1F22F","🈯":"1F22F","🈁":"1F201","🈂":"1F202","🈳":"1F233","🈹":"1F239","🈷":"1F237","🈺":"1F23A","🈸":"1F238","🈚️":"1F21A","🈚":"1F21A","🈶":"1F236","🈲":"1F232","🈵":"1F235","🈴":"1F234","㊗️":"3297","㊙️":"3299","💮":"1F4AE","🉐":"1F250","🉑":"1F251","🕲":"1F572","🔞":"1F51E","📵":"1F4F5","🚱":"1F6B1","🚳":"1F6B3","🚯":"1F6AF","🚷":"1F6B7","📛":"1F4DB","⛔️":"26D4","⛔":"26D4","🚫":"1F6AB","🛇":"1F6C7","🛌":"1F6CC","🗣":"1F5E3","🔎":"1F50E","🔍":"1F50D","🛡":"1F6E1","🚸":"1F6B8","🗱":"1F5F1","🗰":"1F5F0","🗯":"1F5EF","🗮":"1F5EE","🗭":"1F5ED","🗬":"1F5EC","🗫":"1F5EB","🗪":"1F5EA","🗩":"1F5E9","🗨":"1F5E8","💬":"1F4AC","💭":"1F4AD","🕊":"1F54A","🕉":"1F549","🕈":"1F548","🕇":"1F547","🕆":"1F546","🎝":"1F39D","🎜":"1F39C","🕭":"1F56D","🔕":"1F515","🔔":"1F514","💤":"1F4A4","🕬":"1F56C","🕫":"1F56B","🕪":"1F56A","🕩":"1F569","🕨":"1F568","🔇":"1F507","🔊":"1F50A","🔉":"1F509","🔈":"1F508","📢":"1F4E2","📣":"1F4E3","🔓":"1F513","🔒":"1F512","🔐":"1F510","🔏":"1F50F","📝":"1F4DD","🖍":"1F58D","🖌":"1F58C","🖋":"1F58B","🖊":"1F58A","🖉":"1F589","✏️":"270F","✏":"270F","✒️":"2712","🗄":"1F5C4","📂":"1F4C2","📁":"1F4C1","🗁":"1F5C1","🗀":"1F5C0","🕳":"1F573","🏴":"1F3F4","🏳":"1F3F3","🏲":"1F3F2","🏱":"1F3F1","🚩":"1F6A9","📏":"1F4CF","📍":"1F4CD","📐":"1F4D0","✂️":"2702","🖈":"1F588","📌":"1F4CC","🖇":"1F587","📎":"1F4CE","🔗":"1F517","🗃":"1F5C3","🗂":"1F5C2","📇":"1F4C7","📚":"1F4DA","📙":"1F4D9","📘":"1F4D8","📗":"1F4D7","📕":"1F4D5","📒":"1F4D2","📔":"1F4D4","📓":"1F4D3","📖":"1F4D6","🕮":"1F56E","📋":"1F4CB","📜":"1F4DC","🖽":"1F5BD","🖼":"1F5BC","🖾":"1F5BE","🗜":"1F5DC","🔆":"1F506","🔅":"1F505","🗳":"1F5F3","🗓":"1F5D3","📆":"1F4C6","📅":"1F4C5","🗠":"1F5E0","📊":"1F4CA","📉":"1F4C9","📈":"1F4C8","🗒":"1F5D2","🗊":"1F5CA","🗉":"1F5C9","🗇":"1F5C7","🗆":"1F5C6","🗑":"1F5D1","📑":"1F4D1","🗐":"1F5D0","📃":"1F4C3","📄":"1F4C4","🗏":"1F5CF","🖹":"1F5B9","🗎":"1F5CE","📬":"1F4EC","📭":"1F4ED","📫":"1F4EB","📪":"1F4EA","📮":"1F4EE","📯":"1F4EF","📦":"1F4E6","📤":"1F4E4","📥":"1F4E5","📧":"1F4E7","📨":"1F4E8","📩":"1F4E9","🖆":"1F586","🖅":"1F585","🖃":"1F583","🖂":"1F582","✉️":"2709","🗝":"1F5DD","🔑":"1F511","🏷":"1F3F7","🌡":"1F321","🗞":"1F5DE","📰":"1F4F0","🔖":"1F516","🔫":"1F52B","🕱":"1F571","🚬":"1F6AC","💣":"1F4A3","🛢":"1F6E2","🛠":"1F6E0","🔨":"1F528","🔩":"1F529","🗡":"1F5E1","🔪":"1F52A","🔧":"1F527","🔮":"1F52E","🔭":"1F52D","🔬":"1F52C","💊":"1F48A","💉":"1F489","💈":"1F488","🚽":"1F6BD","🛁":"1F6C1","🚿":"1F6BF","🚪":"1F6AA","👖":"1F456","👔":"1F454","👕":"1F455","👚":"1F45A","👘":"1F458","👗":"1F457","👙":"1F459","👟":"1F45F","👞":"1F45E","👢":"1F462","👠":"1F460","👡":"1F461","👒":"1F452","🕶":"1F576","👓":"1F453","💄":"1F484","🎒":"1F392","💼":"1F4BC","👜":"1F45C","👛":"1F45B","👝":"1F45D","🌂":"1F302","💎":"1F48E","💰":"1F4B0","💸":"1F4B8","💳":"1F4B3","🛰":"1F6F0","📡":"1F4E1","🕯":"1F56F","🔦":"1F526","💡":"1F4A1","🔌":"1F50C","🔋":"1F50B","📼":"1F4FC","🖸":"1F5B8","📀":"1F4C0","💿":"1F4BF","🖴":"1F5B4","🖭":"1F5AD","🖫":"1F5AB","🖪":"1F5AA","💾":"1F4BE","💽":"1F4BD","📠":"1F4E0","🖁":"1F581","🕿":"1F57F","🕾":"1F57E","☎️":"260E","☎":"260E","🕻":"1F57B","📞":"1F4DE","🕹":"1F579","📟":"1F4DF","📾":"1F4FE","📻":"1F4FB","🎛":"1F39B","🎚":"1F39A","🎙":"1F399","🎘":"1F398","📺":"1F4FA","📽":"1F4FD","🎥":"1F3A5","📹":"1F4F9","📸":"1F4F8","📷":"1F4F7","⌛️":"231B","⌛":"231B","⏳":"23F3","🕰":"1F570","⏰":"23F0","🖩":"1F5A9","🗔":"1F5D4","🖨":"1F5A8","🖧":"1F5A7","🖦":"1F5A6","🖲":"1F5B2","🖯":"1F5AF","🖮":"1F5AE","🖳":"1F5B3","🖥":"1F5A5","💻":"1F4BB","📲":"1F4F2","📱":"1F4F1","⌚️":"231A","⌚":"231A","🍼":"1F37C","🍻":"1F37B","🍺":"1F37A","🍹":"1F379","🍸":"1F378","🍷":"1F377","🍶":"1F376","☕️":"2615","🍵":"1F375","🍴":"1F374","🍳":"1F373","🍲":"1F372","🍱":"1F371","🍰":"1F370","🍯":"1F36F","🍮":"1F36E","🍭":"1F36D","🍬":"1F36C","🍫":"1F36B","🍪":"1F36A","🍩":"1F369","🍨":"1F368","🍧":"1F367","🍦":"1F366","🍥":"1F365","🍤":"1F364","🍣":"1F363","🍢":"1F362","🍡":"1F361","🍟":"1F35F","🍞":"1F35E","🍝":"1F35D","🍜":"1F35C","🍛":"1F35B","🍚":"1F35A","🍙":"1F359","🍘":"1F358","🍗":"1F357","🍖":"1F356","🍕":"1F355","🍔":"1F354","🍓":"1F353","🍒":"1F352","🍑":"1F351","🍐":"1F350","🍏":"1F34F","🍎":"1F34E","🍍":"1F34D","🍌":"1F34C","🍋":"1F34B","🍊":"1F34A","🍉":"1F349","🍈":"1F348","🍇":"1F347","🌶":"1F336","🍠":"1F360","🌽":"1F33D","🍆":"1F346","🍅":"1F345","🎢":"1F3A2","🎡":"1F3A1","🎠":"1F3A0","🀄️":"1F004","🀄":"1F004","🃏":"1F0CF","🎴":"1F3B4","🎮":"1F3AE","🎲":"1F3B2","🎰":"1F3B0","🎳":"1F3B3","🎱":"1F3B1","🎯":"1F3AF","🎨":"1F3A8","🎟":"1F39F","🎞":"1F39E","🎬":"1F3AC","🎪":"1F3AA","🎩":"1F3A9","🎫":"1F3AB","🎭":"1F3AD","🎤":"1F3A4","🎧":"1F3A7","🎼":"1F3BC","🎶":"1F3B6","🎵":"1F3B5","🎺":"1F3BA","🎷":"1F3B7","🎻":"1F3BB","🎸":"1F3B8","🎹":"1F3B9","🏁":"1F3C1","🎽":"1F3BD","🏅":"1F3C5","🏆":"1F3C6","⛳️":"26F3","⛳":"26F3","🏉":"1F3C9","🎾":"1F3BE","⚾️":"26BE","⚾":"26BE","🏈":"1F3C8","🏀":"1F3C0","⚽️":"26BD","⚽":"26BD","🎣":"1F3A3","⛺️":"26FA","⛺":"26FA","🏇":"1F3C7","🏎":"1F3CE","🏍":"1F3CD","🚵":"1F6B5","🚴":"1F6B4","⛄️":"26C4","⛄":"26C4","🎿":"1F3BF","🏂":"1F3C2","🛀":"1F6C0","🏄":"1F3C4","🏊":"1F3CA","🚣":"1F6A3","🏌":"1F3CC","🏋":"1F3CB","💃":"1F483","🚶":"1F6B6","🏃":"1F3C3","💙":"1F499","💚":"1F49A","💛":"1F49B","💜":"1F49C","💟":"1F49F","🎔":"1F394","💝":"1F49D","💘":"1F498","💖":"1F496","💗":"1F497","💓":"1F493","💞":"1F49E","💕":"1F495","💌":"1F48C","💔":"1F494","❤️":"2764","🎕":"1F395","💍":"1F48D","🏮":"1F3EE","🎌":"1F38C","🎐":"1F390","🎏":"1F38F","🎎":"1F38E","🎖":"1F396","🎗":"1F397","👑":"1F451","🎓":"1F393","💥":"1F4A5","💫":"1F4AB","🎈":"1F388","🎊":"1F38A","🎉":"1F389","🎇":"1F387","🎆":"1F386","🎑":"1F391","🎍":"1F38D","🎋":"1F38B","🎄":"1F384","🎃":"1F383","🎂":"1F382","🎁":"1F381","🎀":"1F380","🌬":"1F32C","🌞":"1F31E","🌜":"1F31C","🌛":"1F31B","🌝":"1F31D","🌚":"1F31A","🌘":"1F318","🌗":"1F317","🌖":"1F316","🌕":"1F315","🌔":"1F314","🌓":"1F313","🌒":"1F312","🌑":"1F311","🌏":"1F30F","🌎":"1F30E","🌍":"1F30D","🌐":"1F310","🗾":"1F5FE","🗻":"1F5FB","🌌":"1F30C","🌋":"1F30B","🌊":"1F30A","🌈":"1F308","🌅":"1F305","🌄":"1F304","🌠":"1F320","⭐️":"2B50","⭐":"2B50","🌟":"1F31F","❄️":"2744","💨":"1F4A8","🌫":"1F32B","☔️":"2614","💦":"1F4A6","💧":"1F4A7","🌪":"1F32A","🌩":"1F329","🌨":"1F328","🌧":"1F327","☁️":"2601","⛅️":"26C5","⛅":"26C5","☀️":"2600","🌙":"1F319","🔥":"1F525","⚡️":"26A1","⚡":"26A1","🐾":"1F43E","🕸":"1F578","🕷":"1F577","🐞":"1F41E","🐝":"1F41D","🐜":"1F41C","🐛":"1F41B","🐌":"1F40C","🐚":"1F41A","🐡":"1F421","🐠":"1F420","🐟":"1F41F","🐙":"1F419","🐬":"1F42C","🐳":"1F433","🐋":"1F40B","🐸":"1F438","🐢":"1F422","🐍":"1F40D","🐊":"1F40A","🐲":"1F432","🐉":"1F409","🐒":"1F412","🙊":"1F64A","🙉":"1F649","🙈":"1F648","🐵":"1F435","🐼":"1F43C","🐨":"1F428","🐻":"1F43B","🐺":"1F43A","🐶":"1F436","🐩":"1F429","🐕":"1F415","🐽":"1F43D","🐷":"1F437","🐖":"1F416","🐗":"1F417","🐫":"1F42B","🐪":"1F42A","🐘":"1F418","🐧":"1F427","🐦":"1F426","🐥":"1F425","🐣":"1F423","🐤":"1F424","🐔":"1F414","🐓":"1F413","🐐":"1F410","🐑":"1F411","🐏":"1F40F","🐴":"1F434","🐎":"1F40E","🐱":"1F431","🐈":"1F408","🐰":"1F430","🐇":"1F407","🐿":"1F43F","🐯":"1F42F","🐆":"1F406","🐅":"1F405","🐮":"1F42E","🐄":"1F404","🐃":"1F403","🐂":"1F402","🐹":"1F439","🐭":"1F42D","🐁":"1F401","🐀":"1F400","🌰":"1F330","🍄":"1F344","🍃":"1F343","🍂":"1F342","🍁":"1F341","🍀":"1F340","🌿":"1F33F","🌾":"1F33E","💐":"1F490","🌼":"1F33C","🌻":"1F33B","🌺":"1F33A","🌹":"1F339","🌸":"1F338","🌷":"1F337","🌵":"1F335","🌴":"1F334","🌳":"1F333","🌲":"1F332","🌱":"1F331","🙏":"1F64F","🖟":"1F59F","🖞":"1F59E","🖙":"1F599","🖘":"1F598","🖗":"1F597","🖖":"1F596","🖕":"1F595","🖔":"1F594","🖓":"1F593","🖒":"1F592","🖑":"1F591","🖐":"1F590","🖏":"1F58F","🖎":"1F58E","👐":"1F450","💪":"1F4AA","✋":"270B","✊":"270A","👊":"1F44A","✌️":"270C","✌":"270C","👌":"1F44C","👉":"1F449","👈":"1F448","👇":"1F447","👆":"1F446","☝️":"261D","☝":"261D","👎":"1F44E","👍":"1F44D","👋":"1F44B","💅":"1F485","👅":"1F445","💋":"1F48B","🗢":"1F5E2","👄":"1F444","👃":"1F443","👀":"1F440","👁":"1F441","👂":"1F442","👏":"1F44F","🙌":"1F64C","👨‍❤️‍💋‍👨":"1F468-2764-1F48B-1F468","👨❤💋👨":"1F468-2764-1F48B-1F468","👩‍❤️‍💋‍👩":"1F469-2764-1F48B-1F469","👩❤💋👩":"1F469-2764-1F48B-1F469","💏":"1F48F","👨‍❤️‍👨":"1F468-2764-1F468","👨❤👨":"1F468-2764-1F468","👩‍❤️‍👩":"1F469-2764-1F469","👩❤👩":"1F469-2764-1F469","💑":"1F491","💇":"1F487","💆":"1F486","🙍":"1F64D","🙎":"1F64E","🙋":"1F64B","🙆":"1F646","🙅":"1F645","💁":"1F481","🙇":"1F647","👾":"1F47E","👽":"1F47D","💀":"1F480","💩":"1F4A9","👺":"1F47A","👹":"1F479","👻":"1F47B","🎅":"1F385","👼":"1F47C","💂":"1F482","👸":"1F478","👷":"1F477","👮":"1F46E","👵":"1F475","👴":"1F474","👳":"1F473","👲":"1F472","👱":"1F471","👰":"1F470","👯":"1F46F","👭":"1F46D","👬":"1F46C","👫":"1F46B","👨‍👨‍👧‍👧":"1F468-1F468-1F467-1F467","👨👨👧👧":"1F468-1F468-1F467-1F467","👨‍👨‍👦‍👦":"1F468-1F468-1F466-1F466","👨👨👦👦":"1F468-1F468-1F466-1F466","👨‍👨‍👧":"1F468-1F468-1F467","👨👨👧👦":"1F468-1F468-1F467-1F466","👨👨👧":"1F468-1F468-1F467","👨‍👨‍👦":"1F468-1F468-1F466","👨👨👦":"1F468-1F468-1F466","👩‍👩‍👧‍👧":"1F469-1F469-1F467-1F467","👩👩👧👧":"1F469-1F469-1F467-1F467","👩‍👩‍👦‍👦":"1F469-1F469-1F466-1F466","👩👩👦👦":"1F469-1F469-1F466-1F466","👩‍👩‍👧‍👦":"1F469-1F469-1F467-1F466","👩👩👧👦":"1F469-1F469-1F467-1F466","👩‍👩‍👧":"1F469-1F469-1F467","👩👩👧":"1F469-1F469-1F467","👩‍👩‍👦":"1F469-1F469-1F466","👩👩👦":"1F469-1F469-1F466","👨‍👩‍👧‍👧":"1F468-1F469-1F467-1F467","👨👩👧👧":"1F468-1F469-1F467-1F467","👨‍👩‍👦‍👦":"1F468-1F469-1F466-1F466","👨👩👦👦":"1F468-1F469-1F466-1F466","👨‍👩‍👧‍👦":"1F468-1F469-1F467-1F466","👨👩👧👦":"1F468-1F469-1F467-1F466","👨‍👩‍👧":"1F468-1F469-1F467","👨👩👧":"1F468-1F469-1F467","👪":"1F46A","👩":"1F469","👨":"1F468","👧":"1F467","👦":"1F466","👶":"1F476","🕵":"1F575","🕴":"1F574","👥":"1F465","👤":"1F464","👣":"1F463","🙀":"1F640","😿":"1F63F","😾":"1F63E","😽":"1F63D","😼":"1F63C","😻":"1F63B","😺":"1F63A","😹":"1F639","😸":"1F638","🙂":"1F642","🙁":"1F641","😷":"1F637","😶":"1F636","😵":"1F635","😴":"1F634","😳":"1F633","😲":"1F632","😱":"1F631","😰":"1F630","😯":"1F62F","😮":"1F62E","😭":"1F62D","😬":"1F62C","😫":"1F62B","😪":"1F62A","😩":"1F629","😨":"1F628","😧":"1F627","😦":"1F626","😥":"1F625","😤":"1F624","😣":"1F623","😢":"1F622","😡":"1F621","😠":"1F620","😟":"1F61F","😞":"1F61E","😝":"1F61D","😜":"1F61C","😛":"1F61B","😚":"1F61A","😙":"1F619","😘":"1F618","😗":"1F617","😖":"1F616","😕":"1F615","😔":"1F614","😓":"1F613","😒":"1F612","😑":"1F611","😐":"1F610","😏":"1F60F","😎":"1F60E","😍":"1F60D","😌":"1F60C","😋":"1F60B","☺️":"263A","☺":"263A","😊":"1F60A","😉":"1F609","👿":"1F47F","😈":"1F608","😇":"1F607","😆":"1F606","😅":"1F605","😄":"1F604","😃":"1F603","😂":"1F602","😁":"1F601","😀":"1F600"},a.shortnameRegexp=":([-+\\w]+):",a.imagePathPNG="//cdn.jsdelivr.net/emojione/assets/png/",a.imagePathSVG="//cdn.jsdelivr.net/emojione/assets/svg/",a.imagePathSVGSprites="./../assets/sprites/emojione.sprites.svg",a.imageType="png",a.sprites=!1,a.unicodeAlt=!0,a.ascii=!1,a.cacheBustParam="?v=1.2.4",a.toImage=function(b){return b=a.unicodeToImage(b),b=a.shortnameToImage(b)},a.unifyUnicode=function(b){return b=a.toShort(b),b=a.shortnameToUnicode(b)},a.shortnameToAscii=function(b){var c,d=a.objectFlip(a.asciiList);return b=b.replace(new RegExp("<object[^>]*>.*?</object>|<span[^>]*>.*?</span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|("+a.shortnameRegexp+")","gi"),function(b){return"undefined"!=typeof b&&""!==b&&b in a.emojioneList?(c=a.emojioneList[b][a.emojioneList[b].length-1].toLowerCase(),"undefined"!=typeof d[c]?d[c]:b):b})},a.shortnameToUnicode=function(b){var c;return b=b.replace(new RegExp("<object[^>]*>.*?</object>|<span[^>]*>.*?</span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|("+a.shortnameRegexp+")","gi"),function(b){return"undefined"!=typeof b&&""!==b&&b in a.emojioneList?(c=a.emojioneList[b][a.emojioneList[b].length-1].toUpperCase(),a.convert(c)):b}),a.ascii&&(b=b.replace(new RegExp("<object[^>]*>.*?</object>|<span[^>]*>.*?</span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|((\\s|^)"+a.asciiRegexp+"(?=\\s|$|[!,.]))","g"),function(b,d,e,f){return"undefined"!=typeof f&&""!==f&&a.unescapeHTML(f)in a.asciiList?(f=a.unescapeHTML(f),c=a.asciiList[f].toUpperCase(),e+a.convert(c)):b})),b},a.shortnameToImage=function(b){var c,d,e;return b=b.replace(new RegExp("<object[^>]*>.*?</object>|<span[^>]*>.*?</span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|("+a.shortnameRegexp+")","gi"),function(b){return"undefined"!=typeof b&&""!==b&&b in a.emojioneList?(d=a.emojioneList[b][a.emojioneList[b].length-1].toUpperCase(),e=a.unicodeAlt?a.convert(d):b,c="png"===a.imageType?a.sprites?'<span class="emojione-'+d+'" title="'+b+'">'+e+"</span>":'<img class="emojione" alt="'+e+'" src="'+a.imagePathPNG+d+".png"+a.cacheBustParam+'"/>':a.sprites?'<svg class="emojione"><description>'+e+'</description><use xlink:href="'+a.imagePathSVGSprites+"#emoji-"+d+'"></use></svg>':'<object class="emojione" data="'+a.imagePathSVG+d+".svg"+a.cacheBustParam+'" type="image/svg+xml" standby="'+e+'">'+e+"</object>"):b}),a.ascii&&(b=b.replace(new RegExp("<object[^>]*>.*?</object>|<span[^>]*>.*?</span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|((\\s|^)"+a.asciiRegexp+"(?=\\s|$|[!,.]))","g"),function(b,f,g,h){return"undefined"!=typeof h&&""!==h&&a.unescapeHTML(h)in a.asciiList?(h=a.unescapeHTML(h),d=a.asciiList[h].toUpperCase(),e=a.unicodeAlt?a.convert(d):a.escapeHTML(h),c="png"===a.imageType?a.sprites?g+'<span class="emojione-'+d.toUpperCase()+'" title="'+a.escapeHTML(h)+'">'+e+"</span>":g+'<img class="emojione" alt="'+e+'" src="'+a.imagePathPNG+d+".png"+a.cacheBustParam+'"/>':a.sprites?'<svg class="emojione"><description>'+e+'</description><use xlink:href="'+a.imagePathSVGSprites+"#emoji-"+d.toUpperCase()+'"></use></svg>':g+'<object class="emojione" data="'+a.imagePathSVG+d+".svg"+a.cacheBustParam+'" type="image/svg+xml" standby="'+e+'">'+e+"</object>"):b})),b},a.unicodeToImage=function(b){var c,d,e;if(!a.unicodeAlt||a.sprites)var f=a.mapShortToUnicode();return b=b.replace(new RegExp("<object[^>]*>.*?</object>|<span[^>]*>.*?</span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|("+a.unicodeRegexp+")","gi"),function(b){return"undefined"!=typeof b&&""!==b&&b in a.jsecapeMap?(d=a.jsecapeMap[b],e=a.unicodeAlt?a.convert(d):f[d],c="png"===a.imageType?a.sprites?'<span class="emojione-'+d.toUpperCase()+'" title="'+f[d]+'">'+e+"</span>":'<img class="emojione" alt="'+e+'" src="'+a.imagePathPNG+d+".png"+a.cacheBustParam+'"/>':a.sprites?'<svg class="emojione"><description>'+e+'</description><use xlink:href="'+a.imagePathSVGSprites+"#emoji-"+d.toUpperCase()+'"></use></svg>':'<img class="emojione" alt="'+e+'" src="'+a.imagePathSVG+d+".svg"+a.cacheBustParam+'"/>'):b})},a.toShort=function(b){for(var c in a.emojioneList)if(a.emojioneList.hasOwnProperty(c))for(var d=0,e=a.emojioneList[c].length;e>d;d++){var f=a.emojioneList[c][d].toUpperCase();b=a.replaceAll(b,a.convert(f),c)}return b},a.convert=function(a){if(a.indexOf("-")>-1){for(var b=[],c=a.split("-"),d=0;d<c.length;d++){var e=parseInt(c[d],16);if(e>=65536&&1114111>=e){var f=Math.floor((e-65536)/1024)+55296,g=(e-65536)%1024+56320;e=String.fromCharCode(f)+String.fromCharCode(g)}else e=String.fromCharCode(e);b.push(e)}return b.join("")}var c=parseInt(a,16);if(c>=65536&&1114111>=c){var f=Math.floor((c-65536)/1024)+55296,g=(c-65536)%1024+56320;return String.fromCharCode(f)+String.fromCharCode(g)}return String.fromCharCode(c)},a.escapeHTML=function(a){var b={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"};return a.replace(/[&<>"']/g,function(a){return b[a]})},a.unescapeHTML=function(a){var b={"&amp;":"&","&#38;":"&","&#x26;":"&","&lt;":"<","&#60;":"<","&#x3C;":"<","&gt;":">","&#62;":">","&#x3E;":">","&quot;":'"',"&#34;":'"',"&#x22;":'"',"&apos;":"'","&#39;":"'","&#x27;":"'"};return a.replace(/&(?:amp|#38|#x26|lt|#60|#x3C|gt|#62|#x3E|apos|#39|#x27|quot|#34|#x22);/gi,function(a){return b[a]})},a.mapShortToUnicode=function(){var b={};for(var c in a.emojioneList)if(a.emojioneList.hasOwnProperty(c))for(var d=0,e=a.emojioneList[c].length;e>d;d++)b[a.emojioneList[c][d].toUpperCase()]=c;return b},a.objectFlip=function(a){var b,c={};for(b in a)a.hasOwnProperty(b)&&(c[a[b]]=b);return c},a.escapeRegExp=function(a){return a.replace(/[-[\]{}()*+?.,;:&\\^$|#\s]/g,"\\$&")},a.replaceAll=function(a,b,c){var d=new RegExp("<object[^>]*>.*?</object>|<span[^>]*>.*?</span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|("+b+")","gi"),e=function(a,b){return"undefined"==typeof b||""===b?a:c};return a.replace(d,e)}}(this.emojione=this.emojione||{}),"object"==typeof module&&(module.exports=this.emojione);





(function(document, window, $, emojione) {
    'use strict';

    var blankImg = 'data:image/gif;base64,R0lGODlhAQABAJH/AP///wAAAMDAwAAAACH5BAEAAAIALAAAAAABAAEAAAICVAEAOw==';

    var default_options = {
        template          : "<editor/><filters/><tabs/>",

        dir               : "ltr",
        spellcheck        : false,
        autocomplete      : "off",
        autocorrect       : "off",
        autocapitalize    : "off",

        placeholder       : null,
        container         : null,
        hideSource        : true,
        autoHideFilters   : false,

        useSprite         : true,

        filters: {
            people: {
                icon: "yum",
                emoji: "grinning,grin,joy,smiley,smile,sweat_smile,laughing,innocent,smiling_imp,imp,wink,blush," +
                "relaxed,yum,relieved,heart_eyes,sunglasses,smirk,neutral_face,expressionless,unamused,sweat," +
                "pensive,confused,confounded,kissing,kissing_heart,kissing_smiling_eyes,kissing_closed_eyes," +
                "stuck_out_tongue,stuck_out_tongue_winking_eye,stuck_out_tongue_closed_eyes,disappointed,worried," +
                "angry,rage,cry,persevere,triumph,disappointed_relieved,frowning,anguished,fearful,weary," +
                "sleepy,tired_face,grimacing,sob,open_mouth,hushed,cold_sweat,scream,astonished,flushed," +
                "sleeping,dizzy_face,no_mouth,mask,slight_frown,slight_smile,smile_cat,joy_cat,smiley_cat," +
                "heart_eyes_cat,smirk_cat,kissing_cat,pouting_cat,crying_cat_face,scream_cat,footprints," +
                "bust_in_silhouette,busts_in_silhouette,levitate,spy,baby,boy,girl,man,woman,family," +
                "family_mwg,family_mwgb,family_mwbb,family_mwgg,family_wwb,family_wwg,family_wwgb,family_wwbb," +
                "family_wwgg,family_mmb,family_mmg,family_mmgb,family_mmbb,family_mmgg,couple,two_men_holding_hands," +
                "two_women_holding_hands,dancers,bride_with_veil,person_with_blond_hair,man_with_gua_pi_mao," +
                "man_with_turban,older_man,older_woman,cop,construction_worker,princess,guardsman,angel," +
                "santa,ghost,japanese_ogre,japanese_goblin,poop,skull,alien,space_invader,bow," +
                "information_desk_person,no_good,ok_woman,raising_hand,person_with_pouting_face,person_frowning," +
                "massage,haircut,couple_with_heart,couple_ww,couple_mm,couplekiss,kiss_ww,kiss_mm,raised_hands," +
                "clap,ear,eye,eyes,nose,lips,kiss,tongue,nail_care,wave,thumbsup,thumbsdown," +
                "point_up,point_up_2,point_down,point_left,point_right,ok_hand,v,punch,fist,raised_hand," +
                "muscle,open_hands,writing_hand,hand_splayed,middle_finger,vulcan,pray"
            },

            nature: {
                icon: "whale",
                emoji: "seedling,evergreen_tree,deciduous_tree,palm_tree,cactus,tulip,cherry_blossom,rose,hibiscus," +
                "sunflower,blossom,bouquet,ear_of_rice,herb,four_leaf_clover,maple_leaf,fallen_leaf,leaves," +
                "mushroom,chestnut,rat,mouse2,mouse,hamster,ox,water_buffalo,cow2,cow,tiger2,leopard," +
                "tiger,chipmunk,rabbit2,rabbit,cat2,cat,racehorse,horse,ram,sheep,goat,rooster,chicken," +
                "baby_chick,hatching_chick,hatched_chick,bird,penguin,elephant,dromedary_camel,camel,boar,pig2," +
                "pig,pig_nose,dog2,poodle,dog,wolf,bear,koala,panda_face,monkey_face,see_no_evil,hear_no_evil," +
                "speak_no_evil,monkey,dragon,dragon_face,crocodile,snake,turtle,frog,whale2,whale,dolphin," +
                "octopus,fish,tropical_fish,blowfish,shell,snail,bug,ant,bee,beetle,spider,spider_web,feet," +
                "zap,fire,crescent_moon,sunny,partly_sunny,cloud,cloud_rain,cloud_snow,cloud_lightning,cloud_tornado," +
                "droplet,sweat_drops,umbrella,fog,dash,snowflake,star2,star,stars,sunrise_over_mountains,sunrise," +
                "rainbow,ocean,volcano,milky_way,mount_fuji,japan,globe_with_meridians,earth_africa,earth_americas," +
                "earth_asia,new_moon,waxing_crescent_moon,first_quarter_moon,waxing_gibbous_moon,full_moon," +
                "waning_gibbous_moon,last_quarter_moon,waning_crescent_moon,new_moon_with_face,full_moon_with_face," +
                "first_quarter_moon_with_face,last_quarter_moon_with_face,sun_with_face,wind_blowing_face"
            },

            food_drink: {
                icon: "cherries",
                emoji: "tomato,eggplant,corn,sweet_potato,hot_pepper,grapes,melon,watermelon,tangerine,lemon," +
                "banana,pineapple,apple,green_apple,pear,peach,cherries,strawberry,hamburger,pizza,meat_on_bone," +
                "poultry_leg,rice_cracker,rice_ball,rice,curry,ramen,spaghetti,bread,fries,dango,oden,sushi," +
                "fried_shrimp,fish_cake,icecream,shaved_ice,ice_cream,doughnut,cookie,chocolate_bar,candy," +
                "lollipop,custard,honey_pot,cake,bento,stew,egg,fork_and_knife,tea,coffee,sake,wine_glass," +
                "cocktail,tropical_drink,beer,beers,baby_bottle"
            },

            celebration: {
                icon: "tada",
                emoji: "ribbon,gift,birthday,jack_o_lantern,christmas_tree,tanabata_tree,bamboo,rice_scene," +
                "fireworks,sparkler,tada,confetti_ball,balloon,dizzy,sparkles,boom,mortar_board,crown," +
                "reminder_ribbon,military_medal,dolls,flags,wind_chime,crossed_flags,izakaya_lantern,ring," +
                "heart,broken_heart,love_letter,two_hearts,revolving_hearts,heartbeat,heartpulse,sparkling_heart," +
                "cupid,gift_heart,heart_decoration,purple_heart,yellow_heart,green_heart,blue_heart"
            },

            activity: {
                icon: "trophy",
                emoji: "runner,walking,dancer,lifter,golfer,rowboat,swimmer,surfer,bath,snowboarder,ski," +
                "snowman,bicyclist,mountain_bicyclist,motorcycle,race_car,horse_racing,tent,fishing_pole_and_fish," +
                "soccer,basketball,football,baseball,tennis,rugby_football,golf,trophy,medal,running_shirt_with_sash," +
                "checkered_flag,musical_keyboard,guitar,violin,saxophone,trumpet,musical_note,notes,musical_score," +
                "headphones,microphone,performing_arts,ticket,tophat,circus_tent,clapper,film_frames,tickets," +
                "art,dart,8ball,bowling,slot_machine,game_die,video_game,flower_playing_cards,black_joker," +
                "mahjong,carousel_horse,ferris_wheel,roller_coaster"
            },

            travel: {
                icon: "rocket",
                emoji: "railway_car,mountain_railway,steam_locomotive,train,monorail,bullettrain_side," +
                "bullettrain_front,train2,metro,light_rail,station,tram,railway_track,bus,oncoming_bus," +
                "trolleybus,minibus,ambulance,fire_engine,police_car,oncoming_police_car,rotating_light,taxi," +
                "oncoming_taxi,red_car,oncoming_automobile,blue_car,truck,articulated_lorry,tractor,bike," +
                "motorway,busstop,fuelpump,construction,vertical_traffic_light,traffic_light,rocket,helicopter," +
                "airplane,airplane_small,airplane_departure,airplane_arriving,seat,anchor,ship,cruise_ship," +
                "motorboat,speedboat,sailboat,aerial_tramway,mountain_cableway,suspension_railway," +
                "passport_control,customs,baggage_claim,left_luggage,yen,euro,pound,dollar,bellhop,bed," +
                "couch,fork_knife_plate,shopping_bags,statue_of_liberty,moyai,foggy,tokyo_tower,fountain," +
                "european_castle,japanese_castle,classical_building,stadium,mountain_snow,camping,beach," +
                "desert,island,park,cityscape,city_sunset,city_dusk,night_with_stars,bridge_at_night,house," +
                "homes,house_with_garden,house_abandoned,contruction_site,office,department_store,factory," +
                "post_office,european_post_office,hospital,bank,hotel,love_hotel,wedding,church," +
                "convenience_store,school,map"
            },

            objects_symbols: {
                icon: "paperclips",
                emoji: "watch,iphone,calling,computer,desktop,keyboard,trackball,printer,alarm_clock,clock," +
                "hourglass_flowing_sand,hourglass,camera,camera_with_flash,video_camera,movie_camera,projector," +
                "tv,microphone2,level_slider,control_knobs,radio,pager,joystick,telephone_receiver,telephone," +
                "fax,minidisc,floppy_disk,cd,dvd,vhs,battery,electric_plug,bulb,flashlight,candle,satellite," +
                "satellite_orbital,credit_card,money_with_wings,moneybag,gem,closed_umbrella,pouch,purse," +
                "handbag,briefcase,school_satchel,lipstick,eyeglasses,dark_sunglasses,womans_hat,sandal," +
                "high_heel,boot,mans_shoe,athletic_shoe,bikini,dress,kimono,womans_clothes,shirt,necktie," +
                "jeans,door,shower,bathtub,toilet,barber,syringe,pill,microscope,telescope,crystal_ball," +
                "wrench,knife,dagger,nut_and_bolt,hammer,tools,oil,bomb,smoking,gun,bookmark,newspaper," +
                "newspaper2,thermometer,label,key,key2,envelope,envelope_with_arrow,incoming_envelope,email," +
                "inbox_tray,outbox_tray,package,postal_horn,postbox,mailbox_closed,mailbox,mailbox_with_no_mail," +
                "mailbox_with_mail,page_facing_up,page_with_curl,bookmark_tabs,wastebasket,notepad_spiral," +
                "chart_with_upwards_trend,chart_with_downwards_trend,bar_chart,date,calendar,calendar_spiral," +
                "ballot_box,low_brightness,high_brightness,compression,frame_photo,scroll,clipboard,book," +
                "notebook,notebook_with_decorative_cover,ledger,closed_book,green_book,blue_book,orange_book," +
                "books,card_index,dividers,card_box,link,paperclip,paperclips,pushpin,scissors," +
                "triangular_ruler,round_pushpin,straight_ruler,triangular_flag_on_post,flag_white,flag_black," +
                "hole,file_folder,open_file_folder,file_cabinet,black_nib,pencil2,pen_ballpoint,pen_fountain," +
                "paintbrush,crayon,pencil,lock_with_ink_pen,closed_lock_with_key,lock,unlock,mega,loudspeaker," +
                "speaker,sound,loud_sound,mute,zzz,bell,no_bell,cross_heavy,om_symbol,dove,thought_balloon," +
                "speech_balloon,anger_right,children_crossing,shield,mag,mag_right,speaking_head," +
                "sleeping_accommodation,no_entry_sign,no_entry,name_badge,no_pedestrians,do_not_litter," +
                "no_bicycles,non_potable_water,no_mobile_phones,underage,sparkle,eight_spoked_asterisk," +
                "negative_squared_cross_mark,white_check_mark,eight_pointed_black_star,vibration_mode," +
                "mobile_phone_off,vs,a,b,ab,cl,o2,sos,id,parking,wc,cool,free,new,ng,ok,up,atm," +
                "aries,taurus,gemini,cancer,leo,virgo,libra,scorpius,sagittarius,capricorn,aquarius," +
                "pisces,restroom,mens,womens,baby_symbol,wheelchair,potable_water,no_smoking," +
                "put_litter_in_its_place,arrow_forward,arrow_backward,arrow_up_small,arrow_down_small," +
                "fast_forward,rewind,arrow_double_up,arrow_double_down,arrow_right,arrow_left,arrow_up," +
                "arrow_down,arrow_upper_right,arrow_lower_right,arrow_lower_left,arrow_upper_left,arrow_up_down," +
                "left_right_arrow,arrows_counterclockwise,arrow_right_hook,leftwards_arrow_with_hook," +
                "arrow_heading_up,arrow_heading_down,twisted_rightwards_arrows,repeat,repeat_one,hash," +
                "zero,one,two,three,four,five,six,seven,eight,nine,keycap_ten,1234,abc,abcd,capital_abcd," +
                "information_source,signal_strength,cinema,symbols,heavy_plus_sign,heavy_minus_sign,wavy_dash," +
                "heavy_division_sign,heavy_multiplication_x,heavy_check_mark,arrows_clockwise,tm,copyright," +
                "registered,currency_exchange,heavy_dollar_sign,curly_loop,loop,part_alternation_mark," +
                "exclamation,question,grey_exclamation,grey_question,bangbang,interrobang,x,o,100,end," +
                "back,on,top,soon,cyclone,m,ophiuchus,six_pointed_star,beginner,trident,warning," +
                "hotsprings,rosette,recycle,anger,diamond_shape_with_a_dot_inside,spades,clubs,hearts," +
                "diamonds,ballot_box_with_check,white_circle,black_circle,radio_button,red_circle," +
                "large_blue_circle,small_red_triangle,small_red_triangle_down,small_orange_diamond," +
                "small_blue_diamond,large_orange_diamond,large_blue_diamond,black_small_square," +
                "white_small_square,black_large_square,white_large_square,black_medium_square,white_medium_square," +
                "black_medium_small_square,white_medium_small_square,black_square_button,white_square_button," +
                "clock1,clock2,clock3,clock4,clock5,clock6,clock7,clock8,clock9,clock10,clock11," +
                "clock12,clock130,clock230,clock330,clock430,clock530,clock630,clock730,clock830,clock930," +
                "clock1030,clock1130,clock1230"
            },

            flags: {
                icon: "triangular_flag_on_post",
                emoji: "au,at,be,br,ca,flag_cl,cn,co,dk,fi,fr,de,hk,in,flag_id,ie,il,it,jp,kr,mo," +
                "my,mx,nl,nz,no,ph,pl,pt,pr,ru,flag_sa,sg,za,es,se,ch,tr,gb,us,ae,vn,af,al,dz," +
                "ad,ao,ai,ag,ar,am,aw,ac,az,bs,bh,bd,bb,by,bz,bj,bm,bt,bo,ba,bw,bn,bg,bf,bi," +
                "kh,cm,cv,ky,cf,km,flag_cd,cg,td,cr,ci,hr,cu,cy,cz,dj,dm,do,tl,ec,eg,sv,gq,er," +
                "ee,et,fk,fo,fj,pf,ga,gm,ge,gh,gi,gr,gl,gd,gu,gt,gn,gw,gy,ht,hn,hu,is,ir,iq,jm," +
                "je,jo,kz,ke,ki,xk,kw,kg,la,lv,lb,ls,lr,ly,li,lt,lu,mk,mg,mw,mv,ml,mt,mh,mr,mu," +
                "fm,md,mc,mn,me,ms,ma,mz,mm,na,nr,np,nc,ni,ne,flag_ng,nu,kp,om,pk,pw,ps,pa,pg," +
                "py,pe,qa,ro,rw,sh,kn,lc,vc,ws,sm,st,sn,rs,sc,sl,sk,si,sb,so,lk,sd,sr,sz,sy,tw,tj," +
                "tz,th,tg,to,tt,tn,flag_tm,flag_tv,vi,ug,ua,uy,uz,vu,va,ve,wf,eh,ye,zm,zw"
            }
        }
    };

    var slice = [].slice,
        saveSelection, restoreSelection,
        emojioneList = {},
        eventStorage = {};

    $.each(emojione.emojioneList, function(shortname, keys) {
        // fix shortnames for emojione v1.5.0
        emojioneList[shortname.replace('-', '_')] = keys;
    });

    if (window.getSelection && document.createRange) {
        saveSelection = function(containerEl) {
            var range = window.getSelection().getRangeAt(0);
            var preSelectionRange = range.cloneRange();
            preSelectionRange.selectNodeContents(containerEl);
            preSelectionRange.setEnd(range.startContainer, range.startOffset);
            var start = preSelectionRange.toString().length;

            return {
                start: start,
                end: start + textFromHtml($("<div/>").append(range.extractContents()).html()).length
            };
        };

        restoreSelection = function(containerEl, savedSel) {
            var charIndex = 0, range = document.createRange();
            range.setStart(containerEl, 0);
            range.collapse(true);
            var nodeStack = [containerEl], node, foundStart = false, stop = false;

            while (!stop && (node = nodeStack.pop())) {
                if (node.nodeType == 3) {
                    var nextCharIndex = charIndex + node.length;
                    if (!foundStart && savedSel.start >= charIndex && savedSel.start <= nextCharIndex) {
                        range.setStart(node, savedSel.start - charIndex);
                        foundStart = true;
                    }
                    if (foundStart && savedSel.end >= charIndex && savedSel.end <= nextCharIndex) {
                        range.setEnd(node, savedSel.end - charIndex);
                        stop = true;
                    }
                    charIndex = nextCharIndex;
                } else {
                    var i = node.childNodes.length;
                    while (i--) {
                        nodeStack.push(node.childNodes[i]);
                    }
                }
            }

            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        }
    } else if (document.selection && document.body.createTextRange) {
        saveSelection = function(containerEl) {
            var selectedTextRange = document.selection.createRange();
            var preSelectionTextRange = document.body.createTextRange();
            preSelectionTextRange.moveToElementText(containerEl);
            preSelectionTextRange.setEndPoint("EndToStart", selectedTextRange);
            var start = preSelectionTextRange.text.length;

            return {
                start: start,
                end: start + selectedTextRange.text.length
            }
        };

        restoreSelection = function(containerEl, savedSel) {
            var textRange = document.body.createTextRange();
            textRange.moveToElementText(containerEl);
            textRange.collapse(true);
            textRange.moveEnd("character", savedSel.end);
            textRange.moveStart("character", savedSel.start);
            textRange.select();
        };
    }

    function pasteHtmlAtCaret(html) {
        var sel, range;
        if (window.getSelection) {
            // IE9 and non-IE
            sel = window.getSelection();
            if (sel.getRangeAt && sel.rangeCount) {
                range = sel.getRangeAt(0);
                range.deleteContents();

                // Range.createContextualFragment() would be useful here but is
                // only relatively recently standardized and is not supported in
                // some browsers (IE9, for one)
                var el = document.createElement("div");
                el.innerHTML = html;
                var frag = document.createDocumentFragment(), node, lastNode;
                while ( (node = el.firstChild) ) {
                    lastNode = frag.appendChild(node);
                }
                range.insertNode(frag);

                // Preserve the selection
                if (lastNode) {
                    range = range.cloneRange();
                    range.setStartAfter(lastNode);
                    range.collapse(true);
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
            }
        } else if (document.selection && document.selection.type != "Control") {
            // IE < 9
            document.selection.createRange().pasteHTML(html);
        }
    }

    function time() {
        return (new Date()).getTime();
    }

    var EmojioneArea = function(element, options) {
        init.apply(this, [element, options]);
    };

    EmojioneArea.prototype.on = function(events, handler) {
        var id = this.id;
        if (!!events && $.isFunction(handler)) {
            $.each(events.toLowerCase().split(' '), function(i, event) {
                if (!eventStorage[id][event]) {
                    eventStorage[id][event] = [];
                }
                eventStorage[id][event].push(handler);
            });
        }
        return this;
    };

    EmojioneArea.prototype.off = function(events, handler) {
        var id = this.id,
            // disabling turn off the system events
            system = /^@/;
        if (!!events) {
            $.each(events.toLowerCase().split(' '), function(i, event) {
                if (!!eventStorage[id][event] && !system.test(event)) {
                    if (!!handler) {
                        $.each(eventStorage[id][event], function(j, fn) {
                            if (fn === handler) {
                                eventStorage[id][event] = eventStorage[id][event].splice(j, 1);
                            }
                        });
                    } else {
                        eventStorage[id][event] = [];
                    }
                }
            });
        }
        return this;
    };

    function trigger(self, event, args) {
        var result = true, j = 1;
        if (!!event) {
            event = event.toLowerCase();
            args = args || [];
            do {
                var _event = j==1 ? '@' + event : event;
                if (!!eventStorage[self.id][_event] && !!eventStorage[self.id][_event].length) {
                    $.each(eventStorage[self.id][_event], function (i, fn) {
                        return result = fn.apply(self, args) !== false;
                    });
                }
            } while (result && !!j--);
        }
        return result;
    }

    function getTarget(event, callerEvent) {
        return $(callerEvent.currentTarget);
    };

    function attach(self, element, events, target) {
        target = target || getTarget;

        function attachEvents(element, event, handler) {
            element.on(event, function() {
                var _target = $.isFunction(target) ? target.apply(self, [event].concat(slice.call(arguments))) : target;
                if (!!_target) {
                    trigger(self, handler, [_target].concat(slice.call(arguments)));
                }
            });
        }

        function attachElement(element) {
            if ((typeof events).toLowerCase() === "string") {
                attachEvents(element, events, events);
            } else {
                $.each(events, function(event, handler) {
                    attachEvents(element, $.isArray(events) ? handler : event, handler);
                });
            }
        }

        if ($.isArray(element)) {
            $.each(element, function(i, el) {
                attachElement($(el));
            });
        } else {
            attachElement(element);
        }
    }

    function htmlFromText(str, self) {
        return unicodeTo(str
            .replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/(?:\r\n|\r|\n)/g, '\n')
            .replace(/(\n+)/g, '<div>$1</div>')
            .replace(/\n/g, '<br/>')
            .replace(/<br\/><\/div>/g, '</div>'),
            '<img alt="{alt}" class="emojione' + (self.sprite ? '-{uni}" src="'+blankImg+'">' : '" src="{img}">'))
            .replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;')
            .replace(/  /g, '&nbsp;&nbsp;');
    }

    function textFromHtml(str) {
        return str
            .replace(/<img[^>]*alt="([^"]+)"[^>]*>/ig, '$1')
            .replace(/\n|\r/g, '')
            .replace(/<br[^>]*>/ig, '\n')
            .replace(/(?:<(?:div|p|ol|ul|li|pre|code|object)[^>]*>)+/ig, '<div>')
            .replace(/(?:<\/(?:div|p|ol|ul|li|pre|code|object)>)+/ig, '</div>')
            .replace(/\n<div><\/div>/ig, '\n')
            .replace(/<div><\/div>\n/ig, '\n')
            .replace(/(?:<div>)+<\/div>/ig, '\n')
            .replace(/([^\n])<\/div><div>/ig, '$1\n')
            .replace(/(?:<\/div>)+/ig, '</div>')
            .replace(/([^\n])<\/div>([^\n])/ig, '$1\n$2')
            .replace(/<\/div>/ig, '')
            .replace(/([^\n])<div>/ig, '$1\n')
            .replace(/\n<div>/ig, '\n')
            .replace(/<div>\n/ig, '\n\n')
            .replace(/<(?:[^>]+)?>/g, '')
            .replace(/&nbsp;/g, ' ')
            .replace(/\x20\x20/g, '&nbsp; ')
            .replace(/\x20\x20/g, ' &nbsp;');
    }

    EmojioneArea.prototype.setText = function(str) {
        var self = this;
        self.editor.html(htmlFromText(str, self));
        self.content = self.editor.html();
        if (arguments.length === 1) {
            trigger(self, 'change', [self.editor]);
        }
    }

    EmojioneArea.prototype.getText = function() {
        return textFromHtml(this.editor.html());
    }
	
	
    EmojioneArea.prototype.showPicker = function () {
        var self = this;
        if (self._sh_timer) {
            window.clearTimeout(self._sh_timer);
        }
        self.picker.removeClass("hidden");
        self._sh_timer =  window.setTimeout(function() {
            self.button.addClass("active");
        }, 50);
        trigger(self, "picker.show", [self.picker]);
        return self;
    }

    EmojioneArea.prototype.hidePicker = function () {
        var self = this;
        if (self._sh_timer) {
            window.clearTimeout(self._sh_timer);
        }
        self.button.removeClass("active");
        self._sh_timer =  window.setTimeout(function() {
            self.picker.addClass("hidden");
        }, 500);
        trigger(self, "picker.hide", [self.picker]);
        return self;
    }

    EmojioneArea.prototype.enable = function () {
        var self = this;
        var next = function () {
            self.disabled = false;
            self.editor.prop('contenteditable', true);
            self.button.show();
            var editor = self[(self.standalone) ? "button" : "editor"];
            editor.parent().removeClass('emojionearea-disable');
            trigger(self, 'enabled', [editor]);
        };
        self.isReady ? next() : self.on("ready", next);
        return self;
    }

    EmojioneArea.prototype.disable = function () {
        var self = this;
        self.disabled = true;
        var next = function () {
            self.editor.prop('contenteditable', false);
            self.hidePicker();
            self.button.hide();
            var editor = self[(self.standalone) ? "button" : "editor"];
            editor.parent().addClass('emojionearea-disable');
            trigger(self, 'disabled', [editor]);
        };
        self.isReady ? next() : self.on("ready", next);
        return self;
    }

	
	

    var uniRegexp = new RegExp("<object[^>]*>.*?<\/object>|<span[^>]*>.*?<\/span>|<(?:object|embed|svg|img|div|span|p|a)[^>]*>|("+
        emojione.unicodeRegexp+")", "gi");

    function getTemplate(template, unicode, shortname) {
        return template
            .replace('{name}', shortname || '')
            .replace('{img}', emojione.imagePathPNG + unicode + '.png'/* + emojione.cacheBustParam*/)
            .replace('{uni}', unicode)
            .replace('{alt}', emojione.convert(unicode));
    }

    function unicodeTo(str, template) {
        return str.replace(uniRegexp, function(unicodeChar) {
            if (typeof unicodeChar !== 'undefined' && unicodeChar in emojione.jsecapeMap) {
                return getTemplate(template, emojione.jsecapeMap[unicodeChar]);
            }
            return unicodeChar;
        });
    }

    function shortnameTo(str, template) {
        return str.replace(/:?[\w_]+:?/g, function(shortname) {
            shortname = ":" + shortname.replace(/:$/,'').replace(/^:/,'') + ":";
            if (shortname in emojioneList) {
                return getTemplate(template, emojioneList[shortname][emojioneList[shortname].length-1].toUpperCase(), shortname);
            }
            return shortname;
        });
    };

    function init(source, options) {
        options = $.extend({}, default_options, options);

        var self = this,
            sourceValFunc = source.is("TEXTAREA") || source.is("INPUT") ? "val" : "text",
            app = options.template,
            stayFocused = false,
            // DOM
            container = !!options.container ? $(options.container) : false,
            editor, filters, tabs, scrollArea, filtersBtns, filtersArrowLeft, filtersArrowRight,
            // scroll vars
            filtersWidth, scrollLeft = 0, scrollAreaWidth = 0, filterWidth,
            resizeHandler = function() {
                var width = filters.width();
                if (width !== filtersWidth) {
                    filtersWidth = width;
                    trigger(self, 'resize', [editor]);
                }
            }, resizeHandlerID;

        self.id = time();
        self.placeholder = options["placeholder"] || source.data("placeholder") || source.attr("placeholder") || "";
        self.sprite = options.useSprite;

        eventStorage[self.id] = {};

        // parse template
        for (var el = ["editor", "filters", "tabs"], i=0; i<3; i++) {
            app = app.replace(new RegExp('<' + el[i] + '/?>' ,'i'), '<div class="emojionearea-' + el[i] + '"></div>');
        }

        // wrap application
        app = $('<div>' + app + '</div>')
            .addClass("emojionearea")
            .attr("role", "application");

        // set editor attributes
        this.editor = app.find(".emojionearea-editor")
            .attr("contenteditable", "true")
            .attr("placeholder", self.placeholder)
            .attr('tabindex', 0);

        editor = self.editor;

        for (var attr = ["dir", "spellcheck", "autocomplete", "autocorrect", "autocapitalize"], i=0; i<5; i++) {
            editor.attr(attr[i], options[attr[i]]);
        }

        // filters
        filters = app.find(".emojionearea-filters");
        if (options.autoHideFilters) {
            filters.hide();
        }

        // tabs
        tabs = app.find(".emojionearea-tabs");

        // parse icons
        $.each(options.filters, function(filter, params) {
            // filters
            $("<i/>")
                .wrapInner(shortnameTo(params.icon, self.sprite ? '<i class="emojione-{uni}"/>' : '<img class="emojione" src="{img}"/>'))
                .addClass('emojionearea-filter')
                .data("filter", filter)
                .appendTo(filters);

            // tabs
            $("<div/>")
                .data("items", shortnameTo(params.emoji, '<i class="emojibtn" role="button">' +
                    (self.sprite ? '<i class="emojione-{uni}"' : '<img class="emojione" src="{img}"') +
                    ' data-name="{name}"/></i>'))
                .addClass('emojionearea-tab')
                .addClass('emojionearea-tab-' + filter)
                .hide()
                .appendTo(tabs);
        });

        filters.wrapInner('<div class="emojionearea-filters-scroll"/>');
        filtersArrowLeft = $('<i class="emojionearea-filter-arrow-left"/>').attr("role", "button").appendTo(filters);
        filtersArrowRight = $('<i class="emojionearea-filter-arrow-right"/>').attr("role", "button").appendTo(filters);

        filtersBtns = filters.find(".emojionearea-filter");
        scrollArea = filters.children(".emojionearea-filters-scroll");

        // show application
        if (!!container) {
            container.wrapInner(app);
        } else {
            app.insertAfter(source);
        }

        if (options.hideSource) {
            source.hide();
        }

        self.setText(source[sourceValFunc]());
 
        // attach events
        attach(self, [filters, tabs], {mousedown: "area.mousedown"}, editor);
        attach(self, editor, "paste", editor);
        attach(self, editor, ["focus", "blur"], function() { return !!stayFocused ? false : editor; });
        attach(self, [editor, filters, tabs], ["mousedown", "mouseup", "click", "keyup", "keydown"], editor);
        attach(self, filters.find(".emojionearea-filter"), {click: "filter.click"});
        attach(self, filtersArrowLeft, {click: "arrowLeft.click"});
        attach(self, filtersArrowRight, {click: "arrowRight.click"});

        function scrollFilters() {
            if (!scrollAreaWidth) {
                $.each(filtersBtns, function (i, e) {
                    scrollAreaWidth += $(e).outerWidth(true);
                });
                filterWidth = filtersBtns.eq(0).outerWidth(true);
            }
            if (scrollAreaWidth > filtersWidth) {
                filtersArrowRight.addClass("active");
                filtersArrowLeft.addClass("active");

                if (scrollLeft + scrollAreaWidth <= filtersWidth) {
                    scrollLeft = filtersWidth - scrollAreaWidth;
                    filtersArrowRight.removeClass("active");
                } else if (scrollLeft >= 0) {
                    scrollLeft = 0;
                    filtersArrowLeft.removeClass("active");
                }
                scrollArea.css("left", scrollLeft);
            } else {
                if (scrollLeft !== 0) {
                    scrollLeft = 0;
                    scrollArea.css("left", scrollLeft);
                }
                filtersArrowRight.removeClass("active");
                filtersArrowLeft.removeClass("active");
            }
        }


        self.on("@filter.click", function(element) {
                if (element.is(".active")) {
                    element.removeClass("active");
                    tabs.children().hide();
                } else {
                    filtersBtns.filter(".active").removeClass("active");
                    element.addClass("active");
                    var i, timer, tab = tabs.children().hide()
                        .filter(".emojionearea-tab-" + element.data("filter")).show(),
                        items = tab.data("items"),
                        event = {click: "emojibtn.click"};
                    if (items) {
                        tab.data("items", false);
                        items = items.split(',');
                        if (self.sprite) {
                            tab.html(items.join(''));
                            attach(self, tab.find(".emojibtn"), event);
                        } else {
                            timer = window.setInterval(function () {
                                for (i = 0; i < 20 && items.length; i++) {
                                    tab.append(items.shift());
                                    attach(self, tab.find(".emojibtn").not(".handled").addClass("handled"), event);
                                }
                                if (!items.length) window.clearInterval(timer);
                            }, 5);
                        }
                    }
                }
            })

            .on("@resize", function() {
                scrollFilters();
            })

            .on("@arrowLeft.click", function() {
                scrollLeft += filterWidth;
                scrollFilters();
            })

            .on("@arrowRight.click", function() {
                scrollLeft -= filterWidth;
                scrollFilters();
            })

            .on("@paste", function(element) {
                stayFocused = true;
                pasteHtmlAtCaret('<span> </span>');

                var sel = saveSelection(element[0]),
                    editorScrollTop = element.scrollTop(),
                    clipboard = $("<div/>")
                        .appendTo($("BODY"))
                        .attr("contenteditable", "true")
                        .css({position: "fixed", left: "-999px", width: "1px", height: "1px", top: "20px", overflow: "hidden"})
                        .focus();

                window.setTimeout(function() {
                    var UID = "caret-" + time();
                    element.focus();
                    restoreSelection(element[0], sel);
                    pasteHtmlAtCaret(htmlFromText(textFromHtml(clipboard.html().replace(/\r\n|\n|\r/g, '<br>')), self));
                    clipboard.remove();
                    pasteHtmlAtCaret('<i id="' + UID +'"></i>');
                    element.scrollTop(editorScrollTop);
                    var caret = $("#" + UID),
                        top = caret.offset().top - element.offset().top,
                        height = element.height();
                    if (editorScrollTop + top >= height || editorScrollTop > top) {
                        element.scrollTop(editorScrollTop + top - 2 * height/3);
                    }
                    caret.remove();
                    stayFocused = false;
                }, 200);
            })

            .on("@emojibtn.click", function(element) {
                saveSelection(editor[0]);
                pasteHtmlAtCaret(shortnameTo(element.children().data("name"),
                    '<img alt="{alt}" class="emojione' + (self.sprite ? '-{uni}" src="'+blankImg+'">' : '" src="{img}">')));
            })

            .on("@area.mousedown", function(element, event) {
                if (!options.autoHideFilters && !app.is(".focused")) {
                    element.focus();
                }
                event.preventDefault();
                return false;
            })

            .on("@change", function(element) {
                var html = element.html().replace(/<\/?(?:div|span|p)[^>]*>/ig, '');
                // clear input, fix: chrome add <br> on contenteditable is empty
                if (!html.length || /^<br[^>]*>$/i.test(html)) {
                    self.setText('', false);
                }
                source[sourceValFunc](self.getText());
            })

            .on("@focus", function() {
                resizeHandler();
                resizeHandlerID = window.setInterval(resizeHandler, 500);
                app.addClass("focused");
                if (options.autoHideFilters) {
                    filters.slideDown(400);
                }
            })

            .on("@blur", function(element) {
                scrollLeft = 0;
                scrollFilters();
                app.removeClass("focused");
                window.clearInterval(resizeHandlerID);
                if (options.autoHideFilters) {
                    filters.slideUp(400);
                }
                filtersBtns.filter(".active").removeClass("active");
                tabs.children().hide();
                var content = element.html();
                if (self.content !== content) {
                    self.content = content;
                    trigger(self, 'change', [editor]);
                }
            });
    };
/*

    $.fn.emojioneArea = function(options) {
        return this.each(function() {
            if (!!this.emojioneArea) return this.emojioneArea;
            return this.emojioneArea = new EmojioneArea($(this), options);
        });
    };
	*/
	
	
    $.fn.emojioneArea = function(options) {
        return this.each(function() {
            if (!!this.emojioneArea) return this.emojioneArea;
            $.data(this, 'emojioneArea', this.emojioneArea = new EmojioneArea($(this), options));
            return this.emojioneArea;
        });
    };

}) (document, window, jQuery, emojione);