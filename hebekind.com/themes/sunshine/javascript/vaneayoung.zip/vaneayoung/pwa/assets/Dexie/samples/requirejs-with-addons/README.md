﻿# Sample - Using Dexie.js + addons with RequireJS

This is a sample on how to use RequireJS to include dexie.js with addons into your web project.

npm install http-server -g
http-server ../.. -a localhost -p 8081
Surf to http://localhost:8081/samples/requirejs-with-addons/app.html
