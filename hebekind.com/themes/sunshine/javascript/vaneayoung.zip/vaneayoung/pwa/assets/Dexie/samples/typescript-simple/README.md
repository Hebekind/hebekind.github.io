## Build
```
npm install
npm run build
```

## Run
```
npm run start
```
Launch a web browser to http://localhost:8081 
