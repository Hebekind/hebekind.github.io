module.exports = {Stream: function(){}};

