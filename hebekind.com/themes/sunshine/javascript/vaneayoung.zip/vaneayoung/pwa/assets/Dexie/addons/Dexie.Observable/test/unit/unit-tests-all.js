import './hooks/tests-creating.js';
import './hooks/tests-deleting.js';
import './hooks/tests-updating.js';
import './tests-override-open.js';
import './tests-override-parse-stores-spec.js';
import './tests-observable-misc';
