QUnit.config.autostart = false;
window.workerImports = ['../dist/dexie.js'];
window.workerSource = 'base/test/worker.js';
